# V2-1 本地数据库与第一版迁移说明

本阶段建立第二版正式数据层。它不会改变当前公开网站的页面，数据库只用于以后在 Mac 上运行的个人本地模式。

## 数据保存位置

默认数据库：

```text
user-data/contexto.sqlite3
```

默认迁移前备份目录：

```text
backups/
```

这两个位置均已从 Git 排除。数据库、学习记录和私人导入文件不会进入公开源码或公开网站。

## 核心关系

```mermaid
flowchart TD
  W[WordBook 词书] --> M[WordBookEntry 成员关系]
  M --> L[Lexeme 全局词条]
  L --> S[Sense 独立义项]
  S --> E[Example / Grammar / Exercise]
```

同一个 `Lexeme` 可以通过多条 `WordBookEntry` 属于不同词书，词条内容只维护一份。

```mermaid
flowchart TD
  P[LocalProfile 本地档案] --> WP[UserWordProgress 词条进度]
  P --> SP[SenseProgress 义项进度]
  SP --> R[ReviewEvent 复习历史]
  P --> F[Favorite 多类型收藏]
```

## 数据表分组

| 分组 | 主要数据表 |
| --- | --- |
| 本地用户 | `local_profiles`、`profile_stats`、`learning_sessions` |
| 词书与词条 | `word_books`、`word_book_entries`、`lexemes`、`parts_of_speech` |
| 学习内容 | `senses`、`phrases`、`lexeme_relations`、`example_sentences`、`grammar_annotations`、`audio_assets` |
| 练习 | `exercises`、`exercise_acceptable_answers`、`exercise_attempts` |
| 学习进度 | `user_word_book_progress`、`user_word_progress`、`sense_progress`、`review_events`、`favorites` |
| 来源与审核 | `content_sources`、`content_review_statuses` |
| 导入与迁移 | `import_jobs`、`import_issues`、`migration_records`、`migration_issues` |

共 27 个正式业务表，另有 `app_schema_migrations` 用于记录数据库结构升级。

## 初始化数据库

在项目文件夹的终端中执行：

```bash
npm run db:init
```

正常结果会显示数据库位置、数据表数量及第一版测试内容数量。命令执行完会自动停止，不需要按 `Control + C`。

第一版测试内容会迁移为一本明确标记的“开发测试词书”。当前只有 2 个词条，并且多个义项不足 3 例句，因此 `content_ready` 为 false，不会冒充正式可学习内容。

## 迁移第一版浏览器学习档案

### 1. 先从第一版导出

打开第一版网站，进入“设置”，选择“导出学习档案”。浏览器会下载类似文件：

```text
contexto-backup-2026-07-18.json
```

不要修改文件内容。原始 JSON 在迁移后仍保留，不会被删除。

### 2. 放进私人数据目录

建议在项目中建立：

```text
user-data/imports/
```

把下载的 JSON 放入该目录。整个 `user-data/` 已被 Git 排除。

### 3. 执行迁移

把下面示例中的文件名替换成实际文件名：

```bash
npm run db:migrate:v1 -- --input user-data/imports/contexto-backup-2026-07-18.json
```

迁移顺序固定为：

1. 验证 JSON 格式和 `schemaVersion`；
2. 如果已有数据库，先创建 SQLite 完整备份；
3. 检查并升级数据库结构；
4. 迁移收藏、义项进度、活动统计和语速；
5. 保存一条可审计的迁移记录；
6. 对找不到对应内容的旧 ID 生成 `migration_issues`，不静默丢弃；
7. 同一份文件成功迁移后拒绝再次导入。

### 4. 查看结果

```bash
npm run db:report
```

报告只显示数量和结构，不显示私人答案正文。

## 如何判断迁移成功

- 输出包含“第一版学习档案迁移完成”；
- 显示迁移前备份路径；
- 显示收藏和义项进度的“读取／写入”数量；
- `npm run db:report` 中 `migrationRecords` 至少为 1；
- 找不到对应内容的旧记录计入“待处理记录”，而不是消失。

## 回退原则

- 原始第一版 JSON 永不删除；
- 每次迁移现有数据库前创建独立 `.sqlite3` 备份；
- 迁移在单个数据库事务中完成，写入中途失败会整体撤销；
- 当前不要手动覆盖正在使用的数据库；正式恢复按钮和自动“恢复前再备份”将在备份恢复阶段实现。

如迁移报错，请保留完整错误文字、原始 JSON 和输出的备份路径，不要反复重试或删除数据库。

## 当前驱动边界

V2-1 使用 Node 自带的 SQLite 接口，并隔离在 `db/local/`。当前 Node 运行时会显示一条 SQLite 实验性接口警告；这不是迁移失败。SQLite 文件格式和 SQL 迁移不依赖该接口，后续如果改用稳定的独立驱动，只需替换适配层，不需要重新设计数据表或丢弃数据库。
