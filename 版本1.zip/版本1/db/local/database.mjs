import { createHash } from "node:crypto";
import {
  existsSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  statSync,
} from "node:fs";
import { dirname, isAbsolute, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { DatabaseSync } from "node:sqlite";

import {
  DEFAULT_PROFILE_ID,
  LOCAL_SCHEMA_VERSION,
  PARTS_OF_SPEECH,
  REVIEW_STATUSES,
} from "./constants.mjs";

export const projectRoot = fileURLToPath(new URL("../../", import.meta.url));

function configuredProjectPath(value, fallback) {
  const selected = value || fallback;
  if (selected === ":memory:") return selected;
  return isAbsolute(selected) ? selected : join(projectRoot, selected);
}

export const defaultDatabasePath = configuredProjectPath(
  process.env.CONTEXTO_DATABASE_PATH,
  "user-data/contexto.sqlite3",
);
export const defaultBackupDirectory = configuredProjectPath(
  process.env.CONTEXTO_BACKUP_DIR,
  "backups",
);

export function resolveProjectPath(value, fallback) {
  const selected = value || fallback;
  if (selected === ":memory:") return selected;
  return isAbsolute(selected) ? selected : resolve(projectRoot, selected);
}

function sha256(value) {
  return createHash("sha256").update(value).digest("hex");
}

export function openLocalDatabase(databasePath = defaultDatabasePath, options = {}) {
  const resolvedPath = resolveProjectPath(databasePath, defaultDatabasePath);
  if (resolvedPath !== ":memory:" && !options.readOnly) {
    mkdirSync(dirname(resolvedPath), { recursive: true });
  }

  const database = new DatabaseSync(resolvedPath, {
    readOnly: options.readOnly ?? false,
    enableForeignKeyConstraints: true,
    enableDoubleQuotedStringLiterals: false,
  });

  if (!options.readOnly) {
    database.exec("PRAGMA journal_mode = WAL;");
    database.exec("PRAGMA synchronous = NORMAL;");
  }
  database.exec("PRAGMA foreign_keys = ON;");
  return database;
}

export function withTransaction(database, operation) {
  database.exec("BEGIN IMMEDIATE;");
  try {
    const result = operation();
    database.exec("COMMIT;");
    return result;
  } catch (error) {
    database.exec("ROLLBACK;");
    throw error;
  }
}

export function applySqlMigrations(database) {
  database.exec(`
    CREATE TABLE IF NOT EXISTS app_schema_migrations (
      migration_name TEXT PRIMARY KEY NOT NULL,
      checksum TEXT NOT NULL,
      applied_at TEXT NOT NULL
    );
  `);

  const migrationsDirectory = join(projectRoot, "drizzle");
  const migrationFiles = readdirSync(migrationsDirectory)
    .filter((name) => /^\d+.*\.sql$/.test(name))
    .sort((left, right) => left.localeCompare(right));

  const findApplied = database.prepare(
    "SELECT checksum FROM app_schema_migrations WHERE migration_name = ?",
  );
  const recordApplied = database.prepare(`
    INSERT INTO app_schema_migrations (migration_name, checksum, applied_at)
    VALUES (?, ?, ?)
  `);

  const applied = [];
  for (const migrationName of migrationFiles) {
    const sqlText = readFileSync(join(migrationsDirectory, migrationName), "utf8");
    const checksum = sha256(sqlText);
    const existing = findApplied.get(migrationName);
    if (existing) {
      if (existing.checksum !== checksum) {
        throw new Error(
          `数据库迁移 ${migrationName} 已被修改，拒绝继续以保护现有数据。`,
        );
      }
      continue;
    }

    withTransaction(database, () => {
      database.exec(sqlText);
      recordApplied.run(migrationName, checksum, new Date().toISOString());
    });
    applied.push(migrationName);
  }

  return applied;
}

export function seedReferenceData(database, timezone = "UTC") {
  const upsertStatus = database.prepare(`
    INSERT INTO content_review_statuses (code, label_zh, is_learnable, sort_order)
    VALUES (?, ?, ?, ?)
    ON CONFLICT(code) DO UPDATE SET
      label_zh = excluded.label_zh,
      is_learnable = excluded.is_learnable,
      sort_order = excluded.sort_order
  `);
  const upsertPartOfSpeech = database.prepare(`
    INSERT INTO parts_of_speech (code, label_es, label_zh, sort_order)
    VALUES (?, ?, ?, ?)
    ON CONFLICT(code) DO UPDATE SET
      label_es = excluded.label_es,
      label_zh = excluded.label_zh,
      sort_order = excluded.sort_order
  `);
  const upsertProfile = database.prepare(`
    INSERT INTO local_profiles (
      id, display_name, locale, timezone, speech_rate, settings_json
    ) VALUES (?, '个人学习档案', 'zh-CN', ?, 'normal', '{}')
    ON CONFLICT(id) DO UPDATE SET timezone = excluded.timezone
  `);
  const upsertStats = database.prepare(`
    INSERT INTO profile_stats (profile_id) VALUES (?)
    ON CONFLICT(profile_id) DO NOTHING
  `);

  withTransaction(database, () => {
    for (const status of REVIEW_STATUSES) upsertStatus.run(...status);
    for (const partOfSpeech of PARTS_OF_SPEECH) {
      upsertPartOfSpeech.run(...partOfSpeech);
    }
    upsertProfile.run(DEFAULT_PROFILE_ID, timezone);
    upsertStats.run(DEFAULT_PROFILE_ID);
  });
}

export function initializeSchema(database, options = {}) {
  const appliedMigrations = applySqlMigrations(database);
  seedReferenceData(
    database,
    options.timezone || Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC",
  );
  return { schemaVersion: LOCAL_SCHEMA_VERSION, appliedMigrations };
}

export function createPreMigrationBackup(
  databasePath = defaultDatabasePath,
  backupDirectory = defaultBackupDirectory,
  label = "pre-migration",
) {
  const resolvedDatabasePath = resolveProjectPath(databasePath, defaultDatabasePath);
  if (
    resolvedDatabasePath === ":memory:" ||
    !existsSync(resolvedDatabasePath) ||
    statSync(resolvedDatabasePath).size === 0
  ) {
    return null;
  }

  const resolvedBackupDirectory = resolveProjectPath(
    backupDirectory,
    defaultBackupDirectory,
  );
  mkdirSync(resolvedBackupDirectory, { recursive: true });
  const safeLabel = label.replace(/[^a-zA-Z0-9_-]+/g, "-");
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
  const backupPath = join(
    resolvedBackupDirectory,
    `contexto-${safeLabel}-${timestamp}.sqlite3`,
  );

  const database = openLocalDatabase(resolvedDatabasePath);
  try {
    database.exec("PRAGMA wal_checkpoint(FULL);");
    database.prepare("VACUUM INTO ?").run(backupPath);
  } finally {
    database.close();
  }
  return backupPath;
}

export function getDatabaseReport(database) {
  const tableNames = database
    .prepare(`
      SELECT name
      FROM sqlite_master
      WHERE type = 'table' AND name NOT LIKE 'sqlite_%'
      ORDER BY name
    `)
    .all()
    .map((row) => row.name);

  const count = (table) => database.prepare(`SELECT COUNT(*) AS count FROM ${table}`).get().count;
  return {
    schemaVersion: LOCAL_SCHEMA_VERSION,
    tableCount: tableNames.length,
    tables: tableNames,
    counts: {
      wordBooks: count("word_books"),
      enabledWordBooks: database
        .prepare("SELECT COUNT(*) AS count FROM word_books WHERE is_enabled = 1")
        .get().count,
      wordBookEntries: count("word_book_entries"),
      lexemes: count("lexemes"),
      senses: count("senses"),
      examples: count("example_sentences"),
      favorites: count("favorites"),
      senseProgress: count("sense_progress"),
      reviewEvents: count("review_events"),
      migrationRecords: count("migration_records"),
      migrationIssues: count("migration_issues"),
    },
  };
}
