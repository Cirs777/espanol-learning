import { readFileSync } from "node:fs";
import { join } from "node:path";

import { projectRoot, withTransaction } from "./database.mjs";

export function readWordBookCatalog() {
  return JSON.parse(readFileSync(join(projectRoot, "data", "wordbooks.json"), "utf8"));
}

export function seedWordBookCatalog(database, catalog = readWordBookCatalog()) {
  const sourceId = "content-source-contexto-wordbook-framework";
  const upsertSource = database.prepare(`
    INSERT INTO content_sources (
      id, name, source_type, license_name, authorization_status,
      imported_at, notes, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    ON CONFLICT(id) DO UPDATE SET
      name = excluded.name,
      source_type = excluded.source_type,
      license_name = excluded.license_name,
      authorization_status = excluded.authorization_status,
      notes = excluded.notes,
      updated_at = CURRENT_TIMESTAMP
  `);
  const upsertWordBook = database.prepare(`
    INSERT INTO word_books (
      id, name, level, description, source_id, source_notice,
      license_notice, version, is_enabled, is_development_only,
      created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      name = excluded.name,
      level = excluded.level,
      description = excluded.description,
      source_id = excluded.source_id,
      source_notice = excluded.source_notice,
      license_notice = excluded.license_notice,
      version = excluded.version,
      is_enabled = excluded.is_enabled,
      is_development_only = excluded.is_development_only,
      updated_at = excluded.updated_at
  `);

  const formalWordBooks = catalog.wordBooks.filter(
    (wordBook) => !wordBook.isDevelopmentOnly,
  );
  withTransaction(database, () => {
    upsertSource.run(
      sourceId,
      "Contexto 词书框架",
      "self_curated_framework",
      "项目自建元数据",
      "framework_only",
      new Date().toISOString(),
      catalog.meta.notice,
    );
    for (const wordBook of formalWordBooks) {
      upsertWordBook.run(
        wordBook.id,
        wordBook.name,
        wordBook.level,
        wordBook.description,
        sourceId,
        wordBook.sourceNotice,
        wordBook.licenseNotice,
        wordBook.version,
        wordBook.isEnabled ? 1 : 0,
        0,
        `${wordBook.updatedAt}T12:00:00.000Z`,
        `${wordBook.updatedAt}T12:00:00.000Z`,
      );
    }
  });
  return {
    total: formalWordBooks.length,
    enabled: formalWordBooks.filter((wordBook) => wordBook.isEnabled).length,
    planned: formalWordBooks.filter((wordBook) => !wordBook.isEnabled).length,
  };
}
