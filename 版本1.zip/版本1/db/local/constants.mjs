export const LOCAL_SCHEMA_VERSION = "2.0.0-v2.1";
export const DEFAULT_PROFILE_ID = "local-default";
export const V1_DEMO_WORDBOOK_ID = "wordbook-v1-development";
export const V1_INTERVAL_DAYS = [1, 3, 7, 14, 30, 60, 90];

export const REVIEW_STATUSES = [
  ["development_test", "开发测试", 0, 10],
  ["pending_review", "待审核", 0, 20],
  ["approved", "已审核", 1, 30],
  ["needs_revision", "需要修订", 0, 40],
  ["rejected", "不采用", 0, 50],
];

export const PARTS_OF_SPEECH = [
  ["noun", "sustantivo", "名词", 10],
  ["verb", "verbo", "动词", 20],
  ["adjective", "adjetivo", "形容词", 30],
  ["adverb", "adverbio", "副词", 40],
  ["pronoun", "pronombre", "代词", 50],
  ["preposition", "preposición", "介词", 60],
  ["conjunction", "conjunción", "连词", 70],
  ["determiner", "determinante", "限定词", 80],
  ["interjection", "interjección", "感叹词", 90],
  ["phrase", "locución", "固定表达", 100],
  ["other", "otro", "其他", 999],
];

export const V1_PART_OF_SPEECH_MAP = new Map([
  ["sustantivo", "noun"],
  ["nombre", "noun"],
  ["verbo", "verb"],
  ["adjetivo", "adjective"],
  ["adverbio", "adverb"],
  ["pronombre", "pronoun"],
  ["preposición", "preposition"],
  ["conjunción", "conjunction"],
  ["determinante", "determiner"],
  ["interjección", "interjection"],
  ["locución", "phrase"],
]);
