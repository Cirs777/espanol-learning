import {
  defaultDatabasePath,
  getDatabaseReport,
  initializeSchema,
  openLocalDatabase,
  resolveProjectPath,
} from "./database.mjs";
import { importV1DemoContent } from "./import-v1-content.mjs";
import { seedWordBookCatalog } from "./seed-wordbooks.mjs";

export function initializeLocalDatabase(options = {}) {
  const databasePath = resolveProjectPath(
    options.databasePath,
    defaultDatabasePath,
  );
  const database = openLocalDatabase(databasePath);
  try {
    const schema = initializeSchema(database, { timezone: options.timezone });
    const seededWordBooks = seedWordBookCatalog(database);
    const importedContent = options.importV1Demo === false
      ? null
      : importV1DemoContent(database);
    return {
      databasePath,
      ...schema,
      seededWordBooks,
      importedContent,
      report: getDatabaseReport(database),
    };
  } finally {
    database.close();
  }
}
