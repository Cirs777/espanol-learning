import { createHash, randomUUID } from "node:crypto";

import { initializeLocalDatabase } from "./bootstrap.mjs";
import {
  createPreMigrationBackup,
  defaultBackupDirectory,
  defaultDatabasePath,
  openLocalDatabase,
  resolveProjectPath,
  withTransaction,
} from "./database.mjs";
import {
  DEFAULT_PROFILE_ID,
  LOCAL_SCHEMA_VERSION,
  V1_INTERVAL_DAYS,
} from "./constants.mjs";

function isObject(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function integerOrZero(value) {
  return Number.isInteger(value) && value >= 0 ? value : 0;
}

function legacyDateToIso(value) {
  if (!value || typeof value !== "string") return null;
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return `${value}T12:00:00.000Z`;
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed.toISOString();
}

function statusFromScore(score) {
  if (score === 0) return "unknown";
  if (score === 1) return "unsure";
  return "known";
}

function easeFromScore(score) {
  if (score === 0) return 2.25;
  if (score === 1) return 2.4;
  return 2.6;
}

function scoreRank(status) {
  return { unknown: 0, unsure: 1, known: 2 }[status] ?? 0;
}

function inferFavoriteType(id) {
  if (id.startsWith("entry-")) return "lexeme";
  if (id.startsWith("sense-")) return "sense";
  if (id.startsWith("ex-")) return "example_sentence";
  if (id.startsWith("phrase-")) return "phrase";
  if (id.startsWith("grammar-")) return "grammar_annotation";
  return "legacy_unknown";
}

function targetExists(database, targetType, targetId) {
  const tableByType = {
    lexeme: "lexemes",
    sense: "senses",
    example_sentence: "example_sentences",
    phrase: "phrases",
    grammar_annotation: "grammar_annotations",
  };
  const table = tableByType[targetType];
  if (!table) return false;
  return Boolean(database.prepare(`SELECT 1 FROM ${table} WHERE id = ?`).get(targetId));
}

export function validateV1Profile(payload) {
  if (!isObject(payload)) throw new Error("第一版备份必须是 JSON 对象");
  if (payload.schemaVersion !== 1) {
    throw new Error("只支持 schemaVersion 为 1 的第一版学习档案");
  }

  if (payload.favorites !== undefined) {
    if (!Array.isArray(payload.favorites) || payload.favorites.some((id) => typeof id !== "string")) {
      throw new Error("favorites 必须是字符串数组");
    }
  }
  if (payload.reviewState !== undefined && !isObject(payload.reviewState)) {
    throw new Error("reviewState 必须是对象");
  }
  for (const [senseId, record] of Object.entries(payload.reviewState || {})) {
    if (!isObject(record)) throw new Error(`义项 ${senseId} 的复习记录格式不正确`);
    if (![0, 1, 2].includes(record.score)) {
      throw new Error(`义项 ${senseId} 的 score 必须是 0、1 或 2`);
    }
    if (!Number.isInteger(record.intervalIndex) || record.intervalIndex < 0) {
      throw new Error(`义项 ${senseId} 的 intervalIndex 格式不正确`);
    }
    if (record.contexts !== undefined) {
      if (!Array.isArray(record.contexts) || record.contexts.some((id) => typeof id !== "string")) {
        throw new Error(`义项 ${senseId} 的 contexts 必须是字符串数组`);
      }
    }
  }
  if (payload.activity !== undefined && !isObject(payload.activity)) {
    throw new Error("activity 必须是对象");
  }
  if (payload.speechRate !== undefined && !["normal", "slow"].includes(payload.speechRate)) {
    throw new Error("speechRate 必须是 normal 或 slow");
  }
  return payload;
}

export function migrateV1Profile(options) {
  const rawPayload = options.rawPayload;
  if (typeof rawPayload !== "string" || !rawPayload.trim()) {
    throw new Error("没有提供第一版 JSON 内容");
  }
  const payload = validateV1Profile(JSON.parse(rawPayload));
  const checksum = createHash("sha256").update(rawPayload).digest("hex");
  const databasePath = resolveProjectPath(options.databasePath, defaultDatabasePath);
  const backupDirectory = resolveProjectPath(
    options.backupDirectory,
    defaultBackupDirectory,
  );
  const startedAt = (options.now || new Date()).toISOString();
  const backupPath = createPreMigrationBackup(
    databasePath,
    backupDirectory,
    "pre-v1-profile-import",
  );

  initializeLocalDatabase({
    databasePath,
    timezone: options.timezone,
    importV1Demo: true,
  });

  const database = openLocalDatabase(databasePath);
  const migrationId = randomUUID();
  try {
    const existing = database.prepare(`
      SELECT id FROM migration_records
      WHERE migration_type = 'v1_profile' AND source_checksum = ? AND status = 'completed'
    `).get(checksum);
    if (existing) {
      const error = new Error("这份第一版学习档案已经成功迁移，未重复写入");
      error.code = "V1_ALREADY_MIGRATED";
      error.backupPath = backupPath;
      throw error;
    }

    const insertMigration = database.prepare(`
      INSERT INTO migration_records (
        id, migration_type, source_version, target_version, source_checksum,
        status, backup_path, counts_json, original_payload_json,
        started_at, completed_at
      ) VALUES (?, 'v1_profile', '1', ?, ?, 'running', ?, '{}', ?, ?, NULL)
    `);
    const finishMigration = database.prepare(`
      UPDATE migration_records
      SET status = 'completed', counts_json = ?, completed_at = ?
      WHERE id = ?
    `);
    const insertIssue = database.prepare(`
      INSERT INTO migration_issues (
        id, migration_record_id, severity, record_type, legacy_id,
        message, payload_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    const insertFavorite = database.prepare(`
      INSERT INTO favorites (id, profile_id, target_type, target_id, source)
      VALUES (?, ?, ?, ?, 'v1_import')
      ON CONFLICT(profile_id, target_type, target_id) DO NOTHING
    `);
    const findSense = database.prepare(
      "SELECT lexeme_id FROM senses WHERE id = ?",
    );
    const findSenseProgress = database.prepare(`
      SELECT current_status, updated_at
      FROM sense_progress WHERE profile_id = ? AND sense_id = ?
    `);
    const insertSenseProgress = database.prepare(`
      INSERT INTO sense_progress (
        profile_id, sense_id, current_status, ease_factor, interval_days,
        last_reviewed_at, next_review_at, short_queue_stage,
        short_queue_due_at, consecutive_known, consecutive_failures,
        attempts, independent_uses, context_ids_json, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 0, NULL, ?, ?, ?, ?, ?, ?)
    `);
    const insertReviewEvent = database.prepare(`
      INSERT INTO review_events (
        id, profile_id, lexeme_id, sense_id, word_book_id, event_type,
        rating, resulting_status, resulting_ease, resulting_interval_days,
        multiple_choice_errors, response_time_ms, context_id,
        occurred_at, payload_json
      ) VALUES (?, ?, ?, ?, NULL, 'legacy_v1_import', ?, ?, ?, ?, 0, NULL, ?, ?, ?)
    `);
    const upsertWordProgress = database.prepare(`
      INSERT INTO user_word_progress (
        profile_id, lexeme_id, current_status, familiarity_score,
        first_learned_at, last_studied_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(profile_id, lexeme_id) DO NOTHING
    `);
    const updateProfile = database.prepare(`
      UPDATE local_profiles
      SET speech_rate = ?, settings_json = ?, updated_at = ?
      WHERE id = ?
    `);
    const upsertStats = database.prepare(`
      INSERT INTO profile_stats (
        profile_id, sessions_count, answered_count, correct_count,
        recordings_count, minutes_total, last_active_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(profile_id) DO UPDATE SET
        sessions_count = MAX(profile_stats.sessions_count, excluded.sessions_count),
        answered_count = MAX(profile_stats.answered_count, excluded.answered_count),
        correct_count = MAX(profile_stats.correct_count, excluded.correct_count),
        recordings_count = MAX(profile_stats.recordings_count, excluded.recordings_count),
        minutes_total = MAX(profile_stats.minutes_total, excluded.minutes_total),
        last_active_at = CASE
          WHEN profile_stats.last_active_at IS NULL THEN excluded.last_active_at
          WHEN excluded.last_active_at IS NULL THEN profile_stats.last_active_at
          ELSE MAX(profile_stats.last_active_at, excluded.last_active_at)
        END,
        updated_at = excluded.updated_at
    `);

    const counts = {
      favoritesRead: 0,
      favoritesStored: 0,
      reviewRecordsRead: 0,
      senseProgressStored: 0,
      reviewEventsStored: 0,
      wordProgressStored: 0,
      issues: 0,
    };
    const lexemeProgress = new Map();

    withTransaction(database, () => {
      insertMigration.run(
        migrationId,
        LOCAL_SCHEMA_VERSION,
        checksum,
        backupPath,
        rawPayload,
        startedAt,
      );

      for (const favoriteId of [...new Set(payload.favorites || [])]) {
        counts.favoritesRead += 1;
        const targetType = inferFavoriteType(favoriteId);
        const result = insertFavorite.run(
          randomUUID(),
          DEFAULT_PROFILE_ID,
          targetType,
          favoriteId,
        );
        counts.favoritesStored += Number(result.changes > 0);
        if (!targetExists(database, targetType, favoriteId)) {
          counts.issues += 1;
          insertIssue.run(
            randomUUID(),
            migrationId,
            "warning",
            "favorite",
            favoriteId,
            "收藏目标在当前内容库中不存在；原始 ID 已保留，等待后续内容映射。",
            JSON.stringify({ targetType, favoriteId }),
          );
        }
      }

      for (const [senseId, record] of Object.entries(payload.reviewState || {})) {
        counts.reviewRecordsRead += 1;
        const sense = findSense.get(senseId);
        if (!sense) {
          counts.issues += 1;
          insertIssue.run(
            randomUUID(),
            migrationId,
            "warning",
            "sense_progress",
            senseId,
            "义项不在当前内容库中；原始复习记录完整保存在迁移报告中。",
            JSON.stringify(record),
          );
          continue;
        }

        const existingProgress = findSenseProgress.get(DEFAULT_PROFILE_ID, senseId);
        if (existingProgress) {
          counts.issues += 1;
          insertIssue.run(
            randomUUID(),
            migrationId,
            "warning",
            "sense_progress",
            senseId,
            "第二版中已存在该义项进度；为防止覆盖，新进度被保留，第一版记录保存在迁移报告中。",
            JSON.stringify(record),
          );
          continue;
        }

        const status = statusFromScore(record.score);
        const intervalIndex = Math.min(
          V1_INTERVAL_DAYS.length - 1,
          record.intervalIndex,
        );
        const intervalDays = V1_INTERVAL_DAYS[intervalIndex];
        const lastReviewedAt = legacyDateToIso(record.lastReview);
        const nextReviewAt = legacyDateToIso(record.nextReview);
        const contexts = [...new Set(record.contexts || [])];
        const attempts = integerOrZero(record.attempts);
        const independentUses = integerOrZero(record.independentUses);
        const easeFactor = easeFromScore(record.score);

        insertSenseProgress.run(
          DEFAULT_PROFILE_ID,
          senseId,
          status,
          easeFactor,
          intervalDays,
          lastReviewedAt,
          nextReviewAt,
          status === "known" ? Math.min(1, independentUses) : 0,
          status === "unknown" ? 1 : 0,
          attempts,
          independentUses,
          JSON.stringify(contexts),
          startedAt,
        );
        counts.senseProgressStored += 1;

        insertReviewEvent.run(
          randomUUID(),
          DEFAULT_PROFILE_ID,
          sense.lexeme_id,
          senseId,
          status,
          status,
          easeFactor,
          intervalDays,
          contexts[0] || null,
          lastReviewedAt || startedAt,
          JSON.stringify({ legacySchemaVersion: 1, record }),
        );
        counts.reviewEventsStored += 1;

        const aggregate = lexemeProgress.get(sense.lexeme_id) || {
          statuses: [],
          scores: [],
          firstLearnedAt: null,
          lastStudiedAt: null,
        };
        aggregate.statuses.push(status);
        aggregate.scores.push(record.score);
        aggregate.firstLearnedAt = aggregate.firstLearnedAt || lastReviewedAt;
        if (lastReviewedAt && (!aggregate.lastStudiedAt || lastReviewedAt > aggregate.lastStudiedAt)) {
          aggregate.lastStudiedAt = lastReviewedAt;
        }
        lexemeProgress.set(sense.lexeme_id, aggregate);
      }

      for (const [lexemeId, aggregate] of lexemeProgress) {
        const currentStatus = [...aggregate.statuses].sort(
          (left, right) => scoreRank(left) - scoreRank(right),
        )[0];
        const familiarityScore =
          aggregate.scores.reduce((sum, score) => sum + score, 0) /
          (aggregate.scores.length * 2);
        const result = upsertWordProgress.run(
          DEFAULT_PROFILE_ID,
          lexemeId,
          currentStatus,
          familiarityScore,
          aggregate.firstLearnedAt,
          aggregate.lastStudiedAt,
          startedAt,
        );
        counts.wordProgressStored += Number(result.changes > 0);
      }

      const activity = payload.activity || {};
      const profile = database
        .prepare("SELECT settings_json FROM local_profiles WHERE id = ?")
        .get(DEFAULT_PROFILE_ID);
      let settings = {};
      try {
        settings = JSON.parse(profile?.settings_json || "{}");
      } catch {
        settings = {};
      }
      settings.v1ProfileImportedAt = startedAt;
      settings.v1AppVersion = payload.appVersion || "0.1.0";
      updateProfile.run(
        payload.speechRate || "normal",
        JSON.stringify(settings),
        startedAt,
        DEFAULT_PROFILE_ID,
      );
      upsertStats.run(
        DEFAULT_PROFILE_ID,
        integerOrZero(activity.sessions),
        integerOrZero(activity.answered),
        integerOrZero(activity.correct),
        integerOrZero(activity.recordings),
        integerOrZero(activity.minutes),
        legacyDateToIso(activity.lastActive),
        startedAt,
      );

      finishMigration.run(
        JSON.stringify(counts),
        (options.now || new Date()).toISOString(),
        migrationId,
      );
    });

    return {
      migrationId,
      databasePath,
      backupPath,
      checksum,
      counts,
    };
  } finally {
    database.close();
  }
}
