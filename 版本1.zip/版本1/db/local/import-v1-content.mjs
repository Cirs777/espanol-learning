import { readFileSync } from "node:fs";
import { join } from "node:path";

import {
  V1_DEMO_WORDBOOK_ID,
  V1_PART_OF_SPEECH_MAP,
} from "./constants.mjs";
import { projectRoot, withTransaction } from "./database.mjs";

export function normalizeLemma(value) {
  return value.normalize("NFC").trim().toLocaleLowerCase("es");
}

export function normalizeAnswer(value) {
  return value
    .toLocaleLowerCase("es")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[¿?¡!.,;:]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function v1PartOfSpeech(value) {
  return V1_PART_OF_SPEECH_MAP.get(value.trim().toLocaleLowerCase("es")) || "other";
}

export function readV1DemoContent() {
  return JSON.parse(
    readFileSync(join(projectRoot, "data", "demo-content.json"), "utf8"),
  );
}

export function importV1DemoContent(database, content = readV1DemoContent()) {
  const sourceId = content.meta.contentPackId;
  const reviewStatus = "development_test";

  const upsertSource = database.prepare(`
    INSERT INTO content_sources (
      id, name, source_type, original_level, license_name,
      authorization_status, imported_at, notes, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    ON CONFLICT(id) DO UPDATE SET
      name = excluded.name,
      source_type = excluded.source_type,
      license_name = excluded.license_name,
      authorization_status = excluded.authorization_status,
      notes = excluded.notes,
      updated_at = CURRENT_TIMESTAMP
  `);
  const upsertWordBook = database.prepare(`
    INSERT INTO word_books (
      id, name, level, description, source_id, source_notice,
      license_notice, version, is_enabled, is_development_only, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, 1, CURRENT_TIMESTAMP)
    ON CONFLICT(id) DO UPDATE SET
      name = excluded.name,
      level = excluded.level,
      description = excluded.description,
      source_notice = excluded.source_notice,
      license_notice = excluded.license_notice,
      version = excluded.version,
      updated_at = CURRENT_TIMESTAMP
  `);
  const upsertLexeme = database.prepare(`
    INSERT INTO lexemes (
      id, lemma, normalized_lemma, language, part_of_speech_code,
      summary_zh, frequency_band, source_id, content_stage,
      review_status_code, updated_at
    ) VALUES (?, ?, ?, 'es', ?, ?, ?, ?, 'meanings_ready', ?, CURRENT_TIMESTAMP)
    ON CONFLICT(id) DO UPDATE SET
      lemma = excluded.lemma,
      normalized_lemma = excluded.normalized_lemma,
      part_of_speech_code = excluded.part_of_speech_code,
      summary_zh = excluded.summary_zh,
      frequency_band = excluded.frequency_band,
      content_stage = excluded.content_stage,
      review_status_code = excluded.review_status_code,
      updated_at = CURRENT_TIMESTAMP
  `);
  const upsertWordBookEntry = database.prepare(`
    INSERT INTO word_book_entries (
      word_book_id, lexeme_id, position, original_level, priority,
      source_id, content_ready
    ) VALUES (?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(word_book_id, lexeme_id) DO UPDATE SET
      position = excluded.position,
      original_level = excluded.original_level,
      priority = excluded.priority,
      source_id = excluded.source_id,
      content_ready = excluded.content_ready
  `);
  const upsertSense = database.prepare(`
    INSERT INTO senses (
      id, lexeme_id, part_of_speech_code, sense_order, importance,
      label_zh, definition_en, register_label, region_label,
      source_id, content_stage, review_status_code, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    ON CONFLICT(id) DO UPDATE SET
      lexeme_id = excluded.lexeme_id,
      part_of_speech_code = excluded.part_of_speech_code,
      sense_order = excluded.sense_order,
      importance = excluded.importance,
      label_zh = excluded.label_zh,
      definition_en = excluded.definition_en,
      register_label = excluded.register_label,
      region_label = excluded.region_label,
      content_stage = excluded.content_stage,
      review_status_code = excluded.review_status_code,
      updated_at = CURRENT_TIMESTAMP
  `);
  const upsertPhrase = database.prepare(`
    INSERT INTO phrases (
      id, lexeme_id, sense_id, phrase_type, text_es, sort_order,
      review_status_code, updated_at
    ) VALUES (?, ?, ?, 'chunk', ?, ?, ?, CURRENT_TIMESTAMP)
    ON CONFLICT(id) DO UPDATE SET
      text_es = excluded.text_es,
      sort_order = excluded.sort_order,
      review_status_code = excluded.review_status_code,
      updated_at = CURRENT_TIMESTAMP
  `);
  const upsertRelation = database.prepare(`
    INSERT INTO lexeme_relations (
      id, source_lexeme_id, relation_type, related_form, sort_order
    ) VALUES (?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      relation_type = excluded.relation_type,
      related_form = excluded.related_form,
      sort_order = excluded.sort_order
  `);
  const upsertExample = database.prepare(`
    INSERT INTO example_sentences (
      id, sense_id, sort_order, scene, spanish, translation_zh,
      translation_en, target_meaning, framework, replacement_prompt,
      level, source_id, source_type_label, review_status_code, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    ON CONFLICT(id) DO UPDATE SET
      sense_id = excluded.sense_id,
      sort_order = excluded.sort_order,
      scene = excluded.scene,
      spanish = excluded.spanish,
      translation_zh = excluded.translation_zh,
      translation_en = excluded.translation_en,
      target_meaning = excluded.target_meaning,
      framework = excluded.framework,
      replacement_prompt = excluded.replacement_prompt,
      level = excluded.level,
      source_type_label = excluded.source_type_label,
      review_status_code = excluded.review_status_code,
      updated_at = CURRENT_TIMESTAMP
  `);
  const upsertGrammar = database.prepare(`
    INSERT INTO grammar_annotations (
      id, example_sentence_id, annotation_type, label_zh, content_zh,
      sort_order, review_status_code, updated_at
    ) VALUES (?, ?, 'learning_note', '语法要点', ?, ?, ?, CURRENT_TIMESTAMP)
    ON CONFLICT(id) DO UPDATE SET
      content_zh = excluded.content_zh,
      sort_order = excluded.sort_order,
      review_status_code = excluded.review_status_code,
      updated_at = CURRENT_TIMESTAMP
  `);
  const upsertExercise = database.prepare(`
    INSERT INTO exercises (
      id, lexeme_id, sense_id, exercise_type, prompt, hint,
      primary_answer, feedback, difficulty, review_status_code, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, CURRENT_TIMESTAMP)
    ON CONFLICT(id) DO UPDATE SET
      lexeme_id = excluded.lexeme_id,
      sense_id = excluded.sense_id,
      exercise_type = excluded.exercise_type,
      prompt = excluded.prompt,
      hint = excluded.hint,
      primary_answer = excluded.primary_answer,
      feedback = excluded.feedback,
      review_status_code = excluded.review_status_code,
      updated_at = CURRENT_TIMESTAMP
  `);
  const upsertAnswer = database.prepare(`
    INSERT INTO exercise_acceptable_answers (
      exercise_id, answer, normalized_answer, sort_order
    ) VALUES (?, ?, ?, ?)
    ON CONFLICT(exercise_id, normalized_answer) DO UPDATE SET
      answer = excluded.answer,
      sort_order = excluded.sort_order
  `);

  const senseToLexeme = new Map();
  const counts = {
    wordBooks: 1,
    lexemes: content.entries.length,
    senses: 0,
    phrases: 0,
    examples: 0,
    grammarAnnotations: 0,
    exercises: content.exercises.length,
  };

  withTransaction(database, () => {
    upsertSource.run(
      sourceId,
      content.meta.title,
      content.meta.sourceType,
      "A2-B1",
      "项目自建 AI 学习文本（开发测试）",
      "project_owned_development",
      new Date().toISOString(),
      content.meta.notice,
    );
    upsertWordBook.run(
      V1_DEMO_WORDBOOK_ID,
      "第一版开发测试内容",
      "A2-B1",
      "仅用于验证第一版数据迁移，不作为正式等级词书。",
      sourceId,
      content.meta.notice,
      "项目自建开发测试内容；不得冒充官方或商业词书。",
      content.meta.version,
    );

    content.entries.forEach((entry, entryIndex) => {
      const partOfSpeech = v1PartOfSpeech(entry.partOfSpeech);
      const contentReady = content.meta.reviewStatus === "approved" && entry.senses.every(
        (sense) =>
          Array.isArray(sense.examples) &&
          sense.examples.length >= 3 &&
          sense.examples.every((example) =>
            example.analysis &&
            Array.isArray(example.analysis.sentenceParts) &&
            example.analysis.sentenceParts.length > 0 &&
            example.analysis.microExercise?.prompt &&
            example.analysis.microExercise?.answer,
          ),
      );
      upsertLexeme.run(
        entry.id,
        entry.lemma,
        normalizeLemma(entry.lemma),
        partOfSpeech,
        entry.summaryZh,
        entry.frequency,
        sourceId,
        reviewStatus,
      );
      upsertWordBookEntry.run(
        V1_DEMO_WORDBOOK_ID,
        entry.id,
        entryIndex + 1,
        entry.level,
        Math.max(0, 100 - entryIndex),
        sourceId,
        contentReady ? 1 : 0,
      );

      entry.family.forEach((relatedForm, index) => {
        upsertRelation.run(
          `relation-${entry.id}-family-${index + 1}`,
          entry.id,
          "family",
          relatedForm,
          index + 1,
        );
      });
      entry.contrasts.forEach((relatedForm, index) => {
        upsertRelation.run(
          `relation-${entry.id}-contrast-${index + 1}`,
          entry.id,
          "contrast",
          relatedForm,
          index + 1,
        );
      });

      entry.senses.forEach((sense, senseIndex) => {
        counts.senses += 1;
        senseToLexeme.set(sense.id, entry.id);
        const contentStage = sense.examples.length >= 3 ? "examples_ready" : "meanings_ready";
        upsertSense.run(
          sense.id,
          entry.id,
          partOfSpeech,
          senseIndex + 1,
          Math.max(1, 100 - senseIndex * 10),
          sense.labelZh,
          sense.definitionEn,
          sense.register,
          sense.region,
          sourceId,
          contentStage,
          reviewStatus,
        );

        sense.chunks.forEach((chunk, chunkIndex) => {
          counts.phrases += 1;
          upsertPhrase.run(
            `phrase-${sense.id}-${chunkIndex + 1}`,
            entry.id,
            sense.id,
            chunk,
            chunkIndex + 1,
            reviewStatus,
          );
        });

        sense.examples.forEach((example, exampleIndex) => {
          counts.examples += 1;
          upsertExample.run(
            example.id,
            sense.id,
            exampleIndex + 1,
            example.scene,
            example.spanish,
            example.chinese,
            example.english,
            example.targetMeaning,
            example.framework,
            example.replacement,
            entry.level,
            sourceId,
            example.sourceType,
            reviewStatus,
          );
          const analysisNotes = [
            ...example.grammar,
            `句子成分：${example.analysis.sentenceParts.join("；")}`,
            `动词信息：${example.analysis.verbInfo}`,
            `代词、冠词、介词与一致：${example.analysis.functionNotes.join("；")}`,
            `英西差异：${example.analysis.englishContrast}`,
            `常见迁移错误：${example.analysis.transferError}`,
            `其他词语：${example.analysis.extraVocabulary.join("；")}`,
            `微练习：${example.analysis.microExercise.prompt}｜参考：${example.analysis.microExercise.answer}`,
          ];
          analysisNotes.forEach((point, grammarIndex) => {
            counts.grammarAnnotations += 1;
            upsertGrammar.run(
              `grammar-${example.id}-${grammarIndex + 1}`,
              example.id,
              point,
              grammarIndex + 1,
              reviewStatus,
            );
          });
        });
      });
    });

    content.exercises.forEach((exercise) => {
      const lexemeId = senseToLexeme.get(exercise.senseId);
      if (!lexemeId) {
        throw new Error(`练习 ${exercise.id} 引用了不存在的义项 ${exercise.senseId}`);
      }
      upsertExercise.run(
        exercise.id,
        lexemeId,
        exercise.senseId,
        exercise.type,
        exercise.prompt,
        exercise.hint,
        exercise.answers[0],
        exercise.feedback,
        reviewStatus,
      );
      exercise.answers.forEach((answer, answerIndex) => {
        upsertAnswer.run(
          exercise.id,
          answer,
          normalizeAnswer(answer),
          answerIndex + 1,
        );
      });
    });
  });

  return counts;
}
