import { sql } from "drizzle-orm";
import {
  check,
  index,
  integer,
  primaryKey,
  real,
  sqliteTable,
  text,
  uniqueIndex,
} from "drizzle-orm/sqlite-core";

const createdAt = () =>
  text("created_at").notNull().default(sql`(CURRENT_TIMESTAMP)`);
const updatedAt = () =>
  text("updated_at").notNull().default(sql`(CURRENT_TIMESTAMP)`);

export const localProfiles = sqliteTable("local_profiles", {
  id: text("id").primaryKey(),
  displayName: text("display_name").notNull().default("个人学习档案"),
  locale: text("locale").notNull().default("zh-CN"),
  timezone: text("timezone").notNull().default("UTC"),
  speechRate: text("speech_rate").notNull().default("normal"),
  settingsJson: text("settings_json").notNull().default("{}"),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
});

export const profileStats = sqliteTable("profile_stats", {
  profileId: text("profile_id")
    .primaryKey()
    .references(() => localProfiles.id, { onDelete: "cascade" }),
  sessionsCount: integer("sessions_count").notNull().default(0),
  answeredCount: integer("answered_count").notNull().default(0),
  correctCount: integer("correct_count").notNull().default(0),
  recordingsCount: integer("recordings_count").notNull().default(0),
  minutesTotal: integer("minutes_total").notNull().default(0),
  lastActiveAt: text("last_active_at"),
  updatedAt: updatedAt(),
});

export const contentSources = sqliteTable("content_sources", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  sourceType: text("source_type").notNull(),
  originalLevel: text("original_level"),
  licenseName: text("license_name"),
  licenseUrl: text("license_url"),
  authorizationStatus: text("authorization_status").notNull(),
  importedAt: text("imported_at"),
  notes: text("notes"),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
});

export const contentReviewStatuses = sqliteTable(
  "content_review_statuses",
  {
    code: text("code").primaryKey(),
    labelZh: text("label_zh").notNull(),
    isLearnable: integer("is_learnable", { mode: "boolean" })
      .notNull()
      .default(false),
    sortOrder: integer("sort_order").notNull(),
  },
  (table) => [uniqueIndex("content_review_status_sort_uq").on(table.sortOrder)],
);

export const partsOfSpeech = sqliteTable("parts_of_speech", {
  code: text("code").primaryKey(),
  labelEs: text("label_es").notNull(),
  labelZh: text("label_zh").notNull(),
  sortOrder: integer("sort_order").notNull(),
});

export const wordBooks = sqliteTable(
  "word_books",
  {
    id: text("id").primaryKey(),
    name: text("name").notNull(),
    level: text("level"),
    description: text("description").notNull().default(""),
    sourceId: text("source_id").references(() => contentSources.id, {
      onDelete: "set null",
    }),
    sourceNotice: text("source_notice").notNull().default(""),
    licenseNotice: text("license_notice").notNull().default(""),
    version: text("version").notNull(),
    isEnabled: integer("is_enabled", { mode: "boolean" })
      .notNull()
      .default(true),
    isDevelopmentOnly: integer("is_development_only", { mode: "boolean" })
      .notNull()
      .default(false),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (table) => [
    index("word_books_level_idx").on(table.level),
    index("word_books_enabled_idx").on(table.isEnabled),
  ],
);

export const lexemes = sqliteTable(
  "lexemes",
  {
    id: text("id").primaryKey(),
    lemma: text("lemma").notNull(),
    normalizedLemma: text("normalized_lemma").notNull(),
    language: text("language").notNull().default("es"),
    partOfSpeechCode: text("part_of_speech_code")
      .notNull()
      .references(() => partsOfSpeech.code),
    summaryZh: text("summary_zh").notNull().default(""),
    frequencyBand: text("frequency_band"),
    sourceId: text("source_id").references(() => contentSources.id, {
      onDelete: "set null",
    }),
    contentStage: text("content_stage").notNull().default("index_only"),
    reviewStatusCode: text("review_status_code")
      .notNull()
      .default("pending_review")
      .references(() => contentReviewStatuses.code),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (table) => [
    uniqueIndex("lexemes_identity_uq").on(
      table.normalizedLemma,
      table.language,
      table.partOfSpeechCode,
    ),
    index("lexemes_search_idx").on(table.normalizedLemma),
    index("lexemes_content_stage_idx").on(table.contentStage),
    check(
      "lexemes_content_stage_check",
      sql`${table.contentStage} in ('index_only','meanings_ready','examples_ready','grammar_ready','audio_ready','exercises_ready','complete')`,
    ),
  ],
);

export const wordBookEntries = sqliteTable(
  "word_book_entries",
  {
    wordBookId: text("word_book_id")
      .notNull()
      .references(() => wordBooks.id, { onDelete: "cascade" }),
    lexemeId: text("lexeme_id")
      .notNull()
      .references(() => lexemes.id, { onDelete: "cascade" }),
    position: integer("position").notNull(),
    originalLevel: text("original_level"),
    frequencyRank: integer("frequency_rank"),
    priority: integer("priority").notNull().default(0),
    sourceId: text("source_id").references(() => contentSources.id, {
      onDelete: "set null",
    }),
    contentReady: integer("content_ready", { mode: "boolean" })
      .notNull()
      .default(false),
    addedAt: createdAt(),
  },
  (table) => [
    primaryKey({ columns: [table.wordBookId, table.lexemeId] }),
    uniqueIndex("word_book_entries_position_uq").on(
      table.wordBookId,
      table.position,
    ),
    index("word_book_entries_lexeme_idx").on(table.lexemeId),
    index("word_book_entries_ready_idx").on(
      table.wordBookId,
      table.contentReady,
    ),
  ],
);

export const senses = sqliteTable(
  "senses",
  {
    id: text("id").primaryKey(),
    lexemeId: text("lexeme_id")
      .notNull()
      .references(() => lexemes.id, { onDelete: "cascade" }),
    partOfSpeechCode: text("part_of_speech_code").references(
      () => partsOfSpeech.code,
    ),
    senseOrder: integer("sense_order").notNull(),
    importance: integer("importance").notNull().default(50),
    labelZh: text("label_zh").notNull(),
    definitionEs: text("definition_es"),
    definitionEn: text("definition_en"),
    scene: text("scene"),
    registerLabel: text("register_label"),
    regionLabel: text("region_label"),
    prepositionNotes: text("preposition_notes"),
    sourceId: text("source_id").references(() => contentSources.id, {
      onDelete: "set null",
    }),
    contentStage: text("content_stage").notNull().default("meanings_ready"),
    reviewStatusCode: text("review_status_code")
      .notNull()
      .default("pending_review")
      .references(() => contentReviewStatuses.code),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (table) => [
    uniqueIndex("senses_lexeme_order_uq").on(table.lexemeId, table.senseOrder),
    index("senses_lexeme_idx").on(table.lexemeId),
  ],
);

export const phrases = sqliteTable(
  "phrases",
  {
    id: text("id").primaryKey(),
    lexemeId: text("lexeme_id")
      .notNull()
      .references(() => lexemes.id, { onDelete: "cascade" }),
    senseId: text("sense_id").references(() => senses.id, {
      onDelete: "cascade",
    }),
    phraseType: text("phrase_type").notNull(),
    textEs: text("text_es").notNull(),
    meaningZh: text("meaning_zh"),
    usageNote: text("usage_note"),
    sortOrder: integer("sort_order").notNull(),
    reviewStatusCode: text("review_status_code")
      .notNull()
      .default("pending_review")
      .references(() => contentReviewStatuses.code),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (table) => [
    index("phrases_sense_idx").on(table.senseId),
    uniqueIndex("phrases_sense_text_uq").on(table.senseId, table.textEs),
  ],
);

export const lexemeRelations = sqliteTable(
  "lexeme_relations",
  {
    id: text("id").primaryKey(),
    sourceLexemeId: text("source_lexeme_id")
      .notNull()
      .references(() => lexemes.id, { onDelete: "cascade" }),
    targetLexemeId: text("target_lexeme_id").references(() => lexemes.id, {
      onDelete: "set null",
    }),
    relationType: text("relation_type").notNull(),
    relatedForm: text("related_form").notNull(),
    explanationZh: text("explanation_zh"),
    replaceabilityNote: text("replaceability_note"),
    sortOrder: integer("sort_order").notNull(),
    createdAt: createdAt(),
  },
  (table) => [
    index("lexeme_relations_source_idx").on(table.sourceLexemeId),
    uniqueIndex("lexeme_relations_form_uq").on(
      table.sourceLexemeId,
      table.relationType,
      table.relatedForm,
    ),
  ],
);

export const exampleSentences = sqliteTable(
  "example_sentences",
  {
    id: text("id").primaryKey(),
    senseId: text("sense_id")
      .notNull()
      .references(() => senses.id, { onDelete: "cascade" }),
    sortOrder: integer("sort_order").notNull(),
    scene: text("scene").notNull(),
    spanish: text("spanish").notNull(),
    translationZh: text("translation_zh").notNull(),
    translationEn: text("translation_en"),
    targetMeaning: text("target_meaning").notNull(),
    framework: text("framework"),
    replacementPrompt: text("replacement_prompt"),
    level: text("level"),
    sourceId: text("source_id").references(() => contentSources.id, {
      onDelete: "set null",
    }),
    sourceTypeLabel: text("source_type_label").notNull(),
    reviewStatusCode: text("review_status_code")
      .notNull()
      .default("pending_review")
      .references(() => contentReviewStatuses.code),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (table) => [
    uniqueIndex("examples_sense_order_uq").on(table.senseId, table.sortOrder),
    index("examples_sense_idx").on(table.senseId),
  ],
);

export const grammarAnnotations = sqliteTable(
  "grammar_annotations",
  {
    id: text("id").primaryKey(),
    exampleSentenceId: text("example_sentence_id")
      .notNull()
      .references(() => exampleSentences.id, { onDelete: "cascade" }),
    annotationType: text("annotation_type").notNull(),
    labelZh: text("label_zh").notNull(),
    contentZh: text("content_zh").notNull(),
    contentEs: text("content_es"),
    contentEn: text("content_en"),
    sortOrder: integer("sort_order").notNull(),
    reviewStatusCode: text("review_status_code")
      .notNull()
      .default("pending_review")
      .references(() => contentReviewStatuses.code),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (table) => [index("grammar_example_idx").on(table.exampleSentenceId)],
);

export const audioAssets = sqliteTable(
  "audio_assets",
  {
    id: text("id").primaryKey(),
    ownerType: text("owner_type").notNull(),
    ownerId: text("owner_id").notNull(),
    assetType: text("asset_type").notNull(),
    storagePath: text("storage_path"),
    voiceName: text("voice_name"),
    locale: text("locale").notNull().default("es-ES"),
    accentLabel: text("accent_label").notNull().default("欧洲西班牙语"),
    speed: real("speed").notNull().default(1),
    sourceId: text("source_id").references(() => contentSources.id, {
      onDelete: "set null",
    }),
    licenseNotice: text("license_notice"),
    reviewStatusCode: text("review_status_code")
      .notNull()
      .default("pending_review")
      .references(() => contentReviewStatuses.code),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (table) => [index("audio_owner_idx").on(table.ownerType, table.ownerId)],
);

export const exercises = sqliteTable(
  "exercises",
  {
    id: text("id").primaryKey(),
    lexemeId: text("lexeme_id").references(() => lexemes.id, {
      onDelete: "cascade",
    }),
    senseId: text("sense_id").references(() => senses.id, {
      onDelete: "cascade",
    }),
    phraseId: text("phrase_id").references(() => phrases.id, {
      onDelete: "set null",
    }),
    exampleSentenceId: text("example_sentence_id").references(
      () => exampleSentences.id,
      { onDelete: "set null" },
    ),
    exerciseType: text("exercise_type").notNull(),
    prompt: text("prompt").notNull(),
    hint: text("hint"),
    primaryAnswer: text("primary_answer").notNull(),
    feedback: text("feedback").notNull(),
    difficulty: integer("difficulty").notNull().default(1),
    errorTypeOnFailure: text("error_type_on_failure"),
    reviewStatusCode: text("review_status_code")
      .notNull()
      .default("pending_review")
      .references(() => contentReviewStatuses.code),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (table) => [
    index("exercises_sense_idx").on(table.senseId),
    index("exercises_type_idx").on(table.exerciseType),
  ],
);

export const exerciseAcceptableAnswers = sqliteTable(
  "exercise_acceptable_answers",
  {
    exerciseId: text("exercise_id")
      .notNull()
      .references(() => exercises.id, { onDelete: "cascade" }),
    answer: text("answer").notNull(),
    normalizedAnswer: text("normalized_answer").notNull(),
    sortOrder: integer("sort_order").notNull(),
  },
  (table) => [
    primaryKey({ columns: [table.exerciseId, table.normalizedAnswer] }),
  ],
);

export const favorites = sqliteTable(
  "favorites",
  {
    id: text("id").primaryKey(),
    profileId: text("profile_id")
      .notNull()
      .references(() => localProfiles.id, { onDelete: "cascade" }),
    targetType: text("target_type").notNull(),
    targetId: text("target_id").notNull(),
    source: text("source").notNull().default("user"),
    createdAt: createdAt(),
  },
  (table) => [
    uniqueIndex("favorites_target_uq").on(
      table.profileId,
      table.targetType,
      table.targetId,
    ),
    index("favorites_profile_idx").on(table.profileId),
  ],
);

export const userWordBookProgress = sqliteTable(
  "user_word_book_progress",
  {
    profileId: text("profile_id")
      .notNull()
      .references(() => localProfiles.id, { onDelete: "cascade" }),
    wordBookId: text("word_book_id")
      .notNull()
      .references(() => wordBooks.id, { onDelete: "cascade" }),
    state: text("state").notNull().default("not_started"),
    currentLexemeId: text("current_lexeme_id").references(() => lexemes.id, {
      onDelete: "set null",
    }),
    currentPosition: integer("current_position").notNull().default(0),
    isCurrent: integer("is_current", { mode: "boolean" })
      .notNull()
      .default(false),
    startedAt: text("started_at"),
    lastStudiedAt: text("last_studied_at"),
    updatedAt: updatedAt(),
  },
  (table) => [
    primaryKey({ columns: [table.profileId, table.wordBookId] }),
    index("word_book_progress_current_idx").on(table.profileId, table.isCurrent),
    check(
      "word_book_progress_state_check",
      sql`${table.state} in ('not_started','active','paused','completed','restarted')`,
    ),
  ],
);

export const userWordProgress = sqliteTable(
  "user_word_progress",
  {
    profileId: text("profile_id")
      .notNull()
      .references(() => localProfiles.id, { onDelete: "cascade" }),
    lexemeId: text("lexeme_id")
      .notNull()
      .references(() => lexemes.id, { onDelete: "cascade" }),
    currentStatus: text("current_status").notNull().default("unseen"),
    familiarityScore: real("familiarity_score").notNull().default(0),
    totalMultipleChoiceErrors: integer("total_multiple_choice_errors")
      .notNull()
      .default(0),
    totalStudySeconds: integer("total_study_seconds").notNull().default(0),
    firstLearnedAt: text("first_learned_at"),
    lastStudiedAt: text("last_studied_at"),
    updatedAt: updatedAt(),
  },
  (table) => [
    primaryKey({ columns: [table.profileId, table.lexemeId] }),
    index("word_progress_status_idx").on(table.profileId, table.currentStatus),
  ],
);

export const senseProgress = sqliteTable(
  "sense_progress",
  {
    profileId: text("profile_id")
      .notNull()
      .references(() => localProfiles.id, { onDelete: "cascade" }),
    senseId: text("sense_id")
      .notNull()
      .references(() => senses.id, { onDelete: "cascade" }),
    currentStatus: text("current_status").notNull().default("unseen"),
    easeFactor: real("ease_factor").notNull().default(2.5),
    intervalDays: real("interval_days").notNull().default(0),
    lastReviewedAt: text("last_reviewed_at"),
    nextReviewAt: text("next_review_at"),
    shortQueueStage: integer("short_queue_stage").notNull().default(0),
    shortQueueDueAt: text("short_queue_due_at"),
    consecutiveKnown: integer("consecutive_known").notNull().default(0),
    consecutiveFailures: integer("consecutive_failures").notNull().default(0),
    attempts: integer("attempts").notNull().default(0),
    independentUses: integer("independent_uses").notNull().default(0),
    contextIdsJson: text("context_ids_json").notNull().default("[]"),
    updatedAt: updatedAt(),
  },
  (table) => [
    primaryKey({ columns: [table.profileId, table.senseId] }),
    index("sense_progress_due_idx").on(table.profileId, table.nextReviewAt),
    index("sense_progress_short_due_idx").on(
      table.profileId,
      table.shortQueueDueAt,
    ),
  ],
);

export const reviewEvents = sqliteTable(
  "review_events",
  {
    id: text("id").primaryKey(),
    profileId: text("profile_id")
      .notNull()
      .references(() => localProfiles.id, { onDelete: "cascade" }),
    lexemeId: text("lexeme_id")
      .notNull()
      .references(() => lexemes.id, { onDelete: "cascade" }),
    senseId: text("sense_id").references(() => senses.id, {
      onDelete: "set null",
    }),
    wordBookId: text("word_book_id").references(() => wordBooks.id, {
      onDelete: "set null",
    }),
    eventType: text("event_type").notNull(),
    rating: text("rating"),
    previousStatus: text("previous_status"),
    resultingStatus: text("resulting_status"),
    previousEase: real("previous_ease"),
    resultingEase: real("resulting_ease"),
    previousIntervalDays: real("previous_interval_days"),
    resultingIntervalDays: real("resulting_interval_days"),
    multipleChoiceErrors: integer("multiple_choice_errors").notNull().default(0),
    responseTimeMs: integer("response_time_ms"),
    contextId: text("context_id"),
    occurredAt: text("occurred_at").notNull(),
    payloadJson: text("payload_json").notNull().default("{}"),
  },
  (table) => [
    index("review_events_profile_time_idx").on(table.profileId, table.occurredAt),
    index("review_events_sense_time_idx").on(table.senseId, table.occurredAt),
  ],
);

export const exerciseAttempts = sqliteTable(
  "exercise_attempts",
  {
    id: text("id").primaryKey(),
    profileId: text("profile_id")
      .notNull()
      .references(() => localProfiles.id, { onDelete: "cascade" }),
    exerciseId: text("exercise_id")
      .notNull()
      .references(() => exercises.id, { onDelete: "cascade" }),
    answer: text("answer").notNull(),
    normalizedAnswer: text("normalized_answer").notNull(),
    isAccepted: integer("is_accepted", { mode: "boolean" }).notNull(),
    errorType: text("error_type"),
    responseTimeMs: integer("response_time_ms"),
    attemptedAt: text("attempted_at").notNull(),
    feedbackJson: text("feedback_json").notNull().default("{}"),
  },
  (table) => [index("exercise_attempts_profile_idx").on(table.profileId)],
);

export const learningSessions = sqliteTable(
  "learning_sessions",
  {
    id: text("id").primaryKey(),
    profileId: text("profile_id")
      .notNull()
      .references(() => localProfiles.id, { onDelete: "cascade" }),
    wordBookId: text("word_book_id").references(() => wordBooks.id, {
      onDelete: "set null",
    }),
    deviceLabel: text("device_label"),
    startedAt: text("started_at").notNull(),
    endedAt: text("ended_at"),
    durationSeconds: integer("duration_seconds").notNull().default(0),
    viewedSenseIdsJson: text("viewed_sense_ids_json").notNull().default("[]"),
    playedAudioIdsJson: text("played_audio_ids_json").notNull().default("[]"),
    openedAnalysisIdsJson: text("opened_analysis_ids_json").notNull().default("[]"),
    metadataJson: text("metadata_json").notNull().default("{}"),
  },
  (table) => [index("learning_sessions_profile_idx").on(table.profileId)],
);

export const importJobs = sqliteTable(
  "import_jobs",
  {
    id: text("id").primaryKey(),
    profileId: text("profile_id").references(() => localProfiles.id, {
      onDelete: "set null",
    }),
    wordBookId: text("word_book_id").references(() => wordBooks.id, {
      onDelete: "set null",
    }),
    fileName: text("file_name").notNull(),
    fileType: text("file_type").notNull(),
    sourceChecksum: text("source_checksum").notNull(),
    fieldMappingJson: text("field_mapping_json").notNull().default("{}"),
    status: text("status").notNull(),
    previewCountsJson: text("preview_counts_json").notNull().default("{}"),
    resultCountsJson: text("result_counts_json").notNull().default("{}"),
    backupPath: text("backup_path"),
    startedAt: text("started_at").notNull(),
    completedAt: text("completed_at"),
  },
  (table) => [index("import_jobs_checksum_idx").on(table.sourceChecksum)],
);

export const importIssues = sqliteTable(
  "import_issues",
  {
    id: text("id").primaryKey(),
    importJobId: text("import_job_id")
      .notNull()
      .references(() => importJobs.id, { onDelete: "cascade" }),
    rowNumber: integer("row_number"),
    severity: text("severity").notNull(),
    issueCode: text("issue_code").notNull(),
    message: text("message").notNull(),
    rowPayloadJson: text("row_payload_json").notNull().default("{}"),
  },
  (table) => [index("import_issues_job_idx").on(table.importJobId)],
);

export const migrationRecords = sqliteTable(
  "migration_records",
  {
    id: text("id").primaryKey(),
    migrationType: text("migration_type").notNull(),
    sourceVersion: text("source_version").notNull(),
    targetVersion: text("target_version").notNull(),
    sourceChecksum: text("source_checksum").notNull(),
    status: text("status").notNull(),
    backupPath: text("backup_path"),
    countsJson: text("counts_json").notNull().default("{}"),
    originalPayloadJson: text("original_payload_json").notNull(),
    startedAt: text("started_at").notNull(),
    completedAt: text("completed_at"),
  },
  (table) => [
    uniqueIndex("migration_completed_source_uq")
      .on(table.migrationType, table.sourceChecksum)
      .where(sql`${table.status} = 'completed'`),
  ],
);

export const migrationIssues = sqliteTable(
  "migration_issues",
  {
    id: text("id").primaryKey(),
    migrationRecordId: text("migration_record_id")
      .notNull()
      .references(() => migrationRecords.id, { onDelete: "cascade" }),
    severity: text("severity").notNull(),
    recordType: text("record_type").notNull(),
    legacyId: text("legacy_id"),
    message: text("message").notNull(),
    payloadJson: text("payload_json").notNull().default("{}"),
  },
  (table) => [index("migration_issues_record_idx").on(table.migrationRecordId)],
);
