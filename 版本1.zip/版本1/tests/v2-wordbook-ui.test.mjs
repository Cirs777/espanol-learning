import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const page = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");
const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");

test("word book page exposes selection, honest counts and per-book controls", () => {
  for (const text of [
    "选择你的学习路线",
    "索引词条",
    "可学习",
    "选择词书",
    "暂停词书",
    "重新开始",
    "等待合法词表来源",
    "不会用虚构数量填充",
  ]) {
    assert.match(page, new RegExp(text));
  }
});

test("public demo explains device-local progress instead of promising sync", () => {
  assert.match(page, /双运行模式 · 当前公开演示/);
  assert.match(page, /设备间不会自动同步/);
  assert.match(page, /Mac 上的 SQLite 数据库统一保存/);
});

test("mobile word book controls use the shared narrow-screen layout", () => {
  assert.match(styles, /@media \(max-width: 760px\)/);
  assert.match(styles, /\.wordbook-grid[\s\S]*?grid-template-columns: 1fr/);
  assert.match(styles, /\.wordbook-filter-tabs button[\s\S]*?min-height: 44px/);
  assert.match(styles, /\.wordbook-detail-actions \.button[\s\S]*?min-height: 44px/);
  assert.match(styles, /\.wordbook-source-grid[\s\S]*?grid-template-columns: 1fr/);
});
