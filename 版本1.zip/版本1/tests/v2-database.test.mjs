import assert from "node:assert/strict";
import { existsSync, mkdirSync, mkdtempSync, rmSync } from "node:fs";
import { after, test } from "node:test";
import { join } from "node:path";

import { initializeLocalDatabase } from "../db/local/bootstrap.mjs";
import {
  getDatabaseReport,
  openLocalDatabase,
  projectRoot,
} from "../db/local/database.mjs";
import { migrateV1Profile } from "../db/local/migrate-v1-profile.mjs";

const workRoot = join(projectRoot, "work");
mkdirSync(workRoot, { recursive: true });
const testRoot = mkdtempSync(join(workRoot, "v2-db-test-"));

after(() => {
  rmSync(testRoot, { recursive: true, force: true });
});

function databasePath(name) {
  return join(testRoot, `${name}.sqlite3`);
}

test("initializes the formal V2 schema and preserves shared lexemes across word books", () => {
  const path = databasePath("schema");
  const first = initializeLocalDatabase({ databasePath: path, timezone: "Asia/Shanghai" });
  const second = initializeLocalDatabase({ databasePath: path, timezone: "Asia/Shanghai" });

  assert.equal(first.appliedMigrations.length, 1);
  assert.equal(second.appliedMigrations.length, 0);
  assert.ok(first.report.tableCount >= 28);
  assert.deepEqual(first.report.counts, {
    wordBooks: 13,
    enabledWordBooks: 4,
    wordBookEntries: 2,
    lexemes: 2,
    senses: 4,
    examples: 16,
    favorites: 0,
    senseProgress: 0,
    reviewEvents: 0,
    migrationRecords: 0,
    migrationIssues: 0,
  });

  const database = openLocalDatabase(path);
  try {
    assert.equal(database.prepare("PRAGMA integrity_check").get().integrity_check, "ok");
    assert.equal(database.prepare("PRAGMA foreign_key_check").all().length, 0);

    const unavailable = database
      .prepare("SELECT COUNT(*) AS count FROM word_book_entries WHERE content_ready = 0")
      .get();
    assert.equal(unavailable.count, 2, "incomplete V1 demo entries must not be marked learnable");

    database.exec(`
      INSERT INTO word_books (
        id, name, level, description, source_notice, license_notice, version
      ) VALUES (
        'wordbook-test-travel', '旅行测试词书', 'A2', '关系测试', '', '', 'test'
      );
      INSERT INTO word_book_entries (
        word_book_id, lexeme_id, position, original_level, content_ready
      ) VALUES ('wordbook-test-travel', 'entry-quedar', 1, 'A2', 0);
    `);
    const shared = database.prepare(`
      SELECT COUNT(*) AS memberships
      FROM word_book_entries WHERE lexeme_id = 'entry-quedar'
    `).get();
    const lexemeCount = database.prepare("SELECT COUNT(*) AS count FROM lexemes").get();
    assert.equal(shared.memberships, 2);
    assert.equal(lexemeCount.count, 2, "the same lexeme content must not be duplicated");
  } finally {
    database.close();
  }
});

test("migrates a V1 browser profile with backup, counts, orphan reporting and no silent overwrite", () => {
  const path = databasePath("v1-migration");
  const backupDirectory = join(testRoot, "backups");
  initializeLocalDatabase({ databasePath: path, timezone: "Europe/Madrid" });

  const payload = {
    schemaVersion: 1,
    exportedAt: "2026-07-17T10:30:00.000Z",
    appVersion: "0.1.0",
    favorites: ["entry-quedar", "missing-favorite"],
    reviewState: {
      "sense-quedar-meet": {
        intervalIndex: 2,
        score: 2,
        lastReview: "2026-07-17",
        nextReview: "2026-07-24",
        attempts: 3,
        independentUses: 2,
        contexts: ["ex-quedar-meet-1", "ex-quedar-meet-2"],
      },
      "sense-no-longer-in-content": {
        intervalIndex: 0,
        score: 0,
        lastReview: "2026-07-17",
        nextReview: "2026-07-18",
        attempts: 1,
        independentUses: 0,
        contexts: [],
      },
    },
    activity: {
      sessions: 4,
      answered: 9,
      correct: 6,
      recordings: 2,
      minutes: 31,
      lastActive: "2026-07-17",
    },
    speechRate: "slow",
  };
  const rawPayload = JSON.stringify(payload, null, 2);
  const now = new Date("2026-07-18T09:00:00.000Z");
  const result = migrateV1Profile({
    rawPayload,
    databasePath: path,
    backupDirectory,
    timezone: "Europe/Madrid",
    now,
  });

  assert.ok(result.backupPath);
  assert.ok(existsSync(result.backupPath));
  assert.deepEqual(result.counts, {
    favoritesRead: 2,
    favoritesStored: 2,
    reviewRecordsRead: 2,
    senseProgressStored: 1,
    reviewEventsStored: 1,
    wordProgressStored: 1,
    issues: 2,
  });

  const database = openLocalDatabase(path, { readOnly: true });
  try {
    const report = getDatabaseReport(database);
    assert.equal(report.counts.favorites, 2);
    assert.equal(report.counts.senseProgress, 1);
    assert.equal(report.counts.reviewEvents, 1);
    assert.equal(report.counts.migrationRecords, 1);
    assert.equal(report.counts.migrationIssues, 2);

    const progress = database.prepare(`
      SELECT current_status, ease_factor, interval_days, attempts,
             independent_uses, context_ids_json
      FROM sense_progress
      WHERE profile_id = 'local-default' AND sense_id = 'sense-quedar-meet'
    `).get();
    assert.equal(progress.current_status, "known");
    assert.equal(progress.ease_factor, 2.6);
    assert.equal(progress.interval_days, 7);
    assert.equal(progress.attempts, 3);
    assert.equal(progress.independent_uses, 2);
    assert.deepEqual(JSON.parse(progress.context_ids_json), [
      "ex-quedar-meet-1",
      "ex-quedar-meet-2",
    ]);

    const profile = database.prepare(`
      SELECT speech_rate, settings_json FROM local_profiles WHERE id = 'local-default'
    `).get();
    assert.equal(profile.speech_rate, "slow");
    assert.equal(JSON.parse(profile.settings_json).v1AppVersion, "0.1.0");

    const stats = database.prepare(`
      SELECT sessions_count, answered_count, correct_count,
             recordings_count, minutes_total
      FROM profile_stats WHERE profile_id = 'local-default'
    `).get();
    assert.deepEqual({ ...stats }, {
      sessions_count: 4,
      answered_count: 9,
      correct_count: 6,
      recordings_count: 2,
      minutes_total: 31,
    });

    const migration = database.prepare(`
      SELECT status, counts_json, original_payload_json
      FROM migration_records WHERE id = ?
    `).get(result.migrationId);
    assert.equal(migration.status, "completed");
    assert.equal(migration.original_payload_json, rawPayload);
    assert.deepEqual(JSON.parse(migration.counts_json), result.counts);
  } finally {
    database.close();
  }

  const backup = openLocalDatabase(result.backupPath, { readOnly: true });
  try {
    const report = getDatabaseReport(backup);
    assert.equal(report.counts.migrationRecords, 0);
    assert.equal(report.counts.lexemes, 2);
  } finally {
    backup.close();
  }

  assert.throws(
    () =>
      migrateV1Profile({
        rawPayload,
        databasePath: path,
        backupDirectory,
        timezone: "Europe/Madrid",
        now,
      }),
    (error) => error.code === "V1_ALREADY_MIGRATED",
  );
});

test("rejects an invalid V1 profile before creating or changing a database", () => {
  const path = databasePath("invalid-profile");
  assert.throws(
    () =>
      migrateV1Profile({
        rawPayload: JSON.stringify({ schemaVersion: 2 }),
        databasePath: path,
        backupDirectory: join(testRoot, "invalid-backups"),
      }),
    /schemaVersion 为 1/,
  );
  assert.equal(existsSync(path), false);
});
