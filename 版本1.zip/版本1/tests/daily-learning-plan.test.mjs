import assert from "node:assert/strict";
import test from "node:test";

import {
  createDailyLearningPlanState,
  createOrResumeDailyQueue,
  dailyPlanSummary,
  markDailyEntryCompleted,
  markEntryFamiliar,
  nextUnfinishedEntry,
  restoreFamiliarEntry,
  sanitizeDailyLearningPlanState,
  setDailyGoal,
} from "../lib/daily-learning-plan.mjs";

const options = {
  date: "2026-07-19",
  wordBookId: "a1",
  goal: 5,
  orderedEntryIds: ["uno", "dos", "tres", "cuatro", "cinco", "seis"],
};

test("daily goal accepts only 5, 10, 15 or 20", () => {
  assert.equal(setDailyGoal(createDailyLearningPlanState(), 10).dailyGoal, 10);
  assert.throws(() => setDailyGoal(createDailyLearningPlanState(), 7));
  assert.equal(sanitizeDailyLearningPlanState({ dailyGoal: 99 }).dailyGoal, 5);
});

test("daily queue is finite and never loops to the first word", () => {
  let state = createOrResumeDailyQueue(createDailyLearningPlanState(), options);
  assert.deepEqual(state.queueEntryIds, ["uno", "dos", "tres", "cuatro", "cinco"]);
  for (const entryId of state.queueEntryIds) state = markDailyEntryCompleted(state, entryId);
  assert.equal(nextUnfinishedEntry(state), null);
  assert.deepEqual(dailyPlanSummary(state), {
    goal: 5,
    available: 5,
    completed: 5,
    remaining: 0,
    isComplete: true,
  });
});

test("familiar words are cut from future queues and can be restored", () => {
  let state = createOrResumeDailyQueue(createDailyLearningPlanState(), options);
  state = markEntryFamiliar(state, "uno");
  assert.equal(nextUnfinishedEntry(state), "dos");
  const tomorrow = createOrResumeDailyQueue(state, { ...options, date: "2026-07-20" });
  assert.equal(tomorrow.queueEntryIds.includes("uno"), false);
  const restored = restoreFamiliarEntry(tomorrow, "uno");
  const nextDay = createOrResumeDailyQueue(restored, { ...options, date: "2026-07-21" });
  assert.equal(nextDay.queueEntryIds.includes("uno"), true);
});

test("same-day queue resumes completed progress instead of rebuilding", () => {
  let state = createOrResumeDailyQueue(createDailyLearningPlanState(), options);
  state = markDailyEntryCompleted(state, "uno");
  const resumed = createOrResumeDailyQueue(state, options);
  assert.equal(nextUnfinishedEntry(resumed), "dos");
  assert.deepEqual(resumed.completedEntryIds, ["uno"]);
});
