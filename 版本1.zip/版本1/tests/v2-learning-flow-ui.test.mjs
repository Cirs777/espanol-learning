import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const component = await readFile(
  new URL("../components/WordLearningFlow.tsx", import.meta.url),
  "utf8",
);
const page = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");
const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");

test("recognition card requires a four-choice answer and keeps wrong answers visible", () => {
  for (const token of [
    "第一张卡 · 词形识别",
    "请选择最接近的核心中文释义",
    "这次选择不正确，请继续选择",
    "回答正确，已展开全部核心内容",
    "后续共 {entry.senses.length} 张义项卡",
  ]) {
    assert.ok(component.includes(token), token);
  }
  assert.match(component, /wrongOptionIds\.includes\(option\.id\)/);
  assert.match(component, /disabled=\{wrong \|\| recognitionCorrect\}/);
});

test("sense flow has separate example and sense navigation plus distance-based swipe", () => {
  for (const label of ["上一条例句", "下一条例句", "上一个义项", "下一个义项"]) {
    assert.ok(component.includes(label), label);
  }
  assert.match(component, /Math\.abs\(deltaX\) >= 130/);
  assert.match(component, /moveToSense\(cardIndex \+ direction\)/);
  assert.match(component, /moveExample\(direction\)/);
  assert.match(styles, /touch-action: pan-y/);
});

test("analysis drawer exposes layered grammar and immediate practice", () => {
  for (const label of [
    "句子成分与从句",
    "动词原形、时态、语气与人称",
    "代词、冠词、性数一致、介词与语序",
    "英语与西语的关键差别",
    "常见迁移错误",
    "立即使用这个结构",
  ]) {
    assert.ok(component.includes(label), label);
  }
});

test("word completion offers all required exits and three familiarity ratings", () => {
  for (const label of [
    "不认识",
    "不熟",
    "认识",
    "返回第一张卡片",
    "复习全部义项",
    "查看收藏例句",
    "完成本词小测",
    "下一词",
  ]) {
    assert.ok(component.includes(label), label);
  }
  assert.match(page, /scheduleMemoryReview/);
  assert.match(page, /recognition_quiz_error/);
  assert.match(page, /word_learning_completion/);
});

test("new-word flow exposes a cut action and a finite daily completion state", () => {
  for (const token of [
    "斩",
    "加入熟词本",
    "onMarkFamiliar",
    "今日新词队列已结束",
    "系统不会再跳回第一个词循环",
  ]) {
    assert.ok(component.includes(token) || page.includes(token), token);
  }
  assert.match(page, /onMarkFamiliar=\{\(\) => cutFamiliarEntry\(selectedEntry\.id\)\}/);
});

test("daily goal controls expose exactly 5, 10, 15 and 20 words", () => {
  assert.ok(page.includes("每日新词计划"));
  assert.ok(page.includes("首页每日新词数量"));
  assert.match(page, /DAILY_WORD_GOALS/);
  assert.ok(styles.includes(".daily-goal-options"));
  assert.ok(styles.includes(".home-daily-goal"));
});

test("home learning respects the selected word book and never silently falls back to A1", () => {
  assert.match(page, /const preferredBook = currentWordBook && !currentWordBook\.isDevelopmentOnly\s*\? currentWordBook/);
  assert.match(page, /系统不会改学其他词书/);
  assert.match(page, /queueDate: null,[\s\S]{0,120}wordBookId: wordBook\.id/);
});

test("sense cards expose a layered phrase and grammar micro-lesson", () => {
  assert.ok(component.includes("短语与语法微课"));
  assert.match(component, /sense\.microLesson\.keyPoints/);
  assert.match(styles, /\.sense-micro-lesson/);
});

test("the primary visible actions enter the card flow instead of the legacy review page", () => {
  assert.ok(page.includes("开始单词卡片学习"));
  assert.ok(page.includes("开始语义分组学习"));
  assert.match(page, /className="button coral" onClick=\{startCardLearning\}/);
  assert.doesNotMatch(page, /开始今日学习[\s\S]{0,120}navigate\("review"\)/);
  for (const label of ["四选一识别", "义项独立成卡", "双层切换", "分别安排复习"]) {
    assert.ok(page.includes(label), label);
  }
});

test("A1 overview supports semantic ordering and pre-cutting simple words", () => {
  for (const token of [
    "按语义对比学习，不按字母排序",
    "过于简单？可在学习前直接“斩”",
    "a1SemanticPlan.units.map",
    "toggleOverviewFamiliar",
  ]) {
    assert.ok(page.includes(token), token);
  }
  assert.match(styles, /\.semantic-unit-list/);
  assert.match(styles, /\.simple-word-list/);
});

test("review reuses the full learning flow and exposes favorite examples", () => {
  assert.ok(page.includes("进入完整卡片式复习"));
  assert.ok(page.includes("本词收藏例句"));
  assert.match(page, /openEntry\(reviewItem\.entry, reviewItem\.sense\.id, "review"\)/);
  assert.match(component, /mode === "review"/);
  assert.match(component, /favoriteExamples/);
});

test("favorite examples open analysis and non-target words are interactive", () => {
  assert.match(page, /setSelectedExampleStudy\(\{ entry, sense, example \}\)/);
  assert.match(page, /<ExampleStudyDialog/);
  assert.match(component, /<InteractiveSpanishText/);
  assert.match(component, /onWordClick=\{onWordClick\}/);
  assert.match(styles, /\.context-word-token/);
});

test("each sense has an independent three-state schedule and the word has a context quiz", () => {
  for (const token of [
    "当前义项独立记录",
    "不会替其他义项自动评分",
    "onRateSense",
    "senseMemories",
    "本词小测 · 根据新例句辨认义项",
    "这个义项不符合语境，请继续选择",
  ]) {
    assert.ok(component.includes(token) || page.includes(token), token);
  }
  assert.match(page, /const memoryKey = `sense:\$\{senseId\}`/);
  assert.match(page, /source: "sense_card_rating"/);
});

test("mobile flow uses single-column content and 44px or larger controls", () => {
  assert.match(styles, /@media \(max-width: 760px\)/);
  assert.match(styles, /\.meaning-options,[\s\S]*?grid-template-columns: 1fr/);
  assert.match(styles, /\.flow-close[\s\S]*?width: 42px/);
  assert.match(styles, /\.large-navigation button[\s\S]*?min-height: 48px/);
  assert.match(styles, /\.analysis-drawer[\s\S]*?height: 94%/);
  assert.match(styles, /\.sense-memory-actions button[\s\S]*?min-height: 48px/);
  assert.match(styles, /\.word-check-panel > div[\s\S]*?grid-template-columns: 1fr/);
});
