import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

import { expandContentPack } from "../lib/content-pack.mjs";
import { auditContentPack } from "../lib/content-quality.mjs";

const source = JSON.parse(await readFile(new URL("../data/a2-core-content-source.json", import.meta.url), "utf8"));
const plan = JSON.parse(await readFile(new URL("../data/a2-semantic-plan.json", import.meta.url), "utf8"));
const catalog = JSON.parse(await readFile(new URL("../data/wordbooks.json", import.meta.url), "utf8"));
const content = expandContentPack(source);

test("A2 first batch supplies ten distinct words in semantic-pair order", () => {
  const order = plan.units.flatMap((unit) => unit.entryIds);
  const wordBook = catalog.wordBooks.find((candidate) => candidate.id === "wordbook-a2-core");
  assert.equal(content.entries.length, 10);
  assert.deepEqual(content.entries.map((entry) => entry.id), order);
  assert.deepEqual(wordBook.readyEntryIds, order);
});

test("A2 content has comprehensive cards, four long examples per sense and micro-lessons", () => {
  const report = auditContentPack(source);
  assert.equal(report.valid, true, report.errors.join("\n"));
  assert.deepEqual(report.counts, { entries: 10, senses: 20, examples: 80 });
  assert.equal(report.warnings.filter((warning) => warning.includes("扩充到至少")).length, 0);
  for (const entry of content.entries) {
    assert.equal(entry.recognitionOptions.length, 4);
    assert.ok(entry.importantPhrases.length >= 6);
    for (const sense of entry.senses) {
      assert.ok(sense.microLesson?.body);
      assert.ok(sense.microLesson?.keyPoints.length >= 3);
      assert.equal(sense.examples.length, 4);
      assert.ok(sense.examples.every((example) => example.analysis.microExercise.prompt));
    }
  }
});

test("A2 queue IDs resolve to the A2 index even when a lexeme is shared with A1", async () => {
  const index = JSON.parse(await readFile(new URL("../data/indexes/a2-elelex-core.json", import.meta.url), "utf8"));
  const indexed = new Set(index.entries.map((entry) => entry.id));
  assert.ok(plan.units.flatMap((unit) => unit.entryIds).every((entryId) => indexed.has(entryId)));
});
