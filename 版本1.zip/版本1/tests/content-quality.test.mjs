import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

import { auditContentPack } from "../lib/content-quality.mjs";

const pack = JSON.parse(await readFile(new URL("../data/a1-core-content-source.json", import.meta.url), "utf8"));

test("complete learning content passes mandatory structure and example checks", () => {
  const report = auditContentPack(pack);
  assert.equal(report.valid, true, report.errors.join("\n"));
  assert.equal(report.counts.entries, 10);
  assert.equal(report.counts.examples, 80);
  assert.ok(report.warnings.some((warning) => warning.includes("母语教师终审")));
});

test("quality audit rejects short or incomplete generated content", () => {
  const broken = structuredClone(pack);
  broken.entries[0].senses[0].examples = broken.entries[0].senses[0].examples.slice(0, 2);
  const report = auditContentPack(broken);
  assert.equal(report.valid, false);
  assert.ok(report.errors.some((error) => error.includes("例句少于 4 条")));
});
