import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const page = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");
const css = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");
const manifest = JSON.parse(await readFile(new URL("../public/manifest.webmanifest", import.meta.url), "utf8"));

test("cutting a new word animates it out before it enters the familiar book", () => {
  assert.match(page, /setCuttingEntryIds/);
  assert.match(page, /markEntryFamiliar\(current, entryId\)/);
  assert.match(page, /if \(familiar && !cutting\) return null/);
  assert.match(css, /@keyframes cut-to-familiar/);
  assert.match(css, /\.a1-index-list article\.cutting/);
});

test("each word book opens in an independent modal instead of an inline footer", () => {
  assert.match(page, /openWordBookOverview\(wordBook\)/);
  assert.match(page, /className="wordbook-modal-backdrop"/);
  assert.match(page, /role="dialog"/);
  assert.match(css, /\.wordbook-modal \{/);
});

test("mobile web app manifest meets the core install icon requirements", () => {
  assert.equal(manifest.display, "standalone");
  assert.equal(manifest.prefer_related_applications, false);
  assert.ok(manifest.icons.some((icon) => icon.sizes === "192x192" && icon.type === "image/png"));
  assert.ok(manifest.icons.some((icon) => icon.sizes === "512x512" && icon.type === "image/png"));
  assert.ok(manifest.icons.some((icon) => icon.purpose === "maskable"));
});
