import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { test } from "node:test";
import { join } from "node:path";

import {
  activateWordBook,
  createWordBookState,
  deriveWordBookStats,
  filterWordBookEntries,
  resetWordBookProgress,
  sanitizeWordBookState,
  toggleWordBookPaused,
} from "../lib/wordbook-progress.mjs";
import { projectRoot } from "../db/local/database.mjs";

const catalog = JSON.parse(
  readFileSync(join(projectRoot, "data", "wordbooks.json"), "utf8"),
);
const content = JSON.parse(
  readFileSync(join(projectRoot, "data", "demo-content.json"), "utf8"),
);
const a1Source = JSON.parse(
  readFileSync(join(projectRoot, "data", "a1-core-content-source.json"), "utf8"),
);
const a2Source = JSON.parse(
  readFileSync(join(projectRoot, "data", "a2-core-content-source.json"), "utf8"),
);

test("word book catalog exposes honest A1, A2 and B1 entries plus planned expansion", () => {
  const ids = catalog.wordBooks.map((wordBook) => wordBook.id);
  assert.equal(new Set(ids).size, ids.length, "word book IDs must be unique");

  for (const level of ["A1", "A2", "B1"]) {
    const wordBook = catalog.wordBooks.find(
      (candidate) => candidate.level === level && !candidate.isDevelopmentOnly,
    );
    assert.ok(wordBook, `${level} word book must exist`);
    assert.equal(wordBook.isEnabled, true);
    assert.equal(wordBook.entryIds.length, level === "B1" ? 0 : 10, "only completed content-layer memberships may be enabled");
    assert.equal(wordBook.readyEntryIds.length, level === "B1" ? 0 : 10);
    assert.equal(
      wordBook.contentStatus,
      level === "A1"
        ? "partial_content_ready"
        : level === "A2"
          ? "partial_content_ready"
          : "source_pending",
    );
    if (level === "A1") {
      assert.equal(wordBook.indexedEntryCount, 835);
      assert.equal(wordBook.indexFile, "data/indexes/a1-elelex-core.json");
    }
    if (level === "A2") {
      assert.equal(wordBook.indexedEntryCount, 1775);
      assert.equal(wordBook.indexFile, "data/indexes/a2-elelex-core.json");
    }
  }

  const plannedNames = new Set(
    catalog.wordBooks.filter((wordBook) => !wordBook.isEnabled).map((wordBook) => wordBook.name),
  );
  for (const name of [
    "B2 深入交流",
    "C1 高阶运用",
    "C2 精准表达",
    "西班牙生活高频词",
    "校园与交换学习",
    "旅行西语",
    "学术活动西语",
    "DELE 主题词汇",
    "用户自定义词书",
  ]) {
    assert.ok(plannedNames.has(name), `${name} must be reserved`);
  }
});

test("all memberships resolve to shared entries and ready entries are a subset", () => {
  const entryIds = new Set([...content.entries, ...a1Source.entries, ...a2Source.entries].map((entry) => entry.id));
  for (const wordBook of catalog.wordBooks) {
    for (const entryId of wordBook.entryIds) {
      assert.ok(entryIds.has(entryId), `${entryId} must resolve to one global entry`);
    }
    for (const readyEntryId of wordBook.readyEntryIds) {
      assert.ok(wordBook.entryIds.includes(readyEntryId));
    }
  }

  const development = catalog.wordBooks.find(
    (wordBook) => wordBook.id === "wordbook-v1-development",
  );
  assert.deepEqual(development.entryIds, ["entry-quedar", "entry-llevar"]);
  assert.deepEqual(development.readyEntryIds, []);
});

test("switching, pausing and resetting one word book preserves the others", () => {
  const ids = catalog.wordBooks.map((wordBook) => wordBook.id);
  const initial = createWordBookState(ids);
  const withA1 = activateWordBook(initial, "wordbook-a1-core");
  withA1.progress["wordbook-a1-core"] = {
    ...withA1.progress["wordbook-a1-core"],
    currentPosition: 7,
    learnedLexemeIds: ["entry-test"],
  };
  const withA2 = activateWordBook(withA1, "wordbook-a2-core");

  assert.equal(withA2.currentWordBookId, "wordbook-a2-core");
  assert.equal(withA2.progress["wordbook-a1-core"].currentPosition, 7);
  assert.deepEqual(withA2.progress["wordbook-a1-core"].learnedLexemeIds, ["entry-test"]);

  const paused = toggleWordBookPaused(withA2, "wordbook-a2-core");
  assert.equal(paused.progress["wordbook-a2-core"].state, "paused");
  const resumed = toggleWordBookPaused(paused, "wordbook-a2-core");
  assert.equal(resumed.progress["wordbook-a2-core"].state, "active");

  const reset = resetWordBookProgress(resumed, "wordbook-a1-core");
  assert.equal(reset.progress["wordbook-a1-core"].currentPosition, 0);
  assert.deepEqual(reset.progress["wordbook-a1-core"].learnedLexemeIds, []);
  assert.equal(reset.currentWordBookId, "wordbook-a2-core");
  assert.equal(reset.progress["wordbook-a2-core"].state, "active");
});

test("saved word book state is sanitized and missing future books are added safely", () => {
  const ids = catalog.wordBooks.map((wordBook) => wordBook.id);
  const restored = sanitizeWordBookState(
    {
      currentWordBookId: "not-a-real-book",
      progress: {
        "wordbook-a1-core": {
          state: "invalid",
          currentPosition: -4,
          learnedLexemeIds: ["entry-a", "entry-a", 17],
          masteredLexemeIds: null,
          lastStudiedAt: 45,
        },
      },
    },
    ids,
  );

  assert.equal(restored.currentWordBookId, null);
  assert.equal(restored.progress["wordbook-a1-core"].state, "not_started");
  assert.equal(restored.progress["wordbook-a1-core"].currentPosition, 0);
  assert.deepEqual(restored.progress["wordbook-a1-core"].learnedLexemeIds, ["entry-a"]);
  assert.ok(restored.progress["wordbook-b1-core"]);
});

test("word book statistics and search are derived from global progress", () => {
  const development = catalog.wordBooks.find(
    (wordBook) => wordBook.id === "wordbook-v1-development",
  );
  const reviewState = {
    "sense-quedar-meet": {
      nextReview: "2026-07-18",
      independentUses: 2,
      contexts: ["one", "two"],
    },
    "sense-quedar-fit": {
      nextReview: "2026-07-30",
      independentUses: 2,
      contexts: ["three", "four"],
    },
  };
  const stats = deriveWordBookStats(
    development,
    content.entries,
    reviewState,
    "2026-07-18",
  );
  assert.deepEqual(stats, {
    indexed: 2,
    ready: 0,
    learned: 1,
    mastered: 1,
    due: 1,
    progressPercent: 50,
  });

  assert.deepEqual(
    filterWordBookEntries(development, content.entries, reviewState, {
      query: "约定",
      status: "learned",
      today: "2026-07-18",
    }).map((entry) => entry.lemma),
    ["quedar"],
  );
  assert.deepEqual(
    filterWordBookEntries(development, content.entries, reviewState, {
      status: "unlearned",
      today: "2026-07-18",
    }).map((entry) => entry.lemma),
    ["llevar"],
  );
});
