import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

import { buildA1CoreIndex, isA1CoreCandidate } from "../lib/elelex-a1.mjs";

const sample = `"word"\t"tag"\t"level_freq@a1"\t"level_freq@a2"\t"level_freq@b1"\t"level_freq@b2"\t"level_freq@c1"\t"total_freq@total"\t"nb_doc@a1"\t"nb_doc@a2"\t"nb_doc@b1"\t"nb_doc@b2"\t"nb_doc@c1"\t"nb_doc@total"
"como"\t"CS"\t"100"\t"0"\t"0"\t"0"\t"0"\t"110"\t"8"\t"0"\t"0"\t"0"\t"0"\t"8"
"como"\t"RG"\t"80"\t"0"\t"0"\t"0"\t"0"\t"90"\t"7"\t"0"\t"0"\t"0"\t"0"\t"7"
"madrid"\t"NP*"\t"90"\t"0"\t"0"\t"0"\t"0"\t"100"\t"9"\t"0"\t"0"\t"0"\t"0"\t"9"
"poco_frecuente"\t"AQ0"\t"20"\t"0"\t"0"\t"0"\t"0"\t"30"\t"6"\t"0"\t"0"\t"0"\t"0"\t"6"
"raro"\t"AQ0"\t"10"\t"0"\t"0"\t"0"\t"0"\t"20"\t"2"\t"0"\t"0"\t"0"\t"0"\t"2"`;

test("A1 core filter excludes proper names, multiword rows and weak evidence", () => {
  assert.equal(isA1CoreCandidate({ word: "casa", tag: "NCF", "nb_doc@a1": "5" }), true);
  assert.equal(isA1CoreCandidate({ word: "Madrid", tag: "NP*", "nb_doc@a1": "20" }), false);
  assert.equal(isA1CoreCandidate({ word: "a_casa", tag: "RG", "nb_doc@a1": "20" }), false);
  assert.equal(isA1CoreCandidate({ word: "raro", tag: "AQ0", "nb_doc@a1": "2" }), false);
});

test("same written form keeps multiple parts of speech in one index entry", () => {
  const index = buildA1CoreIndex(sample);
  assert.equal(index.meta.indexedLexemes, 1);
  assert.deepEqual(index.entries[0].partsOfSpeech, ["adverb", "conjunction"]);
  assert.deepEqual(index.entries[0].sourceTags, ["CS", "RG"]);
  assert.equal(index.entries[0].a1Frequency, 180);
  assert.equal(index.entries[0].priorityRank, 1);
  assert.equal(index.entries[0].contentStatus, "index_only");
});

test("committed A1 index is reproducible, unique and honestly marked index-only", async () => {
  const index = JSON.parse(
    await readFile(new URL("../data/indexes/a1-elelex-core.json", import.meta.url), "utf8"),
  );
  assert.equal(index.meta.indexedLexemes, 835);
  assert.equal(index.meta.contentReadyLexemes, 10);
  assert.equal(index.meta.license, "CC BY-NC-SA 4.0");
  assert.equal(index.entries.length, 835);
  assert.equal(new Set(index.entries.map((entry) => entry.lemma)).size, 835);
  assert.ok(index.entries.every((entry) => entry.a1DocumentCount >= 5));
  assert.ok(index.entries.every((entry) => entry.contentStatus === "index_only"));
  assert.deepEqual(index.entries.map((entry) => entry.priorityRank),
    Array.from({ length: 835 }, (_, indexValue) => indexValue + 1));
});
