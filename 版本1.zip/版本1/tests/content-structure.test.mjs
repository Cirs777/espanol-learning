import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const content = JSON.parse(
  await readFile(new URL("../data/demo-content.json", import.meta.url), "utf8"),
);

test("demo content keeps program and learning data separated", () => {
  assert.equal(content.meta.reviewStatus, "development_test_only");
  assert.ok(content.entries.length >= 2);
  assert.ok(content.exercises.length >= 2);
});

test("every demo entry has independently addressable senses and examples", () => {
  for (const entry of content.entries) {
    assert.ok(entry.id);
    assert.ok(entry.senses.length >= 2);
    assert.equal(entry.recognitionOptions.length, 4);
    assert.equal(entry.recognitionOptions.filter((option) => option.correct).length, 1);
    assert.ok(entry.forms.length >= 3);
    assert.ok(entry.importantPhrases.length >= 3);
    assert.ok(entry.patterns.length >= 2);
    for (const sense of entry.senses) {
      assert.ok(sense.id);
      assert.ok(sense.cardLabel);
      assert.ok(sense.definitionEs);
      assert.ok(sense.usageScenes.length);
      assert.ok(sense.prepositionNote);
      assert.ok(sense.chunks.length);
      assert.ok(sense.grammarTags.length);
      assert.ok(sense.examples.length >= 4);
      for (const example of sense.examples) {
        assert.ok(example.id);
        assert.ok(example.sourceType);
        assert.ok(example.reviewStatus);
        assert.ok(example.framework);
        assert.ok(example.grammar.length);
        assert.ok(example.analysis.sentenceParts.length);
        assert.ok(example.analysis.verbInfo);
        assert.ok(example.analysis.functionNotes.length);
        assert.ok(example.analysis.chunks.length);
        assert.ok(example.analysis.englishContrast);
        assert.ok(example.analysis.transferError);
        assert.ok(example.analysis.extraVocabulary.length);
        assert.ok(example.analysis.microExercise.prompt);
        assert.ok(example.analysis.microExercise.answer);
      }
    }
  }
});

test("exercise answers are stored as acceptable variants", () => {
  for (const exercise of content.exercises) {
    assert.ok(exercise.senseId);
    assert.ok(Array.isArray(exercise.answers));
    assert.ok(exercise.answers.length >= 1);
    assert.ok(exercise.feedback);
  }
});
