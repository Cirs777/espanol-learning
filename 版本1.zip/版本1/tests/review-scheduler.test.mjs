import assert from "node:assert/strict";
import test from "node:test";

import {
  addCalendarDays,
  createMemoryRecord,
  dateKeyInTimeZone,
  getDueShortTermItems,
  sanitizeMemoryRecord,
  scheduleMemoryReview,
} from "../lib/review-scheduler.mjs";

const now = new Date("2026-07-18T10:00:00.000Z");

test("unknown schedules 1 and 5 minute repetitions and resets long-term review", () => {
  const prior = { ...createMemoryRecord(), intervalDays: 20, easeFactor: 2.5, knownStreak: 4 };
  const next = scheduleMemoryReview(prior, "unknown", {
    now,
    timeZone: "Europe/Madrid",
    recognitionErrors: 2,
    reactionMs: 4300,
  });
  assert.equal(next.status, "unknown");
  assert.equal(next.intervalDays, 1);
  assert.equal(next.nextReviewDate, "2026-07-19");
  assert.deepEqual(next.shortTermDueAt, [
    "2026-07-18T10:01:00.000Z",
    "2026-07-18T10:05:00.000Z",
  ]);
  assert.equal(next.easeFactor, 2.3);
  assert.equal(next.knownStreak, 0);
  assert.equal(next.failureStreak, 1);
  assert.equal(next.recognitionErrors, 2);
});

test("unfamiliar returns later today without a large interval jump", () => {
  const prior = { ...createMemoryRecord(), intervalDays: 4, easeFactor: 2.5 };
  const next = scheduleMemoryReview(prior, "unfamiliar", { now, timeZone: "Europe/Madrid" });
  assert.equal(next.intervalDays, 5);
  assert.equal(next.nextReviewDate, "2026-07-23");
  assert.deepEqual(next.shortTermDueAt, ["2026-07-18T10:12:00.000Z"]);
  assert.equal(next.easeFactor, 2.4);
});

test("known expands through 1, 3, 8 and 20 day reference intervals", () => {
  let record = createMemoryRecord();
  const intervals = [];
  for (let index = 0; index < 4; index += 1) {
    record = scheduleMemoryReview(record, "known", {
      now: new Date(now.getTime() + index * 86_400_000),
      timeZone: "Europe/Madrid",
    });
    intervals.push(record.intervalDays);
  }
  assert.deepEqual(intervals, [1, 3, 8, 20]);
  assert.equal(record.knownStreak, 4);
  assert.equal(record.failureStreak, 0);
});

test("known after an in-session recognition error preserves reset repetitions", () => {
  const failed = scheduleMemoryReview(createMemoryRecord(), "unknown", { now });
  const relearned = scheduleMemoryReview(failed, "known", {
    now: new Date("2026-07-18T10:00:30.000Z"),
    preserveReset: true,
  });
  assert.equal(relearned.status, "known");
  assert.equal(relearned.intervalDays, 1);
  assert.equal(relearned.nextReviewDate, "2026-07-19");
  assert.deepEqual(relearned.shortTermDueAt, failed.shortTermDueAt);
  assert.equal(relearned.failureStreak, 1);
});

test("different entries remain independent and due queue uses exact timestamps", () => {
  const unknown = scheduleMemoryReview(createMemoryRecord(), "unknown", { now });
  const known = scheduleMemoryReview(createMemoryRecord(), "known", { now });
  const state = { "entry-quedar": unknown, "entry-llevar": known };
  assert.deepEqual(
    getDueShortTermItems(state, new Date("2026-07-18T10:01:01.000Z")),
    ["entry-quedar"],
  );
  assert.equal(state["entry-llevar"].shortTermDueAt.length, 0);
});

test("different senses of the same word keep independent familiarity schedules", () => {
  const meetSense = scheduleMemoryReview(createMemoryRecord(), "known", { now });
  const fitSense = scheduleMemoryReview(createMemoryRecord(), "unknown", { now });
  const state = {
    "sense:sense-quedar-meet": meetSense,
    "sense:sense-quedar-fit": fitSense,
  };
  assert.equal(state["sense:sense-quedar-meet"].status, "known");
  assert.equal(state["sense:sense-quedar-meet"].intervalDays, 1);
  assert.equal(state["sense:sense-quedar-fit"].status, "unknown");
  assert.deepEqual(state["sense:sense-quedar-fit"].shortTermDueAt, [
    "2026-07-18T10:01:00.000Z",
    "2026-07-18T10:05:00.000Z",
  ]);
});

test("calendar dates remain correct across time zones and invalid saved data is cleaned", () => {
  assert.equal(dateKeyInTimeZone(new Date("2026-07-18T23:30:00.000Z"), "Asia/Shanghai"), "2026-07-19");
  assert.equal(addCalendarDays("2026-12-31", 1), "2027-01-01");
  const clean = sanitizeMemoryRecord({
    status: "broken",
    easeFactor: -8,
    intervalDays: -3,
    shortTermDueAt: ["not-a-date", "2026-07-18T10:01:00.000Z"],
  });
  assert.equal(clean.status, "not_started");
  assert.equal(clean.easeFactor, 1.3);
  assert.equal(clean.intervalDays, 0);
  assert.deepEqual(clean.shortTermDueAt, ["2026-07-18T10:01:00.000Z"]);
});
