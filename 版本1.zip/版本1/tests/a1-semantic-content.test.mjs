import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

import { expandContentPack } from "../lib/content-pack.mjs";

const source = JSON.parse(
  await readFile(new URL("../data/a1-core-content-source.json", import.meta.url), "utf8"),
);
const plan = JSON.parse(
  await readFile(new URL("../data/a1-semantic-plan.json", import.meta.url), "utf8"),
);
const catalog = JSON.parse(
  await readFile(new URL("../data/wordbooks.json", import.meta.url), "utf8"),
);
const content = expandContentPack(source);

test("A1 first batch supplies ten complete words in semantic-pair order", () => {
  const semanticOrder = plan.units.flatMap((unit) => unit.entryIds);
  const a1Book = catalog.wordBooks.find((wordBook) => wordBook.id === "wordbook-a1-core");
  assert.equal(content.entries.length, 10);
  assert.deepEqual(content.entries.map((entry) => entry.id), semanticOrder);
  assert.deepEqual(a1Book.entryIds, semanticOrder);
  assert.deepEqual(a1Book.readyEntryIds, semanticOrder);
  assert.deepEqual(semanticOrder, [
    "a1-ser", "a1-estar", "a1-tener", "a1-haber", "a1-ir",
    "a1-venir", "a1-entrar", "a1-salir", "a1-ver", "a1-mirar",
  ]);
});

test("each A1 sense has at least four selected examples and complete study fields", () => {
  const senses = content.entries.flatMap((entry) => entry.senses);
  const examples = senses.flatMap((sense) => sense.examples);
  assert.equal(senses.length, 20);
  assert.equal(examples.length, 80);
  for (const entry of content.entries) {
    assert.equal(entry.recognitionOptions.length, 4);
    assert.equal(entry.recognitionOptions.filter((option) => option.correct).length, 1);
    assert.ok(entry.forms.length >= 3);
    assert.ok(entry.importantPhrases.length >= 5);
    assert.ok(entry.lookupForms.length >= 2);
    for (const sense of entry.senses) {
      assert.ok(sense.examples.length >= 4, `${sense.id} must have four examples`);
      assert.ok(sense.definitionEs);
      assert.ok(sense.definitionEn);
      assert.ok(sense.chunks.length >= 3);
      for (const example of sense.examples) {
        assert.ok(example.analysis.sentenceParts.length >= 2);
        assert.ok(example.analysis.verbInfo);
        assert.ok(example.analysis.functionNotes.length >= 1);
        assert.ok(example.analysis.extraVocabulary.length >= 1);
        assert.ok(example.analysis.microExercise.prompt);
        assert.ok(example.analysis.microExercise.answer);
        assert.match(example.sourceType, /项目自建/);
        assert.match(example.reviewStatus, /待母语教师终审/);
      }
    }
  }
  assert.equal(new Set(examples.map((example) => example.id)).size, examples.length);
});

test("simple function words can be pre-cut without entering the ready queue", () => {
  assert.ok(plan.simpleFunctionWords.includes("a1-a"));
  assert.ok(plan.simpleFunctionWords.includes("a1-en"));
  const readyIds = new Set(content.entries.map((entry) => entry.id));
  assert.ok(plan.simpleFunctionWords.every((entryId) => !readyIds.has(entryId)));
});
