import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

import { buildElelexLevelIndex } from "../lib/elelex-level.mjs";

const a1 = JSON.parse(await readFile(new URL("../data/indexes/a1-elelex-core.json", import.meta.url), "utf8"));
const a2 = JSON.parse(await readFile(new URL("../data/indexes/a2-elelex-core.json", import.meta.url), "utf8"));

test("A2 index is imported from ELELex and shares existing A1 lexeme IDs", () => {
  assert.equal(a2.meta.level, "A2");
  assert.equal(a2.meta.indexedLexemes, 1775);
  assert.equal(a2.meta.sharedLexemes, 779);
  assert.equal(new Set(a2.entries.map((entry) => entry.id)).size, a2.entries.length);
  const a1ByLemma = new Map(a1.entries.map((entry) => [entry.lemma, entry.id]));
  for (const entry of a2.entries.filter((candidate) => candidate.sharedAcrossWordBooks).slice(0, 50)) {
    assert.equal(entry.id, a1ByLemma.get(entry.lemma));
  }
});

test("accented and unaccented lexemes keep distinct stable IDs", () => {
  const pairs = [["el", "él"], ["mi", "mí"], ["si", "sí"], ["te", "té"], ["sonar", "soñar"]];
  const byLemma = new Map(a2.entries.map((entry) => [entry.lemma, entry.id]));
  for (const [plain, accented] of pairs) {
    assert.notEqual(byLemma.get(plain), byLemma.get(accented));
  }
});

test("generic level importer rejects weak rows and merges parts of speech", () => {
  const fixture = [
    '"word"\t"tag"\t"level_freq@a2"\t"nb_doc@a2"\t"total_freq@total"',
    '"banco"\t"NC"\t"20"\t"8"\t"50"',
    '"banco"\t"VMI"\t"4"\t"6"\t"10"',
    '"Rita"\t"NP"\t"30"\t"9"\t"30"',
    '"débil"\t"AQ"\t"1"\t"2"\t"3"',
  ].join("\n");
  const index = buildElelexLevelIndex(fixture, { level: "A2", minimumDocuments: 5 });
  assert.equal(index.entries.length, 1);
  assert.deepEqual(index.entries[0].partsOfSpeech, ["noun", "verb"]);
});
