import { readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";

import { buildElelexLevelIndex } from "../lib/elelex-level.mjs";

function argument(name, fallback) {
  const index = process.argv.indexOf(name);
  return index >= 0 ? process.argv[index + 1] : fallback;
}

const level = argument("--level", "A2").toUpperCase();
const input = resolve(argument("--input", "imports/ELELex.tsv"));
const output = resolve(argument("--output", `data/indexes/${level.toLowerCase()}-elelex-core.json`));
const sharedIndexPath = resolve(argument("--shared-index", "data/indexes/a1-elelex-core.json"));
const minimumDocuments = Number(argument("--minimum-documents", "5"));

if (!Number.isInteger(minimumDocuments) || minimumDocuments < 1) {
  throw new Error("--minimum-documents must be a positive integer");
}

const [tsv, sharedIndex] = await Promise.all([
  readFile(input, "utf8"),
  readFile(sharedIndexPath, "utf8").then(JSON.parse).catch(() => ({ entries: [] })),
]);
const index = buildElelexLevelIndex(tsv, {
  level,
  minimumDocuments,
  sharedEntries: sharedIndex.entries,
});
await writeFile(output, `${JSON.stringify(index, null, 2)}\n`, "utf8");
console.log(JSON.stringify({
  output,
  level,
  indexedLexemes: index.meta.indexedLexemes,
  sharedLexemes: index.meta.sharedLexemes,
  minimumDocuments,
}, null, 2));
