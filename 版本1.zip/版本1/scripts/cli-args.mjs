export function parseNamedArguments(values) {
  const result = {};
  for (let index = 0; index < values.length; index += 1) {
    const token = values[index];
    if (!token.startsWith("--")) {
      throw new Error(`无法识别参数：${token}`);
    }
    const key = token.slice(2);
    const value = values[index + 1];
    if (!value || value.startsWith("--")) {
      throw new Error(`参数 --${key} 缺少值`);
    }
    result[key] = value;
    index += 1;
  }
  return result;
}

export function formatPathForDisplay(value) {
  return value.replaceAll("\\", "/");
}
