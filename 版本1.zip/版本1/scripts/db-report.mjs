import { existsSync } from "node:fs";

import {
  defaultDatabasePath,
  getDatabaseReport,
  openLocalDatabase,
  resolveProjectPath,
} from "../db/local/database.mjs";
import { formatPathForDisplay, parseNamedArguments } from "./cli-args.mjs";

try {
  const args = parseNamedArguments(process.argv.slice(2));
  const databasePath = resolveProjectPath(args.database, defaultDatabasePath);
  if (!existsSync(databasePath)) {
    throw new Error("数据库不存在，请先执行 npm run db:init");
  }
  const database = openLocalDatabase(databasePath, { readOnly: true });
  try {
    const report = getDatabaseReport(database);
    console.log(`数据库：${formatPathForDisplay(databasePath)}`);
    console.log(JSON.stringify(report, null, 2));
  } finally {
    database.close();
  }
} catch (error) {
  console.error(`读取数据库报告失败：${error.message}`);
  process.exitCode = 1;
}
