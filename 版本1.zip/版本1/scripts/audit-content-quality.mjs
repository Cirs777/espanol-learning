import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

import { auditContentPack } from "../lib/content-quality.mjs";

const input = resolve(process.argv[2] ?? "data/a1-core-content-source.json");
const pack = JSON.parse(await readFile(input, "utf8"));
const report = auditContentPack(pack);
console.log(JSON.stringify({ input, ...report }, null, 2));
if (!report.valid) process.exitCode = 1;
