import { initializeLocalDatabase } from "../db/local/bootstrap.mjs";
import { parseNamedArguments, formatPathForDisplay } from "./cli-args.mjs";

try {
  const args = parseNamedArguments(process.argv.slice(2));
  const result = initializeLocalDatabase({
    databasePath: args.database,
    timezone: args.timezone,
  });
  console.log("Contexto V2 本地数据库已准备完成。\n");
  console.log(`数据库：${formatPathForDisplay(result.databasePath)}`);
  console.log(`数据表：${result.report.tableCount}`);
  console.log(`迁移：${result.appliedMigrations.length ? result.appliedMigrations.join(", ") : "无需新增迁移"}`);
  console.log(
    `第一版测试内容：${result.report.counts.lexemes} 词条、${result.report.counts.senses} 义项、${result.report.counts.examples} 例句`,
  );
  console.log("说明：第一版测试内容尚未达到正式学习开放标准。下一阶段将建立 A1/A2/B1 词书。");
} catch (error) {
  console.error(`数据库初始化失败：${error.message}`);
  process.exitCode = 1;
}
