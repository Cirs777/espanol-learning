import { readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";

import { buildA1CoreIndex } from "../lib/elelex-a1.mjs";

function argument(name, fallback) {
  const index = process.argv.indexOf(name);
  return index >= 0 ? process.argv[index + 1] : fallback;
}

const input = resolve(argument("--input", "imports/ELELex.tsv"));
const output = resolve(argument("--output", "data/indexes/a1-elelex-core.json"));
const minimumDocuments = Number(argument("--minimum-documents", "5"));
const contentReadyLexemes = Number(argument("--content-ready", "0"));

if (!Number.isInteger(minimumDocuments) || minimumDocuments < 1) {
  throw new Error("--minimum-documents must be a positive integer");
}
if (!Number.isInteger(contentReadyLexemes) || contentReadyLexemes < 0) {
  throw new Error("--content-ready must be a non-negative integer");
}

const tsv = await readFile(input, "utf8");
const index = buildA1CoreIndex(tsv, { minimumDocuments, contentReadyLexemes });
await writeFile(output, `${JSON.stringify(index, null, 2)}\n`, "utf8");
console.log(JSON.stringify({
  output,
  indexedLexemes: index.meta.indexedLexemes,
  sourceRowsObservedInA1: index.meta.sourceRowsObservedInA1,
  minimumDocuments,
}, null, 2));
