import { writeFile } from "node:fs/promises";
import { resolve } from "node:path";

const meta = {
  contentPackId: "contexto-a2-core-batch-001",
  title: "Contexto A2 语义行动内容包 001",
  version: "0.5.0-dev.1",
  locale: "es-ES",
  sourceType: "ai_assisted_original_learning_content",
  sourceTypeLabel: "项目自建 AI 辅助学习文本",
  reviewStatus: "internal_review_passed_native_review_pending",
  reviewStatusLabel: "结构与规则检查通过 · 待母语教师终审",
  notice: "词形索引来自 ELELex；释义、例句、微课和练习为本项目自建候选学习内容，不冒充官方、词典或影视原句。",
};

const entries = [
  {
    id: "a1-empezar", lemma: "empezar", semanticUnit: "开始与结束", summaryZh: "开始；着手做；以……开头", coreMeaningZh: "开始／着手",
    distractors: ["结束／完成", "寻找／设法获得", "回答／作出反应"], present: "empiezo · empiezas · empieza · empezamos · empezáis · empiezan", preterite: "empecé · empezaste · empezó · empezamos · empezasteis · empezaron", participle: "empezado",
    phrases: ["empezar a + 动词原形", "empezar por", "empezar con", "volver a empezar", "para empezar", "acabar de empezar"],
    patterns: ["[人] + empezar a + [行动]", "[活动] + empezar a las + [时间]", "empezar por/con + [第一步]"],
    synonyms: ["comenzar：较中性，可替换多数“开始”语境", "ponerse a：强调突然或立即着手"], antonyms: ["terminar：结束", "dejar de：停止做"], family: ["el comienzo：开端", "recién empezado：刚开始的"], contrasts: ["empezar a / empezar por：开始做某事与先从某一步开始"],
    senses: [
      {
        id: "a2-empezar-action", label: "开始做某事", definitionEs: "Iniciar una acción o comenzar a realizar una actividad.", definitionEn: "to start doing something", scenes: ["学习计划", "找房", "课堂"],
        preposition: "表示着手某行动时使用 empezar a + 动词原形；a 不能省略。", chunks: ["empezar a estudiar", "empezar a buscar piso", "volver a empezar"], grammar: ["empezar a + infinitivo", "cuando + 虚拟式表达未来", "ir a + infinitivo"],
        framework: "[人] + empezar a + [动词原形] + [时间／原因]", lessonTitle: "把“开始”连接到具体行动", lessonBody: "empezar 后面若接另一个动作，通常必须加 a。谈论未来条件时，cuando 后常用现在虚拟式，但主句可以使用将来时或 ir a。", lessonPoints: ["empezar a estudiar，不说 empezar estudiar", "volver a empezar 表示重新开始", "acabar de empezar 表示刚刚开始"],
        examples: [
          ["准备课堂展示", "Cuando termine la clase, voy a empezar a preparar la presentación con mi compañera.", "下课后，我要和同学开始准备展示。", "When class finishes, I am going to start preparing the presentation with my classmate.", ["terminar la clase：下课", "preparar la presentación：准备展示", "compañera：女同学"]],
          ["交换期间找房", "Empezamos a buscar piso con tiempo porque los alquileres suben mucho en septiembre.", "我们提前开始找房，因为九月份房租上涨很多。", "We started looking for a flat early because rents rise a lot in September.", ["con tiempo：提前", "buscar piso：找房", "subir el alquiler：房租上涨"]],
          ["建立听力习惯", "Si quieres entender conversaciones reales, empieza a escuchar diez minutos cada mañana sin subtítulos.", "如果你想听懂真实对话，就从每天早上无字幕听十分钟开始。", "If you want to understand real conversations, start listening for ten minutes every morning without subtitles.", ["conversaciones reales：真实对话", "cada mañana：每天早上", "sin subtítulos：无字幕"]],
          ["老师讲解任务", "La profesora empezó a explicar la actividad después de comprobar que todos tenían el documento.", "老师确认所有人都有文件后，开始讲解活动。", "The teacher started explaining the activity after checking that everyone had the document.", ["comprobar que：确认", "tener el documento：拿到文件", "explicar la actividad：讲解活动"]],
        ],
      },
      {
        id: "a2-empezar-event", label: "活动开始；从……开始", definitionEs: "Señalar el inicio de un evento o el primer elemento de un proceso.", definitionEn: "to begin; to start with", scenes: ["时间安排", "课程", "叙事"],
        preposition: "活动本身作主语；用 empezar por 强调第一步，用 empezar con 说明开场内容。", chunks: ["la reunión empieza", "empezar por revisar", "empezar con una pregunta"], grammar: ["无生命主语", "empezar por + infinitivo", "empezar con + nombre"],
        framework: "[活动] + empezar + [时间] / empezar por-con + [第一部分]", lessonTitle: "事件作主语时不要机械添加 se", lessonBody: "西语可以直接说 la clase empieza。por 突出步骤顺序，con 突出开场内容，两者不能在所有语境中互换。", lessonPoints: ["La clase empieza a las nueve", "Empecemos por lo más urgente", "La película empieza con una escena breve"],
        examples: [
          ["线上会议", "La reunión empieza a las nueve en punto, pero conviene conectarse cinco minutos antes.", "会议九点整开始，但最好提前五分钟上线。", "The meeting starts at nine sharp, but it is advisable to connect five minutes early.", ["en punto：整点", "conviene + infinitivo：最好", "conectarse：上线连接"]],
          ["语言课程", "El curso empieza en octubre y termina justo antes de las vacaciones de invierno.", "课程十月开始，正好在寒假前结束。", "The course begins in October and ends just before the winter holidays.", ["justo antes de：就在……之前", "vacaciones de invierno：寒假", "terminar：结束"]],
          ["处理团队问题", "Para no perder tiempo, empezaremos por revisar los errores que bloquean todo el proyecto.", "为了不浪费时间，我们先检查阻碍整个项目的错误。", "To avoid wasting time, we will start by reviewing the errors blocking the whole project.", ["perder tiempo：浪费时间", "empezar por：先从……开始", "bloquear el proyecto：阻碍项目"]],
          ["分析电影开场", "La película empieza con una escena silenciosa que presenta el conflicto sin explicarlo directamente.", "电影以一个安静的场景开头，不直接解释便呈现了冲突。", "The film begins with a silent scene that introduces the conflict without explaining it directly.", ["escena silenciosa：安静的场景", "presentar el conflicto：呈现冲突", "directamente：直接地"]],
        ],
      },
    ],
  },
  {
    id: "a1-terminar", lemma: "terminar", semanticUnit: "开始与结束", summaryZh: "结束；完成；最终变成或落到某种结果", coreMeaningZh: "结束／完成",
    distractors: ["开始／着手", "找到／遇到", "购买／付钱"], present: "termino · terminas · termina · terminamos · termináis · terminan", preterite: "terminé · terminaste · terminó · terminamos · terminasteis · terminaron", participle: "terminado",
    phrases: ["terminar de + 动词原形", "terminar con", "terminar en", "terminar por", "al terminar", "recién terminado"],
    patterns: ["[人] + terminar de + [完成的行动]", "[事情] + terminar en + [结果]", "terminar por + [最终行动]"],
    synonyms: ["acabar：常见口语近义词", "finalizar：较正式，常用于活动或程序"], antonyms: ["empezar：开始", "continuar：继续"], family: ["el término：术语／期限", "la terminación：终止"], contrasts: ["terminar de / acabar de：完成做与刚刚做完需看时态和语境"],
    senses: [
      {
        id: "a2-terminar-task", label: "结束或完成某项行动", definitionEs: "Llegar al final de una tarea, actividad o periodo.", definitionEn: "to finish or complete", scenes: ["作业", "预订", "项目"],
        preposition: "terminar de + 动词原形表示完成某动作；terminar con 可表示结束或消除某事。", chunks: ["terminar de escribir", "terminar el proyecto", "al terminar la clase"], grammar: ["terminar de + infinitivo", "al + infinitivo", "现在完成时"],
        framework: "[人] + terminar (de) + [任务／动词原形]", lessonTitle: "区分完成对象与完成动作", lessonBody: "直接接名词时说 terminar el informe；后接动作时说 terminar de escribir。al terminar 相当于 cuando termine/terminó，常用于安排先后。", lessonPoints: ["terminar el informe", "terminar de escribir", "al terminar la clase"],
        examples: [
          ["提交报告", "He terminado el informe esta mañana, pero todavía necesito revisar todas las referencias.", "我今天上午完成了报告，但仍需检查全部参考文献。", "I finished the report this morning, but I still need to check all the references.", ["todavía：仍然", "revisar las referencias：检查参考文献", "esta mañana：今天上午"]],
          ["完成线上预订", "¿Has terminado de reservar el alojamiento o quieres comparar algunas opciones más económicas?", "你订完住宿了吗，还是想再比较一些更便宜的选项？", "Have you finished booking the accommodation, or do you want to compare some cheaper options?", ["reservar alojamiento：预订住宿", "comparar opciones：比较选项", "más económico：更经济的"]],
          ["团队项目", "Terminamos el proyecto dentro del plazo porque repartimos bien las tareas desde el principio.", "我们按时完成项目，因为从一开始就合理分配了任务。", "We finished the project on time because we divided the tasks well from the beginning.", ["dentro del plazo：在期限内", "repartir tareas：分配任务", "desde el principio：从一开始"]],
          ["离开图书馆", "Antes de salir de la biblioteca, tengo que terminar de copiar estas notas importantes.", "离开图书馆前，我必须抄完这些重要笔记。", "Before leaving the library, I have to finish copying these important notes.", ["antes de salir：离开前", "copiar notas：抄笔记", "tener que：必须"]],
        ],
      },
      {
        id: "a2-terminar-result", label: "最终以某种结果结束", definitionEs: "Acabar en una situación o llegar finalmente a hacer algo.", definitionEn: "to end up; to result in", scenes: ["争论", "决定", "旅行"],
        preposition: "terminar en + 名词表示结果；terminar por + 动词原形表示经过过程后最终做了某事。", chunks: ["terminar en discusión", "terminar por aceptar", "terminar siendo"], grammar: ["terminar en + nombre", "terminar por + infinitivo", "terminar + gerundio"],
        framework: "[过程] + terminar en/por/siendo + [最终结果]", lessonTitle: "用 terminar 讲清事情如何收场", lessonBody: "en 后面通常是名词结果，por 后面是最终采取的行动；terminar siendo 强调最终呈现出的身份或性质。", lessonPoints: ["terminar en un acuerdo", "terminar por llamar", "terminar siendo útil"],
        examples: [
          ["沟通失误", "La conversación terminó en una discusión porque ninguno quiso escuchar la explicación completa.", "谈话最终变成争论，因为谁都不愿听完整解释。", "The conversation ended in an argument because neither person wanted to hear the full explanation.", ["terminar en una discusión：以争论收场", "ninguno：谁都不", "explicación completa：完整解释"]],
          ["比较房源", "Después de comparar seis pisos, terminamos por aceptar el que estaba mejor comunicado.", "比较六套房后，我们最终接受了交通最便利的那套。", "After comparing six flats, we ended up accepting the one with the best transport connections.", ["terminar por aceptar：最终接受", "estar bien comunicado：交通便利", "comparar pisos：比较房源"]],
          ["拖延的后果", "Si sigues dejando todo para mañana, terminarás trabajando deprisa durante el fin de semana.", "如果继续把事情拖到明天，你最终会在周末匆忙工作。", "If you keep putting everything off until tomorrow, you will end up working hurriedly over the weekend.", ["dejar para mañana：拖到明天", "trabajar deprisa：匆忙工作", "seguir + gerundio：继续做"]],
          ["意外收获", "El viaje terminó siendo mucho más interesante de lo que habíamos imaginado al principio.", "这次旅行最终比我们最初想象的有趣得多。", "The trip ended up being much more interesting than we had imagined at first.", ["terminar siendo：最终成为", "más de lo que：比……更", "al principio：起初"]],
        ],
      },
    ],
  },
  {
    id: "a1-buscar", lemma: "buscar", semanticUnit: "寻找与发现", summaryZh: "寻找；查找；设法获得或追求", coreMeaningZh: "寻找／寻求",
    distractors: ["找到／发现", "询问／打听", "归还／返还"], present: "busco · buscas · busca · buscamos · buscáis · buscan", preterite: "busqué · buscaste · buscó · buscamos · buscasteis · buscaron", participle: "buscado",
    phrases: ["buscar piso", "buscar trabajo", "buscar una solución", "ir a buscar", "buscar información", "buscarse la vida"],
    patterns: ["buscar + [人／物]", "buscar + [抽象目标]", "ir/venir a buscar + [对象]"],
    synonyms: ["intentar encontrar：试着找到", "procurar：设法，语体稍正式"], antonyms: ["encontrar：找到", "perder：弄丢"], family: ["la búsqueda：寻找／搜索", "buscador：搜索工具"], contrasts: ["buscar / encontrar：过程与结果"],
    senses: [
      {
        id: "a2-buscar-object", label: "寻找人、物或信息", definitionEs: "Intentar localizar a una persona, un objeto o una información.", definitionEn: "to look for or search", scenes: ["失物", "网上查资料", "接人"],
        preposition: "buscar 直接接宾语，一般不使用英语式 for；寻找特定的人时可出现人称 a。", chunks: ["buscar las llaves", "buscar información", "ir a buscar a alguien"], grammar: ["直接宾语", "人称 a", "estar buscando"],
        framework: "[人] + buscar + [对象] + [地点／目的]", lessonTitle: "不要照搬英语 look for", lessonBody: "西语 buscar 本身已经包含“寻找”，不能说 buscar por las llaves。寻找具体的人通常说 buscar a alguien。", lessonPoints: ["buscar información", "buscar las llaves", "ir a buscar a Marta"],
        examples: [
          ["车站失物", "Estoy buscando una mochila azul que dejé cerca de la máquina de billetes.", "我在找一个蓝色背包，之前放在售票机附近。", "I am looking for a blue backpack that I left near the ticket machine.", ["máquina de billetes：售票机", "dejar cerca de：放在附近", "mochila：背包"]],
          ["查课程资料", "Antes de escribir el trabajo, busqué información fiable en la página de la universidad.", "写作业前，我在大学网站查找了可靠资料。", "Before writing the assignment, I looked for reliable information on the university website.", ["información fiable：可靠信息", "página de la universidad：大学网站", "escribir el trabajo：写作业"]],
          ["机场接朋友", "Voy a buscar a Daniel al aeropuerto porque llega con dos maletas muy pesadas.", "我要去机场接丹尼尔，因为他带着两个很重的行李箱到达。", "I am going to pick Daniel up at the airport because he is arriving with two very heavy suitcases.", ["ir a buscar a alguien：去接某人", "maleta pesada：重行李箱", "llegar al aeropuerto：抵达机场"]],
          ["超市找商品", "Llevamos diez minutos buscando leche sin lactosa y todavía no encontramos ninguna marca.", "我们找无乳糖牛奶已经十分钟了，仍没找到任何牌子。", "We have been looking for lactose-free milk for ten minutes and still cannot find any brand.", ["leche sin lactosa：无乳糖牛奶", "ninguna marca：任何牌子都没有", "llevar + 时间 + gerundio：持续做"]],
        ],
      },
      {
        id: "a2-buscar-goal", label: "寻求、追求或设法达到", definitionEs: "Intentar conseguir una solución, un objetivo o una situación deseada.", definitionEn: "to seek, aim for, or try to achieve", scenes: ["工作", "解决问题", "正式沟通"],
        preposition: "buscar 可直接接 solución, trabajo, apoyo 等抽象名词；buscar que 后通常接虚拟式。", chunks: ["buscar una solución", "buscar trabajo", "buscar que todos participen"], grammar: ["抽象宾语", "buscar que + subjuntivo", "关系从句"],
        framework: "[人／机构] + buscar + [目标] / buscar que + [虚拟式]", lessonTitle: "从找东西扩展到追求目标", lessonBody: "buscar 不只表示看得见的寻找，也常与 solución、empleo、acuerdo 等抽象目标搭配。buscar que 强调希望促成的结果。", lessonPoints: ["buscar trabajo", "buscar una solución", "buscar que haya equilibrio"],
        examples: [
          ["毕业求职", "Mi hermana busca trabajo en una empresa donde pueda usar español todos los días.", "我姐姐在寻找一份能每天使用西语的公司工作。", "My sister is looking for work at a company where she can use Spanish every day.", ["buscar trabajo：找工作", "empresa：公司", "donde pueda：能在那里，虚拟式"]],
          ["解决噪音问题", "Los vecinos buscan una solución que permita descansar sin cerrar el bar definitivamente.", "邻居们在寻找一个既能休息又不必永久关闭酒吧的方案。", "The neighbors are seeking a solution that allows them to rest without permanently closing the bar.", ["permitir descansar：允许休息", "cerrar definitivamente：永久关闭", "buscar una solución：寻找方案"]],
          ["课堂合作", "La actividad busca que todos participen y comparen distintas formas de expresar una opinión.", "这项活动旨在让所有人参与并比较不同的观点表达方式。", "The activity aims for everyone to participate and compare different ways of expressing an opinion.", ["buscar que：旨在", "expresar una opinión：表达观点", "distintas formas：不同方式"]],
          ["租房谈判", "No buscamos el piso perfecto, sino uno que esté bien comunicado y sea tranquilo.", "我们不是追求完美公寓，而是寻找交通便利且安静的房子。", "We are not looking for the perfect flat, but one that is well connected and quiet.", ["no... sino...：不是……而是", "bien comunicado：交通便利", "虚拟式 esté/sea：未确定对象"]],
        ],
      },
    ],
  },
  {
    id: "a1-encontrar", lemma: "encontrar", semanticUnit: "寻找与发现", summaryZh: "找到；发现；遇见；觉得；处于某种状态", coreMeaningZh: "找到／发现",
    distractors: ["寻找／追求", "开始／着手", "支付／付出代价"], present: "encuentro · encuentras · encuentra · encontramos · encontráis · encuentran", preterite: "encontré · encontraste · encontró · encontramos · encontrasteis · encontraron", participle: "encontrado",
    phrases: ["encontrar trabajo", "encontrar una solución", "encontrarse con", "encontrarse bien", "no encontrar palabras", "volver a encontrarse"],
    patterns: ["encontrar + [对象]", "encontrar + [对象] + [评价]", "encontrarse con/en + [人／状态／地点]"],
    synonyms: ["hallar：较正式的“找到”", "descubrir：发现原先不知道的事"], antonyms: ["buscar：寻找", "perder：失去／弄丢"], family: ["el encuentro：会面／相遇", "encontrado：找到的"], contrasts: ["encontrar / encontrarse：找到某物与自己处于／碰到"],
    senses: [
      {
        id: "a2-encontrar-discover", label: "找到或发现具体、抽象对象", definitionEs: "Localizar algo buscado o descubrir una solución, dato o posibilidad.", definitionEn: "to find or discover", scenes: ["找钥匙", "路线", "解决办法"],
        preposition: "直接接宾语；encontrar + 宾语 + 形容词可表示“觉得……怎么样”。", chunks: ["encontrar las llaves", "encontrar una solución", "encontrar algo útil"], grammar: ["直接宾语代词", "结果补语", "关系从句"],
        framework: "[人] + encontrar + [对象] + [地点／评价]", lessonTitle: "encontrar 强调寻找后的结果", lessonBody: "buscar 描述过程，encontrar 描述结果。后接形容词时还可以表示对对象作出评价，如 encuentro útil esta aplicación。", lessonPoints: ["Lo encontré ayer", "encontrar una solución", "encuentro útil el curso"],
        examples: [
          ["找回钥匙", "Por fin encontré las llaves debajo del sofá, donde nadie había mirado todavía.", "我终于在沙发下面找到了钥匙，那里此前谁都没看过。", "I finally found the keys under the sofa, where nobody had looked yet.", ["por fin：终于", "debajo del sofá：沙发下面", "nadie había mirado：没人看过"]],
          ["选择交通路线", "Encontramos una ruta más rápida que evita las obras del centro de la ciudad.", "我们找到了一条更快、能避开市中心施工的路线。", "We found a faster route that avoids the roadworks in the city center.", ["ruta más rápida：更快路线", "evitar las obras：避开施工", "centro de la ciudad：市中心"]],
          ["处理行政手续", "La estudiante encontró toda la información necesaria en un apartado bastante escondido de la web.", "这名学生在网站一个很隐蔽的栏目中找到了全部必要信息。", "The student found all the necessary information in a rather hidden section of the website.", ["apartado：栏目", "bastante escondido：相当隐蔽", "información necesaria：必要信息"]],
          ["评价学习工具", "Encuentro muy útil esta aplicación porque explica los errores sin interrumpir la práctica.", "我觉得这个应用非常有用，因为它解释错误而不打断练习。", "I find this application very useful because it explains mistakes without interrupting practice.", ["encontrar útil：觉得有用", "explicar errores：解释错误", "sin interrumpir：不中断"]],
        ],
      },
      {
        id: "a2-encontrarse-state", label: "相遇；处于某地或某种状态", definitionEs: "Coincidir con alguien o hallarse en un lugar, estado o situación.", definitionEn: "to meet; to be or feel in a state", scenes: ["偶遇", "身体状态", "位置说明"],
        preposition: "encontrarse con + 人表示遇到；encontrarse en + 地点／处境；encontrarse bien/mal 表示感觉。", chunks: ["encontrarse con alguien", "encontrarse bien", "encontrarse en una situación"], grammar: ["反身代词", "con/en 搭配", "状态副词"],
        framework: "[人／物] + encontrarse + con/en/bien-mal + [补充]", lessonTitle: "反身形式改变句子的观察角度", lessonBody: "encontrarse 不再是主动找到对象，而是表示彼此相遇，或描述主体所处的位置、状态和感受。代词必须随人称变化。", lessonPoints: ["me encontré con Ana", "nos encontramos bien", "el edificio se encuentra en"],
        examples: [
          ["街头偶遇", "Ayer me encontré con una antigua compañera mientras esperaba el autobús cerca de casa.", "昨天我在家附近等公交时偶遇了一位以前的同学。", "Yesterday I ran into a former classmate while waiting for the bus near home.", ["encontrarse con：偶遇", "antigua compañera：以前的同学", "mientras esperaba：当时正在等"]],
          ["询问身体情况", "Después de descansar toda la tarde, me encuentro bastante mejor y ya puedo comer.", "休息了一下午后，我感觉好多了，也能吃东西了。", "After resting all afternoon, I feel much better and can eat now.", ["encontrarse mejor：感觉好转", "bastante：相当", "descansar：休息"]],
          ["说明办公室位置", "La oficina de atención se encuentra al fondo del pasillo, junto a los ascensores.", "服务办公室位于走廊尽头、电梯旁边。", "The service office is located at the end of the corridor, next to the lifts.", ["al fondo del pasillo：走廊尽头", "junto a：在……旁边", "oficina de atención：服务办公室"]],
          ["面对复杂处境", "Nos encontramos en una situación difícil, pero todavía podemos negociar una solución razonable.", "我们正处于困难局面，但仍可以协商合理解决方案。", "We are in a difficult situation, but we can still negotiate a reasonable solution.", ["encontrarse en una situación：处于局面", "negociar：协商", "solución razonable：合理方案"]],
        ],
      },
    ],
  },
  {
    id: "a1-preguntar", lemma: "preguntar", semanticUnit: "提问与回应", summaryZh: "提问；询问信息；打听某人或某事", coreMeaningZh: "询问／提问",
    distractors: ["回答／回应", "请求／点单", "购买／获得"], present: "pregunto · preguntas · pregunta · preguntamos · preguntáis · preguntan", preterite: "pregunté · preguntaste · preguntó · preguntamos · preguntasteis · preguntaron", participle: "preguntado",
    phrases: ["preguntar algo", "preguntar por alguien", "preguntar si", "preguntar cómo", "sin preguntar", "volver a preguntar"],
    patterns: ["preguntar + [问题] + a + [人]", "preguntar por + [人／事]", "preguntar si/cómo/cuándo + [从句]"],
    synonyms: ["consultar：咨询、查阅，通常更正式", "interrogar：盘问，不可随意替换"], antonyms: ["responder：回答", "callarse：不说话"], family: ["la pregunta：问题", "preguntón/preguntona：爱问的人"], contrasts: ["preguntar / pedir：询问信息与请求得到东西或行动"],
    senses: [
      {
        id: "a2-preguntar-information", label: "提出问题、询问信息", definitionEs: "Dirigir una pregunta a alguien para obtener información.", definitionEn: "to ask a question or ask for information", scenes: ["问路", "课堂", "办手续"],
        preposition: "询问某人用 preguntar algo a alguien；不能用 preguntar para alguien。", chunks: ["preguntar una cosa", "preguntar si", "preguntarle a la profesora"], grammar: ["间接宾语代词", "疑问从句", "重音疑问词"],
        framework: "[人] + preguntar(le) + [问题／疑问从句] + a + [对象]", lessonTitle: "把问题与被询问者分开", lessonBody: "所问内容是直接宾语，被询问者常由 a 引出并可用 le 复指。间接疑问词 cómo、cuándo、dónde 仍保留重音。", lessonPoints: ["Le pregunté la hora", "Pregunté si estaba abierto", "Pregunté cómo llegar"],
        examples: [
          ["地铁站问路", "Le pregunté a una empleada cómo podía llegar al museo sin cambiar de línea.", "我问一名工作人员怎样不换线到达博物馆。", "I asked an employee how I could reach the museum without changing lines.", ["empleada：女工作人员", "cambiar de línea：换乘线路", "cómo podía llegar：怎样能到达"]],
          ["课堂澄清", "Un estudiante preguntó si el examen incluía también los temas de la semana pasada.", "一名学生问考试是否也包含上周的主题。", "A student asked whether the exam also included last week's topics.", ["incluir：包含", "temas de la semana pasada：上周主题", "preguntar si：询问是否"]],
          ["办理居留手续", "Antes de entregar los documentos, pregunté qué copias necesitaban y dónde debía firmar.", "递交文件前，我询问需要哪些复印件以及在哪里签字。", "Before submitting the documents, I asked which copies they needed and where I had to sign.", ["entregar documentos：递交文件", "copia：复印件", "dónde debía firmar：应在哪里签字"]],
          ["确认活动安排", "Voy a preguntar a la coordinadora cuándo publicarán el horario definitivo del intercambio.", "我要问协调员什么时候公布交换项目的最终日程。", "I am going to ask the coordinator when they will publish the final exchange schedule.", ["coordinadora：协调员", "horario definitivo：最终日程", "publicar：公布"]],
        ],
      },
      {
        id: "a2-preguntar-about", label: "打听某人、某事或某种情况", definitionEs: "Solicitar noticias o información acerca de una persona o un asunto.", definitionEn: "to ask about or ask for someone", scenes: ["电话", "看病", "入住"],
        preposition: "preguntar por + 人／事表示打听；在电话中也可表示要求找某人。", chunks: ["preguntar por Marta", "preguntar por el precio", "preguntar por los síntomas"], grammar: ["preguntar por", "礼貌条件式", "间接引语"],
        framework: "[人] + preguntar por + [人／主题／情况]", lessonTitle: "por 标记被打听的主题", lessonBody: "preguntar por 不等于 preguntar a：前者说明问的是谁或什么，后者说明向谁提问。两者可以同时出现。", lessonPoints: ["Pregunté por Ana", "Le pregunté al médico por el tratamiento", "Llamo para preguntar por"],
        examples: [
          ["电话找人", "Buenos días, llamo para preguntar por la señora Ruiz del departamento de movilidad.", "您好，我打电话想找流动事务部门的鲁伊斯女士。", "Good morning, I am calling to ask for Ms. Ruiz from the mobility department.", ["llamar para：打电话为了", "departamento de movilidad：流动事务部门", "preguntar por alguien：找某人"]],
          ["了解治疗", "Le pregunté al médico por los posibles efectos secundarios antes de empezar el tratamiento.", "开始治疗前，我向医生询问了可能的副作用。", "I asked the doctor about the possible side effects before starting the treatment.", ["efectos secundarios：副作用", "tratamiento：治疗", "posibles：可能的"]],
          ["酒店入住", "En recepción preguntamos por una habitación tranquila que no diera a la calle principal.", "我们在前台询问了一间不临主街的安静房间。", "At reception we asked about a quiet room that did not face the main street.", ["dar a la calle：面向街道", "recepción：前台", "虚拟式 diera：未确定房间"]],
          ["打听费用", "Varios alumnos preguntaron por el precio total y las condiciones para cancelar la matrícula.", "几名学生询问了总价以及取消注册的条件。", "Several students asked about the total price and the conditions for canceling enrollment.", ["precio total：总价", "cancelar la matrícula：取消注册", "condiciones：条件"]],
        ],
      },
    ],
  },
  {
    id: "a1-responder", lemma: "responder", semanticUnit: "提问与回应", summaryZh: "回答；回复；对……作出反应；对……负责", coreMeaningZh: "回答／回应",
    distractors: ["询问／打听", "寻找／查找", "归还／退回"], present: "respondo · respondes · responde · respondemos · respondéis · responden", preterite: "respondí · respondiste · respondió · respondimos · respondisteis · respondieron", participle: "respondido",
    phrases: ["responder una pregunta", "responder a un mensaje", "responder que sí", "no saber qué responder", "responder bien", "responder de algo"],
    patterns: ["responder + [内容] + a + [人]", "responder a + [消息／刺激]", "responder de + [责任对象]"],
    synonyms: ["contestar：日常口语中常可替换", "replicar：反驳式回应，语气不同"], antonyms: ["preguntar：提问", "ignorar：不理会"], family: ["la respuesta：回答", "la responsabilidad：责任"], contrasts: ["responder algo / responder a algo：回答内容与对消息作出回应"],
    senses: [
      {
        id: "a2-responder-answer", label: "回答问题或回复消息", definitionEs: "Dar una contestación oral o escrita a una pregunta o comunicación.", definitionEn: "to answer or reply", scenes: ["邮件", "课堂", "面试"],
        preposition: "可直接接回答内容；回复某条消息常用 responder a + 名词；被回复的人用 a。", chunks: ["responder una pregunta", "responder al correo", "responder que no"], grammar: ["responder a", "间接引语", "宾语代词"],
        framework: "[人] + responder (a) + [问题／消息／人] + [回答内容]", lessonTitle: "回答内容与回应对象使用不同结构", lessonBody: "responder la pregunta 强调回答问题本身；responder al correo 强调对邮件作出回复。说出回复内容时常接 que 从句。", lessonPoints: ["responder una pregunta", "responder al mensaje", "respondió que vendría"],
        examples: [
          ["回复邮件", "Todavía no he respondido al correo porque quiero comprobar primero todas las fechas.", "我还没回复邮件，因为想先核实所有日期。", "I have not replied to the email yet because I want to check all the dates first.", ["responder al correo：回复邮件", "comprobar fechas：核实日期", "todavía no：还没有"]],
          ["课堂回答", "Nadie supo responder la última pregunta, aunque habíamos leído el capítulo completo.", "尽管我们读了整章，但没人能回答最后一个问题。", "Nobody knew how to answer the last question, although we had read the whole chapter.", ["saber responder：会回答", "aunque：尽管", "capítulo completo：整章"]],
          ["确认邀请", "Clara respondió que sí, pero pidió cambiar la cena del viernes al sábado.", "克拉拉答应了，但请求把周五晚餐改到周六。", "Clara said yes, but asked to move Friday's dinner to Saturday.", ["responder que sí：答应", "cambiar del viernes al sábado：从周五改到周六", "pedir：请求"]],
          ["面试应答", "Intenta responder con ejemplos concretos cuando te pregunten por tu experiencia profesional.", "当被问到职业经历时，尽量用具体例子回答。", "Try to answer with concrete examples when they ask about your professional experience.", ["ejemplos concretos：具体例子", "experiencia profesional：职业经历", "cuando te pregunten：当他们问你时"]],
        ],
      },
      {
        id: "a2-responder-react", label: "作出反应；符合要求；承担责任", definitionEs: "Reaccionar ante algo, funcionar como se espera o hacerse responsable.", definitionEn: "to respond, perform, or be accountable", scenes: ["技术", "治疗", "责任"],
        preposition: "responder a + 刺激／需要；responder bien/mal 表示表现；responder de + 人／事表示负责。", chunks: ["responder bien al tratamiento", "responder a una necesidad", "responder de los daños"], grammar: ["responder a/de", "方式副词", "无人称评价"],
        framework: "[主体] + responder a/de/bien-mal + [刺激／责任／表现]", lessonTitle: "从语言回答扩展到系统反应与责任", lessonBody: "设备、身体和方案也可以 responder，表示产生反应或符合预期。responder de 强调对后果或某人承担责任。", lessonPoints: ["responder al tratamiento", "el sistema no responde", "responder de los daños"],
        examples: [
          ["电脑故障", "El programa dejó de responder justo cuando intentábamos guardar todos los cambios importantes.", "我们正尝试保存所有重要修改时，程序突然停止响应。", "The program stopped responding just as we were trying to save all the important changes.", ["dejar de responder：停止响应", "guardar cambios：保存修改", "justo cuando：正当……时"]],
          ["医疗恢复", "La paciente está respondiendo bien al tratamiento y probablemente podrá volver pronto a casa.", "患者对治疗反应良好，很可能很快可以回家。", "The patient is responding well to treatment and will probably be able to return home soon.", ["responder al tratamiento：对治疗有反应", "probablemente：很可能", "volver a casa：回家"]],
          ["课程设计", "La nueva actividad responde mejor a las necesidades reales de los estudiantes internacionales.", "新活动更好地回应了国际学生的实际需求。", "The new activity responds better to the real needs of international students.", ["responder a necesidades：满足需求", "estudiantes internacionales：国际学生", "actividad：活动"]],
          ["组织责任", "La empresa tendrá que responder de los daños causados por una instalación defectuosa.", "公司必须对有缺陷安装造成的损失负责。", "The company will have to answer for the damage caused by a faulty installation.", ["responder de：对……负责", "daños causados：造成的损失", "instalación defectuosa：有缺陷的安装"]],
        ],
      },
    ],
  },
  {
    id: "a1-comprar", lemma: "comprar", semanticUnit: "购买与支付", summaryZh: "购买；买下；接受或相信某种说法（口语）", coreMeaningZh: "购买／买下",
    distractors: ["支付／付出", "请求／点单", "归还／退款"], present: "compro · compras · compra · compramos · compráis · compran", preterite: "compré · compraste · compró · compramos · comprasteis · compraron", participle: "comprado",
    phrases: ["comprar por internet", "comprar de segunda mano", "comprar a plazos", "ir de compras", "comprar tiempo", "no comprar una excusa"],
    patterns: ["comprar + [商品] + a/en/por + [人／地点／价格]", "comprar algo para alguien", "no comprar + [说法]"],
    synonyms: ["adquirir：较正式的“购得”", "hacerse con：设法弄到，口语"], antonyms: ["vender：出售", "devolver：退回"], family: ["la compra：购买／采购", "el comprador：买家"], contrasts: ["comprar / pagar：取得商品与支付款项"],
    senses: [
      {
        id: "a2-comprar-purchase", label: "购买商品或服务", definitionEs: "Obtener algo a cambio de dinero.", definitionEn: "to buy or purchase", scenes: ["购物", "二手交易", "网购"],
        preposition: "comprar algo a alguien 表示向某人买；por + 金额表示价格；para + 人表示用途。", chunks: ["comprar por internet", "comprar de segunda mano", "comprar algo por veinte euros"], grammar: ["直接宾语代词", "por + 价格", "a + 卖方"],
        framework: "[人] + comprar + [商品] + [卖方／地点／价格／用途]", lessonTitle: "一句话补全买了什么、向谁买、多少钱", lessonBody: "comprar 关注取得商品，价格通常用 por，卖方用 a，受益人用 para。不要把这些介词混成英语式结构。", lessonPoints: ["comprar algo por veinte euros", "comprárselo a un vecino", "comprar un regalo para Ana"],
        examples: [
          ["购买交通卡", "Compré una tarjeta mensual porque resulta más barata que pagar cada viaje por separado.", "我买了月票，因为比每次单独付车费更便宜。", "I bought a monthly pass because it is cheaper than paying for each journey separately.", ["tarjeta mensual：月票", "por separado：分别", "resultar más barato：算下来更便宜"]],
          ["二手家具", "Hemos comprado una mesa de segunda mano que cabe perfectamente en la cocina pequeña.", "我们买了一张正好放进小厨房的二手桌子。", "We bought a second-hand table that fits perfectly in the small kitchen.", ["de segunda mano：二手的", "caber perfectamente：正好放得下", "cocina pequeña：小厨房"]],
          ["线上购物", "Antes de comprar el portátil por internet, compara el precio y las condiciones de devolución.", "网上买笔记本电脑前，比较价格和退货条件。", "Before buying the laptop online, compare the price and the return conditions.", ["portátil：笔记本电脑", "condiciones de devolución：退货条件", "comparar el precio：比价"]],
          ["给朋友买礼物", "Le compramos a Marta un libro ilustrado para agradecerle toda su ayuda durante el viaje.", "我们给玛尔塔买了一本插图书，感谢她旅途中的帮助。", "We bought Marta an illustrated book to thank her for all her help during the trip.", ["libro ilustrado：插图书", "agradecer la ayuda：感谢帮助", "durante el viaje：旅途中"]],
        ],
      },
      {
        id: "a2-comprar-accept", label: "接受、相信某个说法或争取时间", definitionEs: "Aceptar una explicación como verdadera o conseguir margen de tiempo.", definitionEn: "to buy a story; to buy time", scenes: ["口语质疑", "谈判", "叙事"],
        preposition: "口语中 comprar una excusa/versión 表示相信；comprar tiempo 是固定比喻。", chunks: ["no comprar esa excusa", "comprar tiempo", "comprar la versión de alguien"], grammar: ["否定陈述", "指示限定词", "比喻搭配"],
        framework: "[人] + (no) comprar + [说法／借口] / comprar tiempo", lessonTitle: "识别 comprar 的高频比喻用法", lessonBody: "这里没有真实交易。no te compro esa excusa 表示“我不信你这套说法”；comprar tiempo 表示暂时拖延以争取准备空间。", lessonPoints: ["No compro esa explicación", "comprar tiempo", "nadie compró su versión"],
        examples: [
          ["质疑借口", "No te compro esa excusa porque ayer me contaste una historia completamente diferente.", "我不相信这个借口，因为昨天你讲的是完全不同的故事。", "I do not buy that excuse because yesterday you told me a completely different story.", ["no comprar una excusa：不信借口", "contar una historia：讲故事", "completamente diferente：完全不同"]],
          ["争取准备时间", "La directora pidió otra reunión para comprar tiempo antes de anunciar la decisión definitiva.", "主管要求再开一次会，以便在公布最终决定前争取时间。", "The director requested another meeting to buy time before announcing the final decision.", ["comprar tiempo：争取时间", "anunciar：公布", "decisión definitiva：最终决定"]],
          ["识别虚假解释", "Al principio compramos su versión, pero después aparecieron varios datos que la contradecían.", "起初我们相信他的说法，但后来出现了几个与之矛盾的数据。", "At first we bought his version, but later several facts appeared that contradicted it.", ["comprar una versión：相信说法", "aparecer datos：出现数据", "contradecir：反驳／矛盾"]],
          ["谈判策略", "Ofrecieron una solución provisional para comprar unas semanas y preparar un acuerdo más sólido.", "他们提出临时方案，以争取几周并准备更稳妥的协议。", "They offered a temporary solution to buy a few weeks and prepare a stronger agreement.", ["solución provisional：临时方案", "acuerdo sólido：稳妥协议", "ofrecer：提出／提供"]],
        ],
      },
    ],
  },
  {
    id: "a1-pagar", lemma: "pagar", semanticUnit: "购买与支付", summaryZh: "支付；为……付钱；偿还；为行为付出代价", coreMeaningZh: "支付／付钱",
    distractors: ["购买／买下", "寻找／找到", "回答／负责"], present: "pago · pagas · paga · pagamos · pagáis · pagan", preterite: "pagué · pagaste · pagó · pagamos · pagasteis · pagaron", participle: "pagado",
    phrases: ["pagar en efectivo", "pagar con tarjeta", "pagar por adelantado", "pagar a medias", "pagar una deuda", "pagar las consecuencias"],
    patterns: ["pagar + [账单／金额] + a + [收款人]", "pagar por + [商品／原因]", "pagar las consecuencias de + [行为]"],
    synonyms: ["abonar：缴纳，较正式", "liquidar：结清账款"], antonyms: ["cobrar：收款／收费", "deber：欠款"], family: ["el pago：支付", "pagado：已付费的"], contrasts: ["pagar algo / pagar por algo：支付账单与为某物付费"],
    senses: [
      {
        id: "a2-pagar-money", label: "支付金额、账单或商品费用", definitionEs: "Entregar dinero a cambio de algo o para cancelar una deuda.", definitionEn: "to pay money, a bill, or for something", scenes: ["餐厅", "租房", "网购"],
        preposition: "pagar algo 直接接账单；pagar por algo 表示为某物付费；收款人用 a。", chunks: ["pagar la cuenta", "pagar por adelantado", "pagar con tarjeta"], grammar: ["pagar algo", "pagar por", "间接宾语"],
        framework: "[人] + pagar + [账单／金额] + por/a/con + [对象／收款人／方式]", lessonTitle: "区分账单、购买对象和付款方式", lessonBody: "la cuenta 是直接支付的对象；por 引出付费换来的东西；con 引出支付工具。pagué 中 g 变为 gu 以保持发音。", lessonPoints: ["pagar la cuenta", "pagar por el servicio", "pagar con tarjeta"],
        examples: [
          ["餐厅结账", "Pagamos la cuenta a medias porque todos habíamos pedido platos de precios parecidos.", "我们平摊账单，因为大家点的菜价格相近。", "We split the bill because everyone had ordered dishes at similar prices.", ["pagar a medias：平摊", "pedir platos：点菜", "precios parecidos：相近价格"]],
          ["预付房租", "El propietario nos pidió pagar dos meses por adelantado antes de entregar las llaves.", "房东要求我们交钥匙前预付两个月。", "The landlord asked us to pay two months in advance before handing over the keys.", ["por adelantado：预先", "propietario：房东", "entregar las llaves：交钥匙"]],
          ["支付课程费", "Puedes pagar la matrícula con tarjeta o mediante una transferencia bancaria internacional.", "你可以用银行卡或国际银行转账支付注册费。", "You can pay the enrollment fee by card or through an international bank transfer.", ["pagar la matrícula：支付注册费", "transferencia bancaria：银行转账", "mediante：通过"]],
          ["网购附加费", "No quiero pagar veinte euros por un envío que normalmente tarda más de una semana.", "我不想为通常超过一周才送达的配送支付二十欧元。", "I do not want to pay twenty euros for delivery that normally takes more than a week.", ["envío：配送", "tardar más de：耗时超过", "pagar por：为……付费"]],
        ],
      },
      {
        id: "a2-pagar-consequence", label: "偿还或为行为付出代价", definitionEs: "Saldar una obligación o sufrir las consecuencias negativas de una acción.", definitionEn: "to repay or pay the price", scenes: ["债务", "错误后果", "社会话题"],
        preposition: "pagar una deuda 直接接名词；pagar por un error／pagar las consecuencias de 表示承担后果。", chunks: ["pagar una deuda", "pagar por un error", "pagar las consecuencias"], grammar: ["比喻宾语", "por + 原因", "de + 行为来源"],
        framework: "[人／群体] + pagar + [债务／后果] + por/de + [原因]", lessonTitle: "支付可以从金钱延伸到后果", lessonBody: "pagar una deuda 可能是真实债务；pagar por un error 和 pagar las consecuencias 常表示非金钱代价，语气通常较强。", lessonPoints: ["pagar una deuda", "pagar por el error", "pagar las consecuencias de"],
        examples: [
          ["偿还借款", "Necesitaré varios meses para pagar la deuda sin dejar de cubrir los gastos básicos.", "我需要几个月偿还债务，同时不能停止承担基本开支。", "I will need several months to repay the debt without stopping covering basic expenses.", ["pagar la deuda：还债", "cubrir gastos：承担开支", "gastos básicos：基本开支"]],
          ["错过期限", "El equipo pagó caro el error de no comprobar los documentos antes de enviarlos.", "团队因发送前未核对文件而付出了高昂代价。", "The team paid dearly for the mistake of not checking the documents before sending them.", ["pagar caro：付出高昂代价", "comprobar documentos：核对文件", "antes de enviarlos：发送前"]],
          ["环境责任", "Las generaciones futuras no deberían pagar las consecuencias de nuestras decisiones más irresponsables.", "后代不应该为我们最不负责任的决定承担后果。", "Future generations should not pay the consequences of our most irresponsible decisions.", ["generaciones futuras：后代", "pagar las consecuencias：承担后果", "irresponsable：不负责任的"]],
          ["健康代价", "Si duermes tan poco durante meses, acabarás pagando por ese ritmo de vida.", "如果连续几个月睡得这么少，最终会为这种生活节奏付出代价。", "If you sleep so little for months, you will end up paying for that pace of life.", ["ritmo de vida：生活节奏", "acabar + gerundio：最终", "durante meses：连续数月"]],
        ],
      },
    ],
  },
  {
    id: "a1-pedir", lemma: "pedir", semanticUnit: "请求与归还", summaryZh: "请求；索要；点单；要求某人做某事", coreMeaningZh: "请求／索要",
    distractors: ["询问信息", "回答问题", "归还物品"], present: "pido · pides · pide · pedimos · pedís · piden", preterite: "pedí · pediste · pidió · pedimos · pedisteis · pidieron", participle: "pedido",
    phrases: ["pedir ayuda", "pedir permiso", "pedir la cuenta", "pedir prestado", "pedir cita", "pedir que + 虚拟式"],
    patterns: ["pedir + [东西] + a + [人]", "pedir que + [虚拟式]", "pedir para + [点单对象]"],
    synonyms: ["solicitar：正式申请", "rogar：恳求，语气更强"], antonyms: ["ofrecer：主动提供", "devolver：归还"], family: ["el pedido：订单", "la petición：请求"], contrasts: ["pedir / preguntar：要求得到东西或行动与询问信息"],
    senses: [
      {
        id: "a2-pedir-object", label: "请求、索要、点餐或预约", definitionEs: "Solicitar que alguien dé algo o preste un servicio.", definitionEn: "to ask for, request, or order", scenes: ["餐厅", "预约", "借东西"],
        preposition: "所求对象直接接 pedir；向谁请求用 a；pedir prestado 的性数可随所借物变化。", chunks: ["pedir la cuenta", "pedir cita", "pedir algo prestado"], grammar: ["双宾语", "pedir prestado", "礼貌条件式"],
        framework: "[人] + pedir(le) + [对象／服务] + a + [对方]", lessonTitle: "请求的东西与被请求的人不是同一成分", lessonBody: "pedir la cuenta 是索要账单，pedir al camarero 是向服务员提出请求。两者同时出现时可用 le 复指对方。", lessonPoints: ["pedir la cuenta", "pedirle ayuda a Ana", "pedir cita"],
        examples: [
          ["餐厅点单", "Para compartir, pedimos una ración de tortilla y dos platos que no llevaban carne.", "为了分享，我们点了一份土豆饼和两道不含肉的菜。", "To share, we ordered a portion of tortilla and two dishes that contained no meat.", ["para compartir：用来分享", "ración：一份菜", "no llevar carne：不含肉"]],
          ["预约医生", "He pedido cita con la médica porque llevo varios días con un dolor extraño.", "我预约了医生，因为奇怪的疼痛已经持续好几天。", "I made an appointment with the doctor because I have had a strange pain for several days.", ["pedir cita：预约", "llevar varios días con：持续几天有", "dolor extraño：奇怪疼痛"]],
          ["借充电器", "¿Podrías pedirme un cargador prestado hasta que compre uno nuevo esta tarde?", "你能借给我一个充电器，直到我下午买新的为止吗？", "Could you lend me a charger until I buy a new one this afternoon?", ["pedir prestado：借用", "cargador：充电器", "hasta que + 虚拟式：直到"]],
          ["索要收据", "Al pagar, pedí un recibo detallado para justificar correctamente todos los gastos del viaje.", "付款时，我索要详细收据，以便正确报销全部旅行开支。", "When paying, I asked for an itemized receipt to properly justify all the travel expenses.", ["recibo detallado：详细收据", "justificar gastos：说明／报销开支", "al pagar：付款时"]],
        ],
      },
      {
        id: "a2-pedir-action", label: "要求或请某人做某事", definitionEs: "Solicitar a alguien que realice una acción.", definitionEn: "to ask someone to do something", scenes: ["课堂", "合租", "正式请求"],
        preposition: "pedir que + 动词现在或过去虚拟式；不能使用英语式 pedir a alguien hacer。", chunks: ["pedir que venga", "pedirle a alguien que", "pedir permiso para"], grammar: ["pedir que + subjuntivo", "时态呼应", "间接宾语代词"],
        framework: "[人] + pedir(le) a + [对象] + que + [虚拟式行动]", lessonTitle: "主语不同就用 que 加虚拟式", lessonBody: "当请求者和行动者不同，使用 pedir que + 虚拟式。若同一个人请求许可做自己的动作，则常用 pedir permiso para + infinitivo。", lessonPoints: ["Le pedí que viniera", "Pido que me expliquen", "pedir permiso para salir"],
        examples: [
          ["课堂说明", "La profesora nos pidió que entregáramos el ejercicio antes de salir del aula.", "老师要求我们离开教室前交练习。", "The teacher asked us to submit the exercise before leaving the classroom.", ["pedir que + 虚拟式：要求", "entregar el ejercicio：交练习", "salir del aula：离开教室"]],
          ["合租沟通", "Le pedí a mi compañero que bajara la música porque tenía una reunión importante.", "我请室友把音乐调低，因为我有重要会议。", "I asked my flatmate to turn the music down because I had an important meeting.", ["bajar la música：调低音乐", "compañero de piso：室友", "reunión importante：重要会议"]],
          ["修改合同", "Los estudiantes pidieron que el contrato explicara claramente cómo recuperar la fianza.", "学生们要求合同清楚说明如何拿回押金。", "The students asked for the contract to explain clearly how to recover the deposit.", ["recuperar la fianza：拿回押金", "explicar claramente：清楚说明", "contrato：合同"]],
          ["申请提前离开", "Marta pidió permiso para salir antes porque debía recoger a su hijo del colegio.", "玛尔塔请求提前离开，因为必须去学校接孩子。", "Marta asked for permission to leave early because she had to pick up her son from school.", ["pedir permiso para：请求许可", "salir antes：提前离开", "recoger a：去接某人"]],
        ],
      },
    ],
  },
  {
    id: "a2-devolver", lemma: "devolver", semanticUnit: "请求与归还", summaryZh: "归还；退回商品或款项；回赠、回拨或回应", coreMeaningZh: "归还／退回",
    distractors: ["请求／索要", "购买／买下", "开始／继续"], present: "devuelvo · devuelves · devuelve · devolvemos · devolvéis · devuelven", preterite: "devolví · devolviste · devolvió · devolvimos · devolvisteis · devolvieron", participle: "devuelto",
    phrases: ["devolver un libro", "devolver el dinero", "devolver una llamada", "devolver un producto", "devolver el favor", "devolver la sonrisa"],
    patterns: ["devolver + [对象] + a + [原主人]", "devolver el dinero por + [退货]", "devolver + [行动／善意]"],
    synonyms: ["retornar：返回，地区与语体差异较大", "reembolsar：退还款项，较正式"], antonyms: ["quedarse con：留下", "pedir prestado：借用"], family: ["la devolución：退货／归还", "devuelto：已退回的"], contrasts: ["devolver / volver：归还某物与自己返回"],
    senses: [
      {
        id: "a2-devolver-return", label: "归还物品、退货或退款", definitionEs: "Entregar algo de nuevo a su dueño o regresar dinero o productos.", definitionEn: "to return, give back, or refund", scenes: ["图书馆", "商店", "押金"],
        preposition: "devolver algo a alguien；代词顺序是 devolvérselo；过去分词是不规则 devuelto。", chunks: ["devolver el libro", "devolver el dinero", "devolver un producto"], grammar: ["双宾语代词", "不规则过去分词", "退货原因"],
        framework: "[人／商家] + devolver + [对象／款项] + a/por + [人／原因]", lessonTitle: "分清谁把什么还给谁", lessonBody: "被归还物是直接宾语，原主人是间接宾语。两个代词同时出现时 le 变 se：se lo devolví。", lessonPoints: ["devolver un libro", "devolverle el dinero", "se lo devolví"],
        examples: [
          ["图书馆还书", "Tengo que devolver estos libros mañana para evitar una multa por retraso.", "我必须明天归还这些书，以免产生逾期罚款。", "I have to return these books tomorrow to avoid a late fee.", ["multa por retraso：逾期罚款", "evitar：避免", "devolver libros：还书"]],
          ["退换衣服", "Quiero devolver esta chaqueta porque la talla no coincide con la descripción de la web.", "我想退掉这件夹克，因为尺码与网页描述不符。", "I want to return this jacket because the size does not match the website description.", ["talla：尺码", "coincidir con：与……一致", "descripción de la web：网页描述"]],
          ["退还押金", "El propietario prometió devolvernos la fianza completa después de revisar el estado del piso.", "房东承诺检查公寓状况后全额退还押金。", "The landlord promised to return our full deposit after checking the condition of the flat.", ["fianza completa：全额押金", "estado del piso：房屋状况", "prometer + infinitivo：承诺"]],
          ["重复扣款退款", "El banco me devolvió el dinero que habían cobrado dos veces por error.", "银行退还了因错误而重复扣除的钱。", "The bank refunded the money that had been charged twice by mistake.", ["cobrar dos veces：重复扣款", "por error：错误地", "devolver el dinero：退款"]],
        ],
      },
      {
        id: "a2-devolver-response", label: "回拨、回赠或以相同动作回应", definitionEs: "Responder repitiendo una acción, atención o gesto recibido.", definitionEn: "to return a call, favor, smile, or gesture", scenes: ["电话", "人际互助", "社交"],
        preposition: "与 llamada, favor, sonrisa, saludo 等形成固定搭配，通常直接接名词。", chunks: ["devolver la llamada", "devolver el favor", "devolver la sonrisa"], grammar: ["固定搭配", "间接宾语代词", "关系从句"],
        framework: "[人] + devolver(le) + [电话／帮助／动作] + a + [对方]", lessonTitle: "devolver 不一定涉及实物", lessonBody: "西语把回电话、回报帮助、回以微笑都看作把收到的动作送回去。掌握这些词块比逐字翻译更自然。", lessonPoints: ["devolver la llamada", "devolver el favor", "devolver la sonrisa"],
        examples: [
          ["回拨电话", "No pude contestar antes, pero te devolveré la llamada en cuanto termine la reunión.", "我之前无法接听，但会议一结束就会回电话。", "I could not answer earlier, but I will call you back as soon as the meeting ends.", ["devolver la llamada：回电话", "en cuanto termine：一结束就", "contestar：接听／回答"]],
          ["回报帮助", "Algún día espero poder devolverte el favor que me hiciste durante la mudanza.", "我希望有一天能回报你搬家时给予的帮助。", "Someday I hope to return the favor you did me during the move.", ["devolver el favor：回报帮助", "hacer un favor：帮忙", "durante la mudanza：搬家期间"]],
          ["礼貌互动", "La niña me devolvió la sonrisa cuando le cedí el asiento en el autobús.", "我在公交车上给女孩让座时，她回了我一个微笑。", "The girl smiled back at me when I gave her my seat on the bus.", ["devolver la sonrisa：回以微笑", "ceder el asiento：让座", "en el autobús：在公交上"]],
          ["归还问候", "Aunque estaba distraído, levantó la mano para devolver el saludo desde la otra acera.", "尽管心不在焉，他仍举手从街对面回礼。", "Although he was distracted, he raised his hand to return the greeting from the other pavement.", ["devolver el saludo：回礼／回应问候", "levantar la mano：举手", "la otra acera：街对面人行道"]],
        ],
      },
    ],
  },
];

function buildEntry(entry) {
  const lookupForms = entry.present.split(" · ");
  return {
    id: entry.id,
    lemma: entry.lemma,
    partOfSpeech: "动词",
    level: "A2",
    frequency: "核心高频",
    semanticUnit: entry.semanticUnit,
    summaryZh: entry.summaryZh,
    coreMeaningZh: entry.coreMeaningZh,
    recognitionDistractors: entry.distractors,
    forms: [
      { label: "原形", value: entry.lemma, note: "结合重要介词和句式整体学习，避免逐字翻译。" },
      { label: "现在时", value: entry.present, note: "注意词干变化及第一人称拼写。" },
      { label: "简单过去时", value: entry.preterite, note: "用于讲述已完成事件。" },
      { label: "过去分词", value: entry.participle, note: "与 haber 构成完成时，也可能参与被动或形容词结构。" },
    ],
    importantPhrases: entry.phrases,
    patterns: entry.patterns,
    synonyms: entry.synonyms,
    antonyms: entry.antonyms,
    family: entry.family,
    contrasts: entry.contrasts,
    lookupForms: [...lookupForms, entry.participle],
    senses: entry.senses.map((sense, senseIndex) => ({
      id: sense.id,
      cardLabel: `动词义项 ${senseIndex + 1}`,
      labelZh: sense.label,
      definitionEs: sense.definitionEs,
      definitionEn: sense.definitionEn,
      register: "通用",
      region: "欧洲西语优先 · 通用可理解",
      usageScenes: sense.scenes,
      prepositionNote: sense.preposition,
      chunks: sense.chunks,
      grammarTags: sense.grammar,
      verbInfo: `${entry.lemma}：现在时 ${entry.present}；简单过去时 ${entry.preterite}；过去分词 ${entry.participle}。`,
      englishContrast: "英语和西语的及物结构、介词及从句选择不完全对应，应把本义项的句框和词块整体提取。",
      transferError: `不要只按英语介词直译；优先记忆：${sense.chunks.join("；")}。`,
      microLesson: {
        title: sense.lessonTitle,
        body: sense.lessonBody,
        keyPoints: sense.lessonPoints,
      },
      examples: sense.examples.map(([scene, spanish, chinese, english, extraVocabulary], exampleIndex) => ({
        scene,
        spanish,
        chinese,
        english,
        targetMeaning: `${entry.lemma}：${sense.label}`,
        framework: sense.framework,
        grammar: sense.grammar,
        sentenceParts: [
          `核心句框：${sense.framework}`,
          `当前例句围绕“${scene}”补充时间、原因、条件或目的信息。`,
        ],
        functionNotes: [sense.preposition, ...sense.grammar.slice(0, 2)],
        chunks: [...sense.chunks, ...extraVocabulary].slice(0, 5),
        extraVocabulary,
        microExercise: {
          prompt: `先遮住西语，用本句结构口头或书面翻译：${chinese}`,
          answer: spanish,
        },
        replacement: `保留“${sense.chunks[0]}”的结构，替换人物、场景和补充信息，写一个与自己有关的句子。`,
        id: `${sense.id}-example-${exampleIndex + 1}`,
      })),
    })),
  };
}

const output = resolve("data/a2-core-content-source.json");
const pack = { meta, entries: entries.map(buildEntry), exercises: [] };
await writeFile(output, `${JSON.stringify(pack, null, 2)}\n`, "utf8");
console.log(JSON.stringify({ output, entries: pack.entries.length, senses: pack.entries.reduce((sum, entry) => sum + entry.senses.length, 0), examples: pack.entries.flatMap((entry) => entry.senses).reduce((sum, sense) => sum + sense.examples.length, 0) }, null, 2));
