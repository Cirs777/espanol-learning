import { existsSync, readFileSync } from "node:fs";
import { isAbsolute, resolve } from "node:path";

import { migrateV1Profile } from "../db/local/migrate-v1-profile.mjs";
import { formatPathForDisplay, parseNamedArguments } from "./cli-args.mjs";

try {
  const args = parseNamedArguments(process.argv.slice(2));
  if (!args.input) {
    throw new Error("请使用 --input 指定从第一版导出的 JSON 文件");
  }
  const inputPath = isAbsolute(args.input) ? args.input : resolve(process.cwd(), args.input);
  if (!existsSync(inputPath)) throw new Error(`找不到文件：${inputPath}`);

  const result = migrateV1Profile({
    rawPayload: readFileSync(inputPath, "utf8"),
    databasePath: args.database,
    backupDirectory: args["backup-dir"],
    timezone: args.timezone,
  });

  console.log("第一版学习档案迁移完成。\n");
  console.log(`数据库：${formatPathForDisplay(result.databasePath)}`);
  console.log(
    `迁移前备份：${result.backupPath ? formatPathForDisplay(result.backupPath) : "新数据库，无旧数据库需要备份"}`,
  );
  console.log(`收藏：读取 ${result.counts.favoritesRead}，写入 ${result.counts.favoritesStored}`);
  console.log(
    `义项进度：读取 ${result.counts.reviewRecordsRead}，写入 ${result.counts.senseProgressStored}`,
  );
  console.log(`待处理记录：${result.counts.issues}`);
} catch (error) {
  console.error(`第一版学习档案迁移失败：${error.message}`);
  if (error.backupPath) {
    console.error(`已保留迁移前备份：${formatPathForDisplay(error.backupPath)}`);
  }
  process.exitCode = 1;
}
