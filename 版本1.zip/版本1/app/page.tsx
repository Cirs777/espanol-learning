"use client";

import { ChangeEvent, useEffect, useMemo, useRef, useState } from "react";
import WordLearningFlow, {
  LearningExample,
  LearningEntry,
  MemoryRating,
} from "@/components/WordLearningFlow";
import ExampleStudyDialog from "@/components/ExampleStudyDialog";
import InstallAppCard from "@/components/InstallAppCard";
import contentData from "@/data/demo-content.json";
import a1ContentSource from "@/data/a1-core-content-source.json";
import a1SemanticPlanData from "@/data/a1-semantic-plan.json";
import a2ContentSource from "@/data/a2-core-content-source.json";
import a2SemanticPlanData from "@/data/a2-semantic-plan.json";
import a1IndexData from "@/data/indexes/a1-elelex-core.json";
import a2IndexData from "@/data/indexes/a2-elelex-core.json";
import wordBookData from "@/data/wordbooks.json";
import {
  DAILY_WORD_GOALS,
  createDailyLearningPlanState,
  createOrResumeDailyQueue,
  dailyPlanSummary,
  markDailyEntryCompleted,
  markEntryFamiliar,
  nextUnfinishedEntry,
  restoreFamiliarEntry,
  sanitizeDailyLearningPlanState,
  setDailyGoal,
} from "@/lib/daily-learning-plan.mjs";
import {
  activateWordBook,
  createWordBookState,
  deriveWordBookStats,
  filterWordBookEntries,
  resetWordBookProgress,
  sanitizeWordBookState,
  toggleWordBookPaused,
} from "@/lib/wordbook-progress.mjs";
import {
  createMemoryRecord,
  getDueShortTermItems,
  sanitizeMemoryRecord,
  scheduleMemoryReview,
} from "@/lib/review-scheduler.mjs";
import { expandContentPack } from "@/lib/content-pack.mjs";

type View =
  | "home"
  | "library"
  | "review"
  | "favorites"
  | "practice"
  | "profile"
  | "settings";

type Entry = LearningEntry;

type Exercise = {
  id: string;
  type: string;
  senseId: string;
  prompt: string;
  hint: string;
  answers: string[];
  feedback: string;
};

type ReviewRecord = {
  intervalIndex: number;
  score: 0 | 1 | 2;
  lastReview: string;
  nextReview: string;
  attempts: number;
  independentUses: number;
  contexts: string[];
};

type Activity = {
  sessions: number;
  answered: number;
  correct: number;
  recordings: number;
  minutes: number;
  lastActive: string | null;
};

type MemoryRecord = {
  status: "not_started" | MemoryRating;
  easeFactor: number;
  intervalDays: number;
  lastReviewedAt: string | null;
  nextReviewDate: string | null;
  shortTermDueAt: string[];
  knownStreak: number;
  failureStreak: number;
  recognitionErrors: number;
  lastReactionMs: number | null;
  events: Array<Record<string, unknown>>;
};

type LearningEvidence = {
  recognitionErrors: number;
  lastReactionMs: number | null;
  visitedSenseIds: string[];
  audioPlayCount: number;
  viewedAnalysisIds: string[];
  ratedSenseIds: string[];
  wordCheckAttempts: number;
  wordCheckCorrect: number;
  completedSessions: number;
  lastCardPosition: number;
  lastStudiedAt: string | null;
};

type WordBook = {
  id: string;
  name: string;
  level: string;
  shortLabel: string;
  description: string;
  sourceName: string;
  sourceType: string;
  sourceNotice: string;
  licenseNotice: string;
  authorizationStatus: string;
  contentStatus: string;
  version: string;
  updatedAt: string;
  isEnabled: boolean;
  isDevelopmentOnly: boolean;
  indexedEntryCount?: number;
  indexFile?: string;
  entryIds: string[];
  readyEntryIds: string[];
};

type A1IndexEntry = {
  id: string;
  lemma: string;
  level: "A1";
  partsOfSpeech: string[];
  sourceTags: string[];
  a1DocumentCount: number;
  a1Frequency: number;
  totalFrequency: number;
  priorityRank: number;
  contentStatus: "index_only";
  reviewStatus: "source_imported";
};

type A2IndexEntry = {
  id: string;
  lemma: string;
  level: "A2";
  partsOfSpeech: string[];
  sourceTags: string[];
  documentCount: number;
  levelFrequency: number;
  totalFrequency: number;
  priorityRank: number;
  contentStatus: "index_only";
  reviewStatus: "source_imported";
  sharedAcrossWordBooks: boolean;
};

type WordIndexEntry = A1IndexEntry | A2IndexEntry;

type DailyLearningPlanState = {
  dailyGoal: 5 | 10 | 15 | 20;
  queueDate: string | null;
  wordBookId: string | null;
  queueEntryIds: string[];
  completedEntryIds: string[];
  familiarEntryIds: string[];
};

type WordBookProgress = {
  state: "not_started" | "active" | "paused" | "completed";
  currentPosition: number;
  learnedLexemeIds: string[];
  masteredLexemeIds: string[];
  lastStudiedAt: string | null;
};

type WordBookState = {
  currentWordBookId: string | null;
  progress: Record<string, WordBookProgress>;
};

type WordBookLevelFilter = "all" | "A1" | "A2" | "B1" | "planned" | "DEV";
type WordEntryStatusFilter = "all" | "unlearned" | "learned" | "due";
type FlowMode = "learn" | "review" | "lookup";
type ExampleStudySelection = {
  entry: Entry;
  sense: Entry["senses"][number];
  example: LearningExample;
};

const wordBookStateLabels: Record<WordBookProgress["state"], string> = {
  not_started: "未开始",
  active: "学习中",
  paused: "已暂停",
  completed: "已完成",
};

const contentStatusLabels: Record<string, string> = {
  source_pending: "等待合法词表来源",
  index_imported_content_building: "索引已导入 · 内容建设中",
  partial_content_ready: "首批语义内容可学习",
  planned: "后续阶段",
  development_test: "开发测试",
};

const indexPartOfSpeechLabels: Record<string, string> = {
  adjective: "形容词",
  adverb: "副词",
  conjunction: "连词",
  determiner: "限定词",
  interjection: "感叹词",
  noun: "名词",
  preposition: "介词",
  pronoun: "代词",
  verb: "动词",
};

const demoContent = contentData as {
  meta: {
    contentPackId: string;
    title: string;
    version: string;
    locale: string;
    sourceType: string;
    reviewStatus: string;
    notice: string;
  };
  entries: Entry[];
  exercises: Exercise[];
};
const a1Content = expandContentPack(a1ContentSource) as {
  meta: typeof demoContent.meta;
  entries: Entry[];
  exercises: Exercise[];
};
const a2Content = expandContentPack(a2ContentSource) as {
  meta: typeof demoContent.meta;
  entries: Entry[];
  exercises: Exercise[];
};
const content = {
  meta: a1Content.meta,
  entries: [...a1Content.entries, ...a2Content.entries, ...demoContent.entries],
  exercises: [...a1Content.exercises, ...a2Content.exercises, ...demoContent.exercises],
};

const a1Index = a1IndexData as {
  meta: {
    title: string;
    indexedLexemes: number;
    contentReadyLexemes: number;
    sourceName: string;
    license: string;
    selectionRule: string;
    notice: string;
  };
  entries: A1IndexEntry[];
};
const a2Index = a2IndexData as {
  meta: {
    title: string;
    indexedLexemes: number;
    sharedLexemes: number;
    sourceName: string;
    license: string;
    selectionRule: string;
    notice: string;
  };
  entries: A2IndexEntry[];
};
const rawWordBookCatalog = wordBookData as {
  meta: { schemaVersion: number; version: string; updatedAt: string; notice: string };
  wordBooks: WordBook[];
};
const a2SemanticPlan = a2SemanticPlanData as {
  meta: { version: string; title: string; notice: string };
  units: Array<{ id: string; name: string; description: string; entryIds: string[] }>;
};
const a2IndexedIds = new Set(a2Index.entries.map((entry) => entry.id));
const a2ReadyEntryIds = a2SemanticPlan.units
  .flatMap((unit) => unit.entryIds)
  .filter((entryId) => a2IndexedIds.has(entryId) && content.entries.some((entry) => entry.id === entryId));
const wordBookCatalog = {
  ...rawWordBookCatalog,
  wordBooks: rawWordBookCatalog.wordBooks.map((wordBook) => wordBook.id === "wordbook-a2-core"
    ? {
        ...wordBook,
        sourceName: "ELELex（CEFRLex / CENTAL）+ Contexto 内容层",
        sourceType: "licensed_lexical_index",
        sourceNotice: `已导入 ${a2Index.meta.indexedLexemes} 个 A2 候选索引，其中 ${a2Index.meta.sharedLexemes} 个与 A1 共用同一核心词条；首批 ${a2ReadyEntryIds.length} 个动作关系词已具备完整卡片。`,
        licenseNotice: "ELELex 采用 CC BY-NC-SA 4.0，仅用于本个人非商业学习项目；释义、例句与分析须由 Contexto 另行编写和审核。",
        authorizationStatus: "cc_by_nc_sa_4_0",
        contentStatus: "index_imported_content_building",
        indexedEntryCount: a2Index.meta.indexedLexemes,
        indexFile: "data/indexes/a2-elelex-core.json",
        entryIds: a2Index.entries.map((entry) => entry.id),
        readyEntryIds: a2ReadyEntryIds,
      }
    : wordBook),
};
const a1SemanticPlan = a1SemanticPlanData as {
  meta: { version: string; title: string; notice: string };
  simpleFunctionWords: string[];
  units: Array<{ id: string; name: string; description: string; entryIds: string[] }>;
};
const wordBookIds = wordBookCatalog.wordBooks.map((wordBook) => wordBook.id);

const intervals = [1, 3, 7, 14, 30, 60, 90];
const storageKey = "contexto-learning-profile-v0.1";

const navItems: Array<{ id: View; label: string; icon: string }> = [
  { id: "home", label: "首页", icon: "⌂" },
  { id: "library", label: "词书", icon: "A" },
  { id: "review", label: "今日复习", icon: "↻" },
  { id: "favorites", label: "收藏", icon: "♡" },
  { id: "practice", label: "练习", icon: "✦" },
  { id: "profile", label: "学习档案", icon: "◎" },
  { id: "settings", label: "设置", icon: "⚙" },
];

const initialActivity: Activity = {
  sessions: 0,
  answered: 0,
  correct: 0,
  recordings: 0,
  minutes: 0,
  lastActive: null,
};

function datePlusDays(days: number) {
  const next = new Date();
  next.setHours(12, 0, 0, 0);
  next.setDate(next.getDate() + days);
  return next.toISOString().slice(0, 10);
}

function formatDate(value?: string) {
  if (!value) return "尚未安排";
  return new Intl.DateTimeFormat("zh-CN", {
    month: "short",
    day: "numeric",
  }).format(new Date(`${value}T12:00:00`));
}

function normalizeAnswer(value: string) {
  return value
    .toLocaleLowerCase("es")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[¿?¡!.,;:]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function normalizeSpanishToken(value: string) {
  return value
    .normalize("NFC")
    .toLocaleLowerCase("es")
    .replace(/^[^\p{L}áéíóúüñ]+|[^\p{L}áéíóúüñ]+$/giu, "");
}

export default function Home() {
  const [activeView, setActiveView] = useState<View>("home");
  const [favorites, setFavorites] = useState<string[]>([]);
  const [reviewState, setReviewState] = useState<Record<string, ReviewRecord>>({});
  const [activity, setActivity] = useState<Activity>(initialActivity);
  const [wordMemoryState, setWordMemoryState] = useState<Record<string, MemoryRecord>>({});
  const [learningEvidence, setLearningEvidence] = useState<Record<string, LearningEvidence>>({});
  const [wordBookState, setWordBookState] = useState<WordBookState>(() =>
    createWordBookState(wordBookIds) as WordBookState,
  );
  const [dailyPlanState, setDailyPlanState] = useState<DailyLearningPlanState>(() =>
    createDailyLearningPlanState() as DailyLearningPlanState,
  );
  const [cuttingEntryIds, setCuttingEntryIds] = useState<string[]>([]);
  const [dailySessionComplete, setDailySessionComplete] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const [query, setQuery] = useState("");
  const [wordBookQuery, setWordBookQuery] = useState("");
  const [wordBookLevelFilter, setWordBookLevelFilter] = useState<WordBookLevelFilter>("all");
  const [wordEntryStatusFilter, setWordEntryStatusFilter] = useState<WordEntryStatusFilter>("all");
  const [a1IndexPage, setA1IndexPage] = useState(1);
  const [focusedWordBookId, setFocusedWordBookId] = useState("wordbook-a1-core");
  const [selectedWordBookId, setSelectedWordBookId] = useState<string | null>(null);
  const [selectedEntryId, setSelectedEntryId] = useState<string | null>(null);
  const [selectedSenseId, setSelectedSenseId] = useState<string | null>(null);
  const [selectedFlowMode, setSelectedFlowMode] = useState<FlowMode>("learn");
  const [selectedExampleStudy, setSelectedExampleStudy] = useState<ExampleStudySelection | null>(null);
  const [selectedIndexPreview, setSelectedIndexPreview] = useState<WordIndexEntry | null>(null);
  const [reviewCursor, setReviewCursor] = useState(0);
  const [exerciseIndex, setExerciseIndex] = useState(0);
  const [answer, setAnswer] = useState("");
  const [showHint, setShowHint] = useState(false);
  const [practiceFeedback, setPracticeFeedback] = useState<{
    correct: boolean;
    message: string;
  } | null>(null);
  const [speechRate, setSpeechRate] = useState<"normal" | "slow">("normal");
  const [recording, setRecording] = useState(false);
  const [recordingUrl, setRecordingUrl] = useState<string | null>(null);
  const [recordingTake, setRecordingTake] = useState<1 | 2>(1);
  const [toast, setToast] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  const allSenses = useMemo(
    () =>
      content.entries.flatMap((entry) =>
        entry.senses.map((sense) => ({ entry, sense })),
      ),
    [],
  );

  const contentEntryById = useMemo(
    () => new Map(content.entries.map((entry) => [entry.id, entry])),
    [],
  );
  const a1IndexById = useMemo(
    () => new Map(a1Index.entries.map((entry) => [entry.id, entry])),
    [],
  );
  const a2IndexById = useMemo(
    () => new Map(a2Index.entries.map((entry) => [entry.id, entry])),
    [],
  );
  const semanticRankByEntryId = useMemo(
    () => new Map(
      a1SemanticPlan.units
        .flatMap((unit) => unit.entryIds)
        .map((entryId, index) => [entryId, index]),
    ),
    [],
  );
  const lookupEntryByForm = useMemo(() => {
    const lookup = new Map<string, Entry>();
    for (const entry of content.entries) {
      for (const form of [entry.lemma, ...(entry.lookupForms ?? [])]) {
        lookup.set(normalizeSpanishToken(form), entry);
      }
    }
    return lookup;
  }, []);

  const visibleWordBooks = useMemo(() => {
    const normalized = wordBookQuery.trim().toLocaleLowerCase("zh-CN");
    return wordBookCatalog.wordBooks.filter((wordBook) => {
      if (wordBookLevelFilter === "planned" && wordBook.isEnabled) return false;
      if (wordBookLevelFilter === "DEV" && !wordBook.isDevelopmentOnly) return false;
      if (
        !["all", "planned", "DEV"].includes(wordBookLevelFilter) &&
        wordBook.level !== wordBookLevelFilter
      ) return false;
      if (!normalized) return true;
      return [wordBook.name, wordBook.level, wordBook.shortLabel, wordBook.description]
        .join(" ")
        .toLocaleLowerCase("zh-CN")
        .includes(normalized);
    });
  }, [wordBookLevelFilter, wordBookQuery]);

  const familiarSenseIds = useMemo(
    () => new Set(
      content.entries
        .filter((entry) => dailyPlanState.familiarEntryIds.includes(entry.id))
        .flatMap((entry) => entry.senses.map((sense) => sense.id)),
    ),
    [dailyPlanState.familiarEntryIds],
  );

  const reviewableSenses = useMemo(
    () => allSenses.filter(({ entry }) => !dailyPlanState.familiarEntryIds.includes(entry.id)),
    [allSenses, dailyPlanState.familiarEntryIds],
  );

  const a1IndexMatches = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase("es");
    const matches = normalized
      ? a1Index.entries.filter((entry) =>
        [entry.lemma, ...entry.partsOfSpeech].join(" ").toLocaleLowerCase("es").includes(normalized))
      : a1Index.entries;
    const ordered = [...matches].sort((left, right) => {
      const leftRank = semanticRankByEntryId.get(left.id);
      const rightRank = semanticRankByEntryId.get(right.id);
      if (leftRank !== undefined || rightRank !== undefined) {
        if (leftRank === undefined) return 1;
        if (rightRank === undefined) return -1;
        return leftRank - rightRank;
      }
      return left.priorityRank - right.priorityRank;
    });
    return {
      total: ordered.length,
      visible: ordered.slice(0, a1IndexPage * 60),
    };
  }, [a1IndexPage, query, semanticRankByEntryId]);

  const a2IndexMatches = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase("es");
    const matches = normalized
      ? a2Index.entries.filter((entry) =>
        [entry.lemma, ...entry.partsOfSpeech].join(" ").toLocaleLowerCase("es").includes(normalized))
      : a2Index.entries;
    return {
      total: matches.length,
      visible: matches.slice(0, a1IndexPage * 60),
    };
  }, [a1IndexPage, query]);

  const selectedEntry = content.entries.find(
    (entry) => entry.id === selectedEntryId,
  );
  const selectedEntryFavoriteExamples = selectedEntry
    ? selectedEntry.senses.flatMap((sense) => sense.examples.filter((example) => favorites.includes(example.id)))
    : [];
  const selectedEntryWordBook = selectedEntry
    ? wordBookCatalog.wordBooks.find((wordBook) => wordBook.entryIds.includes(selectedEntry.id))
    : undefined;
  const selectedDailyQueueIndex = selectedEntry
    ? dailyPlanState.queueEntryIds.indexOf(selectedEntry.id)
    : -1;
  const selectedEntryPosition = selectedDailyQueueIndex >= 0
    ? selectedDailyQueueIndex + 1
    : selectedEntry && selectedEntryWordBook
      ? selectedEntryWordBook.entryIds.indexOf(selectedEntry.id) + 1
      : selectedEntry
        ? content.entries.findIndex((entry) => entry.id === selectedEntry.id) + 1
        : 0;
  const selectedEntryTotal = selectedDailyQueueIndex >= 0
    ? dailyPlanState.queueEntryIds.length
    : selectedEntryWordBook?.entryIds.length || content.entries.length;
  const reviewItem = reviewableSenses.length
    ? reviewableSenses[Math.min(reviewCursor, reviewableSenses.length - 1)]
    : null;
  const exercise = content.exercises[exerciseIndex % content.exercises.length];
  const exerciseSense = allSenses.find(
    ({ sense }) => sense.id === exercise.senseId,
  );

  const masteredCount = Object.values(reviewState).filter(
    (record) => record.independentUses >= 2 && record.contexts.length >= 2,
  ).length;
  const dueCount = Object.entries(reviewState).filter(
    ([senseId, record]) => !familiarSenseIds.has(senseId) && record.nextReview <= datePlusDays(0),
  ).length;
  const shortTermDueEntryIds = (getDueShortTermItems(wordMemoryState, new Date()) as string[]).filter(
    (memoryKey) => {
      if (memoryKey.startsWith("sense:")) return !familiarSenseIds.has(memoryKey.slice("sense:".length));
      return !dailyPlanState.familiarEntryIds.includes(memoryKey);
    },
  );
  const totalDueCount = dueCount + shortTermDueEntryIds.length;
  const todayPlan = dailyPlanSummary(dailyPlanState);
  const learnedCount = Object.keys(reviewState).length;
  const completion = todayPlan.available
    ? Math.round((todayPlan.completed / todayPlan.available) * 100)
    : 0;
  const currentWordBook = wordBookCatalog.wordBooks.find(
    (wordBook) => wordBook.id === wordBookState.currentWordBookId,
  );
  const focusedWordBook = wordBookCatalog.wordBooks.find(
    (wordBook) => wordBook.id === focusedWordBookId,
  ) ?? currentWordBook ?? wordBookCatalog.wordBooks[0];
  const focusedWordBookStats = deriveWordBookStats(
    focusedWordBook,
    content.entries,
    reviewState,
    datePlusDays(0),
  );
  const filteredEntries = filterWordBookEntries(
    focusedWordBook,
    content.entries,
    reviewState,
    { query, status: wordEntryStatusFilter, today: datePlusDays(0) },
  ) as Entry[];

  useEffect(() => {
    const frame = window.requestAnimationFrame(() => {
      try {
        const saved = window.localStorage.getItem(storageKey);
        if (saved) {
          const parsed = JSON.parse(saved) as {
            favorites?: string[];
            reviewState?: Record<string, ReviewRecord>;
            activity?: Activity;
            speechRate?: "normal" | "slow";
            wordBookState?: WordBookState;
            wordMemoryState?: Record<string, MemoryRecord>;
            learningEvidence?: Record<string, LearningEvidence>;
            dailyPlanState?: DailyLearningPlanState;
          };
          setFavorites(parsed.favorites ?? []);
          setReviewState(parsed.reviewState ?? {});
          setActivity(parsed.activity ?? initialActivity);
          setSpeechRate(parsed.speechRate ?? "normal");
          setWordMemoryState(Object.fromEntries(
            Object.entries(parsed.wordMemoryState ?? {}).map(([entryId, value]) => [
              entryId,
              sanitizeMemoryRecord(value) as MemoryRecord,
            ]),
          ));
          setLearningEvidence(parsed.learningEvidence ?? {});
          setDailyPlanState(
            sanitizeDailyLearningPlanState(parsed.dailyPlanState) as DailyLearningPlanState,
          );
          const restoredWordBooks = sanitizeWordBookState(
            parsed.wordBookState,
            wordBookIds,
          ) as WordBookState;
          setWordBookState(restoredWordBooks);
          if (restoredWordBooks.currentWordBookId) {
            setFocusedWordBookId(restoredWordBooks.currentWordBookId);
          }
        }
      } catch {
        setToast("本地档案读取失败，已使用空白档案");
      } finally {
        setHydrated(true);
      }
    });
    return () => window.cancelAnimationFrame(frame);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    window.localStorage.setItem(
      storageKey,
      JSON.stringify({
        favorites,
        reviewState,
        activity,
        speechRate,
        wordBookState,
        wordMemoryState,
        learningEvidence,
        dailyPlanState,
      }),
    );
  }, [favorites, reviewState, activity, speechRate, wordBookState, wordMemoryState, learningEvidence, dailyPlanState, hydrated]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 2600);
    return () => window.clearTimeout(timer);
  }, [toast]);

  useEffect(() => {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => {
        // Offline caching is an enhancement; the app remains usable online.
      });
    }
  }, []);

  function navigate(view: View) {
    setActiveView(view);
    setSelectedEntryId(null);
    setSelectedExampleStudy(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function openEntry(entry: Entry, senseId?: string, mode: FlowMode = "learn") {
    setSelectedFlowMode(mode);
    setSelectedEntryId(entry.id);
    setSelectedSenseId(senseId ?? entry.senses[0].id);
  }

  function handleContextWord(word: string) {
    const normalized = normalizeSpanishToken(word);
    const completeEntry = lookupEntryByForm.get(normalized);
    setSelectedExampleStudy(null);
    if (completeEntry) {
      openEntry(completeEntry, completeEntry.senses[0].id, "lookup");
      return;
    }
    const indexEntry = a1Index.entries.find((entry) => normalizeSpanishToken(entry.lemma) === normalized)
      ?? a2Index.entries.find((entry) => normalizeSpanishToken(entry.lemma) === normalized);
    if (indexEntry) {
      setSelectedIndexPreview(indexEntry);
      return;
    }
    setToast(`“${word}”尚未匹配到独立词条，暂不编造释义`);
  }

  function recordLearningEvidence(
    entryId: string,
    event: { type: string; id?: string; value?: number },
    markDailyProgress = true,
  ) {
    const now = new Date().toISOString();
    setLearningEvidence((current) => {
      const previous = current[entryId] ?? {
        recognitionErrors: 0,
        lastReactionMs: null,
        visitedSenseIds: [],
        audioPlayCount: 0,
        viewedAnalysisIds: [],
        ratedSenseIds: [],
        wordCheckAttempts: 0,
        wordCheckCorrect: 0,
        completedSessions: 0,
        lastCardPosition: 0,
        lastStudiedAt: null,
      };
      const next = {
        ...previous,
        ratedSenseIds: previous.ratedSenseIds ?? [],
        wordCheckAttempts: previous.wordCheckAttempts ?? 0,
        wordCheckCorrect: previous.wordCheckCorrect ?? 0,
        lastStudiedAt: now,
      };
      if (event.type === "recognition_wrong") next.recognitionErrors += 1;
      if (event.type === "recognition_correct" && Number.isFinite(event.value)) {
        next.lastReactionMs = Math.max(0, Math.round(event.value ?? 0));
      }
      if (event.type === "sense_view" && event.id) {
        next.visitedSenseIds = Array.from(new Set([...next.visitedSenseIds, event.id]));
      }
      if (event.type === "audio_play") next.audioPlayCount += 1;
      if (event.type === "analysis_view" && event.id) {
        next.viewedAnalysisIds = Array.from(new Set([...next.viewedAnalysisIds, event.id]));
      }
      if (event.type === "sense_rating" && event.id) {
        next.ratedSenseIds = Array.from(new Set([...next.ratedSenseIds, event.id]));
      }
      if (event.type === "word_check") {
        next.wordCheckAttempts += 1;
        if (event.value === 1) next.wordCheckCorrect += 1;
      }
      if (event.type === "completed") next.completedSessions += 1;
      if (event.type === "card_position" && Number.isFinite(event.value)) {
        next.lastCardPosition = Math.max(0, Math.round(event.value ?? 0));
      }
      return { ...current, [entryId]: next };
    });

    if (event.type === "recognition_wrong") {
      setWordMemoryState((current) => ({
        ...current,
        [entryId]: scheduleMemoryReview(current[entryId] ?? createMemoryRecord(), "unknown", {
          now: new Date(),
          timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
          recognitionErrors: 1,
          source: "recognition_quiz_error",
        }) as MemoryRecord,
      }));
    }
    if (event.type === "completed" && markDailyProgress) {
      setDailyPlanState((current) =>
        markDailyEntryCompleted(current, entryId) as DailyLearningPlanState,
      );
      const memberWordBook = wordBookCatalog.wordBooks.find((wordBook) =>
        wordBook.entryIds.includes(entryId),
      );
      if (memberWordBook) {
        setWordBookState((current) => {
          const progress = current.progress[memberWordBook.id];
          if (!progress) return current;
          const currentPosition = memberWordBook.entryIds.indexOf(entryId);
          return {
            ...current,
            currentWordBookId: memberWordBook.id,
            progress: {
              ...current.progress,
              [memberWordBook.id]: {
                ...progress,
                state: "active",
                currentPosition: memberWordBook.entryIds.length
                  ? Math.min(currentPosition + 1, memberWordBook.entryIds.length)
                  : 0,
                learnedLexemeIds: Array.from(new Set([...progress.learnedLexemeIds, entryId])),
                lastStudiedAt: now,
              },
            },
          };
        });
      }
    }
  }

  function rateWordMemory(
    entryId: string,
    rating: MemoryRating,
    details: { recognitionErrors: number; reactionMs: number | null },
  ) {
    const current = wordMemoryState[entryId] ?? createMemoryRecord();
    const next = scheduleMemoryReview(current, rating, {
      now: new Date(),
      timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      preserveReset: details.recognitionErrors > 0,
      recognitionErrors: 0,
      reactionMs: details.reactionMs,
      source: "word_learning_completion",
    }) as MemoryRecord;
    setWordMemoryState((state) => ({ ...state, [entryId]: next }));
    setActivity((state) => ({
      ...state,
      sessions: state.sessions + (state.lastActive === datePlusDays(0) ? 0 : 1),
      answered: state.answered + 1,
      correct: state.correct + (rating === "known" && details.recognitionErrors === 0 ? 1 : 0),
      minutes: state.minutes + 3,
      lastActive: datePlusDays(0),
    }));
    setToast(`已记录“${rating === "unknown" ? "不认识" : rating === "unfamiliar" ? "不熟" : "认识"}”`);
    return next;
  }

  function rateSenseMemory(
    senseId: string,
    rating: MemoryRating,
    exampleId: string,
  ) {
    const memoryKey = `sense:${senseId}`;
    const currentMemory = wordMemoryState[memoryKey] ?? createMemoryRecord();
    const next = scheduleMemoryReview(currentMemory, rating, {
      now: new Date(),
      timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      source: "sense_card_rating",
    }) as MemoryRecord;
    setWordMemoryState((current) => ({ ...current, [memoryKey]: next }));
    setReviewState((current) => {
      const previous = current[senseId];
      const score = rating === "unknown" ? 0 : rating === "unfamiliar" ? 1 : 2;
      const matchedIntervalIndex = intervals.findIndex((days) => days >= next.intervalDays);
      const closestIntervalIndex = matchedIntervalIndex === -1
        ? intervals.length - 1
        : matchedIntervalIndex;
      return {
        ...current,
        [senseId]: {
          intervalIndex: closestIntervalIndex,
          score,
          lastReview: datePlusDays(0),
          nextReview: next.nextReviewDate ?? datePlusDays(1),
          attempts: (previous?.attempts ?? 0) + 1,
          independentUses: (previous?.independentUses ?? 0) + (rating === "known" ? 1 : 0),
          contexts: Array.from(new Set([...(previous?.contexts ?? []), exampleId])),
        },
      };
    });
    setToast(`当前义项已记录为“${rating === "unknown" ? "不认识" : rating === "unfamiliar" ? "不熟" : "认识"}”`);
    return next;
  }

  function availableLearningEntryIds(wordBook: WordBook) {
    const sourceIds = wordBook.isDevelopmentOnly ? wordBook.entryIds : wordBook.readyEntryIds;
    const learnedIds = wordBookState.progress[wordBook.id]?.learnedLexemeIds ?? [];
    return sourceIds.filter(
      (entryId) => content.entries.some((entry) => entry.id === entryId)
        && !learnedIds.includes(entryId)
        && !dailyPlanState.familiarEntryIds.includes(entryId),
    );
  }

  function buildQueueForWordBook(wordBook: WordBook) {
    return createOrResumeDailyQueue(dailyPlanState, {
      date: datePlusDays(0),
      wordBookId: wordBook.id,
      goal: dailyPlanState.dailyGoal,
      orderedEntryIds: availableLearningEntryIds(wordBook),
    }) as DailyLearningPlanState;
  }

  function openNextEntry(currentEntryId: string) {
    const completed = markDailyEntryCompleted(dailyPlanState, currentEntryId) as DailyLearningPlanState;
    const nextEntryId = nextUnfinishedEntry(completed);
    setDailyPlanState(completed);
    if (!nextEntryId) {
      setSelectedEntryId(null);
      setSelectedSenseId(null);
      setDailySessionComplete(true);
      return;
    }
    const next = content.entries.find((entry) => entry.id === nextEntryId);
    if (!next) {
      setSelectedEntryId(null);
      setDailySessionComplete(true);
      return;
    }
    setSelectedEntryId(next.id);
    setSelectedSenseId(next.senses[0].id);
  }

  function cutFamiliarEntry(entryId: string) {
    const wasInTodayQueue = dailyPlanState.queueEntryIds.includes(entryId);
    const marked = markEntryFamiliar(dailyPlanState, entryId) as DailyLearningPlanState;
    setDailyPlanState(marked);
    setToast("已斩：加入熟词本，不再进入新词或复习队列");
    if (!wasInTodayQueue) {
      setSelectedEntryId(null);
      setSelectedSenseId(null);
      return;
    }
    const nextEntryId = nextUnfinishedEntry(marked);
    if (!nextEntryId) {
      setSelectedEntryId(null);
      setSelectedSenseId(null);
      setDailySessionComplete(true);
      return;
    }
    const next = content.entries.find((entry) => entry.id === nextEntryId);
    if (next) {
      setSelectedEntryId(next.id);
      setSelectedSenseId(next.senses[0].id);
    }
  }

  function restoreFromFamiliarBook(entryId: string) {
    setDailyPlanState((current) =>
      restoreFamiliarEntry(current, entryId) as DailyLearningPlanState,
    );
    setToast("已移出熟词本，将在后续新词计划中重新出现");
  }

  function toggleOverviewFamiliar(entryId: string, lemma: string) {
    const isFamiliar = dailyPlanState.familiarEntryIds.includes(entryId);
    if (isFamiliar) {
      restoreFromFamiliarBook(entryId);
      return;
    }
    if (cuttingEntryIds.includes(entryId)) return;
    setCuttingEntryIds((current) => [...current, entryId]);
    setToast(`正在斩除 ${lemma}…`);
    window.setTimeout(() => {
      setDailyPlanState((current) => markEntryFamiliar(current, entryId) as DailyLearningPlanState);
      setCuttingEntryIds((current) => current.filter((candidate) => candidate !== entryId));
      setToast(`已斩：${lemma} 已移入熟词本，不再安排学习或复习`);
    }, 420);
  }

  function openWordBookOverview(wordBook: WordBook) {
    setFocusedWordBookId(wordBook.id);
    setSelectedWordBookId(wordBook.id);
    setQuery("");
    setA1IndexPage(1);
  }

  function openNextReviewEntry() {
    const nextCursor = reviewCursor + 1;
    if (nextCursor >= reviewableSenses.length) {
      setSelectedEntryId(null);
      setReviewCursor(0);
      setToast("本轮卡片复习已完成，没有循环回第一项");
      return;
    }
    const next = reviewableSenses[nextCursor];
    setReviewCursor(nextCursor);
    openEntry(next.entry, next.sense.id, "review");
  }

  function toggleFavorite(id: string, label: string) {
    setFavorites((current) => {
      const saved = current.includes(id);
      setToast(saved ? `已取消收藏：${label}` : `已收藏：${label}`);
      return saved ? current.filter((item) => item !== id) : [...current, id];
    });
  }

  function speak(text: string, rateOverride?: "normal" | "slow") {
    if (!("speechSynthesis" in window)) {
      setToast("当前浏览器不支持语音合成");
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "es-ES";
    utterance.rate = (rateOverride ?? speechRate) === "slow" ? 0.72 : 0.95;
    const spanishVoice = window.speechSynthesis
      .getVoices()
      .find((voice) => voice.lang.toLocaleLowerCase().startsWith("es-es"));
    if (spanishVoice) utterance.voice = spanishVoice;
    window.speechSynthesis.speak(utterance);
  }

  function checkPractice() {
    if (!answer.trim()) {
      setToast("请先填写答案");
      return;
    }
    const normalized = normalizeAnswer(answer);
    const correct = exercise.answers.some(
      (variant) => normalizeAnswer(variant) === normalized,
    );
    setPracticeFeedback({
      correct,
      message: correct
        ? exercise.feedback
        : `这个答案暂未匹配到已收录变体。${exercise.feedback}`,
    });
    setActivity((current) => ({
      ...current,
      sessions: current.sessions + (current.lastActive === datePlusDays(0) ? 0 : 1),
      answered: current.answered + 1,
      correct: current.correct + (correct ? 1 : 0),
      minutes: current.minutes + 2,
      lastActive: datePlusDays(0),
    }));
  }

  function nextExercise() {
    setExerciseIndex((current) => (current + 1) % content.exercises.length);
    setAnswer("");
    setShowHint(false);
    setPracticeFeedback(null);
  }

  async function toggleRecording() {
    if (recording && mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      setRecording(false);
      return;
    }
    if (!navigator.mediaDevices?.getUserMedia || !("MediaRecorder" in window)) {
      setToast("当前浏览器无法使用录音功能");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      chunksRef.current = [];
      recorder.ondataavailable = (event) => {
        if (event.data.size) chunksRef.current.push(event.data);
      };
      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, {
          type: recorder.mimeType || "audio/webm",
        });
        if (recordingUrl) URL.revokeObjectURL(recordingUrl);
        setRecordingUrl(URL.createObjectURL(blob));
        stream.getTracks().forEach((track) => track.stop());
        setActivity((current) => ({
          ...current,
          recordings: current.recordings + 1,
          minutes: current.minutes + 1,
          lastActive: datePlusDays(0),
        }));
        setToast(`第 ${recordingTake} 次表达已录下，可立即回放`);
      };
      mediaRecorderRef.current = recorder;
      recorder.start();
      setRecording(true);
    } catch {
      setToast("未获得麦克风权限，请在浏览器设置中允许");
    }
  }

  function exportProfile() {
    const payload = {
      schemaVersion: 3,
      exportedAt: new Date().toISOString(),
      appVersion: "0.5.0-dev.1",
      favorites,
      reviewState,
      activity,
      speechRate,
      wordBookState,
      wordMemoryState,
      learningEvidence,
      dailyPlanState,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `contexto-backup-${datePlusDays(0)}.json`;
    link.click();
    URL.revokeObjectURL(url);
    setToast("学习档案已导出");
  }

  function importProfile(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result)) as {
          schemaVersion: number;
          favorites?: string[];
          reviewState?: Record<string, ReviewRecord>;
          activity?: Activity;
          speechRate?: "normal" | "slow";
          wordBookState?: WordBookState;
          wordMemoryState?: Record<string, MemoryRecord>;
          learningEvidence?: Record<string, LearningEvidence>;
          dailyPlanState?: DailyLearningPlanState;
        };
        if (![1, 2, 3].includes(parsed.schemaVersion)) throw new Error("unsupported");
        setFavorites(parsed.favorites ?? []);
        setReviewState(parsed.reviewState ?? {});
        setActivity(parsed.activity ?? initialActivity);
        setSpeechRate(parsed.speechRate ?? "normal");
        setWordMemoryState(Object.fromEntries(
          Object.entries(parsed.wordMemoryState ?? {}).map(([entryId, value]) => [
            entryId,
            sanitizeMemoryRecord(value) as MemoryRecord,
          ]),
        ));
        setLearningEvidence(parsed.learningEvidence ?? {});
        setDailyPlanState(
          sanitizeDailyLearningPlanState(parsed.dailyPlanState) as DailyLearningPlanState,
        );
        if (parsed.schemaVersion >= 2) {
          const restoredWordBooks = sanitizeWordBookState(
            parsed.wordBookState,
            wordBookIds,
          ) as WordBookState;
          setWordBookState(restoredWordBooks);
          if (restoredWordBooks.currentWordBookId) {
            setFocusedWordBookId(restoredWordBooks.currentWordBookId);
          }
        }
        setToast("备份恢复成功");
      } catch {
        setToast("无法恢复：文件格式不正确");
      }
    };
    reader.readAsText(file);
    event.target.value = "";
  }

  function resetProfile() {
    if (!window.confirm("确定清空当前设备上的学习记录吗？请先导出备份。")) return;
    setFavorites([]);
    setReviewState({});
    setActivity(initialActivity);
    setWordMemoryState({});
    setLearningEvidence({});
    setDailyPlanState(createDailyLearningPlanState() as DailyLearningPlanState);
    setDailySessionComplete(false);
    setWordBookState(createWordBookState(wordBookIds) as WordBookState);
    setFocusedWordBookId("wordbook-a1-core");
    window.localStorage.removeItem(storageKey);
    setToast("本地学习档案已清空");
  }

  function chooseWordBook(wordBook: WordBook) {
    if (!wordBook.isEnabled) {
      setToast(`${wordBook.name} 仍在规划中，暂不能启用`);
      return;
    }
    setFocusedWordBookId(wordBook.id);
    setWordBookState((current) =>
      activateWordBook(current, wordBook.id) as WordBookState,
    );
    setDailyPlanState((current) => current.wordBookId === wordBook.id
      ? current
      : {
          ...current,
          queueDate: null,
          wordBookId: wordBook.id,
          queueEntryIds: [],
          completedEntryIds: [],
        });
    setDailySessionComplete(false);
    setToast(`当前词书已切换为：${wordBook.name}`);
  }

  function pauseWordBook(wordBook: WordBook) {
    setWordBookState((current) =>
      toggleWordBookPaused(current, wordBook.id) as WordBookState,
    );
    const paused = wordBookState.progress[wordBook.id]?.state !== "paused";
    setToast(paused ? `已暂停：${wordBook.name}` : `已继续：${wordBook.name}`);
  }

  function restartWordBook(wordBook: WordBook) {
    if (!window.confirm(`确定重新开始“${wordBook.name}”吗？其他词书和全局收藏不会被删除。`)) return;
    setWordBookState((current) =>
      resetWordBookProgress(current, wordBook.id) as WordBookState,
    );
    if (dailyPlanState.wordBookId === wordBook.id) {
      setDailyPlanState((current) => ({
        ...current,
        queueDate: null,
        wordBookId: null,
        queueEntryIds: [],
        completedEntryIds: [],
      }));
    }
    setToast(`已重置这本词书的位置：${wordBook.name}`);
  }

  function continueWordBook(wordBook: WordBook) {
    setFocusedWordBookId(wordBook.id);
    const availableEntryIds = availableLearningEntryIds(wordBook);
    if (!availableEntryIds.length) {
      setToast(dailyPlanState.familiarEntryIds.length
        ? "当前可用词都已进入熟词本，没有需要学习的新词"
        : `${wordBook.indexedEntryCount ?? wordBook.entryIds.length} 个索引词中尚无内容审核完成的可学习词`);
      return;
    }
    const queue = buildQueueForWordBook(wordBook);
    const nextEntryId = nextUnfinishedEntry(queue);
    setDailyPlanState(queue);
    setDailySessionComplete(false);
    if (!nextEntryId) {
      setDailySessionComplete(true);
      return;
    }
    const entry = content.entries.find((candidate) => candidate.id === nextEntryId);
    if (entry) openEntry(entry);
  }

  function startCardLearning() {
    const a1Book = wordBookCatalog.wordBooks.find(
      (wordBook) => wordBook.id === "wordbook-a1-core",
    );
    const developmentBook = wordBookCatalog.wordBooks.find(
      (wordBook) => wordBook.id === "wordbook-v1-development",
    );
    const preferredBook = currentWordBook && !currentWordBook.isDevelopmentOnly
      ? currentWordBook
      : a1Book && availableLearningEntryIds(a1Book).length
        ? a1Book
        : developmentBook;
    if (!preferredBook) {
      setDailySessionComplete(true);
      setToast("今天可用的新词已处理完；系统不会重新循环。可在词书概览恢复熟词或重新开始词书");
      return;
    }
    if (!availableLearningEntryIds(preferredBook).length) {
      setDailySessionComplete(true);
      setToast(`“${preferredBook.name}”当前没有尚未学习的完整内容；系统不会改学其他词书`);
      return;
    }
    setFocusedWordBookId(preferredBook.id);
    setWordBookState((current) => activateWordBook(current, preferredBook.id) as WordBookState);
    continueWordBook(preferredBook);
    setToast(`已从“${preferredBook.name}”按语义顺序建立今日 ${dailyPlanState.dailyGoal} 词队列`);
  }

  function renderHome() {
    return (
      <div className="view-stack">
        <section className="hero-card">
          <div className="hero-copy">
            <span className="eyebrow light">HOY · 今日学习</span>
            <h1>Buenas tardes.</h1>
            <p>
              今天先把一个词义放进真实场景，再用自己的声音把它说出来。
            </p>
            <div className="hero-actions">
              <button className="button coral" onClick={startCardLearning}>
                {todayPlan.isComplete ? "今日新词计划已完成" : "开始单词卡片学习"} <span>→</span>
              </button>
              <button className="button ghost-light" onClick={() => navigate("library")}>
                查看与选择词书
              </button>
            </div>
            <div className="home-daily-goal" aria-label="首页每日新词数量">
              <span>每日学习计划</span>
              <div>
                {(DAILY_WORD_GOALS as readonly number[]).map((goal) => (
                  <button
                    key={goal}
                    className={dailyPlanState.dailyGoal === goal ? "active" : ""}
                    onClick={() => setDailyPlanState((current) =>
                      setDailyGoal(current, goal) as DailyLearningPlanState)}
                  >{goal} 词</button>
                ))}
              </div>
              <small>当前词书：{currentWordBook?.name ?? "尚未选择，将默认使用 A1"}</small>
            </div>
          </div>
          <div className="progress-orbit" aria-label={`今日计划完成 ${completion}%`}>
            <div
              className="progress-ring"
              style={{ "--progress": `${completion * 3.6}deg` } as React.CSSProperties}
            >
              <div>
                <strong>{completion}%</strong>
                <span>今日计划</span>
              </div>
            </div>
            <small>{todayPlan.completed}/{todayPlan.available || dailyPlanState.dailyGoal} 个今日新词已完成</small>
          </div>
        </section>

        <section className="document-flow-strip" aria-label="修改文档规定的学习流程">
          <div><span>01</span><strong>四选一识别</strong><small>答错继续选择</small></div>
          <div><span>02</span><strong>义项独立成卡</strong><small>每项至少四例句</small></div>
          <div><span>03</span><strong>双层切换</strong><small>小切例句 · 大切义项</small></div>
          <div><span>04</span><strong>分别安排复习</strong><small>不认识 · 不熟 · 认识</small></div>
        </section>

        <section>
          <div className="section-heading">
            <div>
              <span className="eyebrow">学习路径</span>
              <h2>今天的 3 个小任务</h2>
            </div>
            <span className="muted">约 12 分钟</span>
          </div>
          <div className="plan-grid">
            <button className="plan-card current" onClick={startCardLearning}>
              <span className="plan-index">01</span>
              <span className="plan-icon">词</span>
              <strong>完成卡片式单词学习</strong>
              <p>今日目标 {dailyPlanState.dailyGoal} 词；当前有 {todayPlan.remaining} 词待完成</p>
              <span className="plan-status">有限队列 · 完成后停止 →</span>
            </button>
            <button className="plan-card" onClick={() => navigate("review")}>
              <span className="plan-index">02</span>
              <span className="plan-icon">忆</span>
              <strong>主动回忆词义</strong>
              <p>{totalDueCount ? `${totalDueCount} 项今天需要再次提取` : "先建立第一条复习记录"}</p>
              <span className="plan-status">0 / 1</span>
            </button>
            <button className="plan-card" onClick={() => navigate("practice")}>
              <span className="plan-index">03</span>
              <span className="plan-icon">说</span>
              <strong>表达并再次复说</strong>
              <p>听提示，说出你的西语版本</p>
              <span className="plan-status">0 / 1</span>
            </button>
          </div>
        </section>

        <section className="dashboard-grid">
          <article className="anchor-card">
            <div className="card-topline">
              <span className="eyebrow">今日记忆锚点</span>
              <button
                className={`heart-button ${favorites.includes("ex-quedar-meet-1") ? "active" : ""}`}
                onClick={() => toggleFavorite("ex-quedar-meet-1", "咖啡约见例句")}
                aria-label="收藏例句"
              >
                {favorites.includes("ex-quedar-meet-1") ? "♥" : "♡"}
              </button>
            </div>
            <button
              className="word-link"
              onClick={() => openEntry(content.entries[0], "sense-quedar-meet")}
            >
              quedar <span>v.</span>
            </button>
            <p className="anchor-sentence">
              Mañana he <mark>quedado con</mark> Ana para tomar un café.
            </p>
            <p className="anchor-translation">我约了明天和安娜喝咖啡。</p>
            <div className="card-actions">
              <button className="chip-action" onClick={() => speak("Mañana he quedado con Ana para tomar un café.")}>
                ◉ 听例句
              </button>
              <button className="text-action" onClick={() => openEntry(content.entries[0], "sense-quedar-meet")}>
                查看结构分析 →
              </button>
            </div>
          </article>

          <article className="evidence-card">
            <span className="eyebrow">学习证据</span>
            <div className="evidence-row">
              <div>
                <strong>{activity.answered}</strong>
                <span>次作答</span>
              </div>
              <div>
                <strong>{activity.recordings}</strong>
                <span>段录音</span>
              </div>
              <div>
                <strong>{masteredCount}</strong>
                <span>义项达标</span>
              </div>
            </div>
            <div className="evidence-note">
              <span className="status-dot" />
              {masteredCount
                ? "已有义项获得两个场景中的主动使用证据"
                : "当前能力判断：缺少证据。完成练习后才会更新。"}
            </div>
            <button className="text-action" onClick={() => navigate("profile")}>
              查看完整档案 →
            </button>
          </article>
        </section>
      </div>
    );
  }

  function renderLibrary() {
    return (
      <div className="view-stack wordbook-view">
        <section className="page-intro compact">
          <span className="eyebrow">LIBROS · 词书</span>
          <h1>选择你的学习路线</h1>
          <p>切换词书不会删除其他词书的学习位置；同一个词未来可加入多本词书，但核心内容只维护一份。</p>
        </section>

        <aside className="storage-mode-note">
          <span>双运行模式 · 当前公开演示</span>
          <p>这个网页可在电脑和手机打开，但学习档案暂存在各自浏览器中，设备间不会自动同步。后续本地版会由 Mac 上的 SQLite 数据库统一保存。</p>
        </aside>

        <section className="wordbook-experience-callout">
          <div>
            <span className="eyebrow">A1 词书 · 合法索引已导入</span>
            <h2>835 个 A1 核心候选词，内容分批精建</h2>
            <p>索引来自 ELELex（CC BY-NC-SA 4.0）。每个词要补齐常用词性与义项、每义项至少 4 条精选例句、详细分析和练习后，才会加入每日学习队列。</p>
          </div>
          <div className="wordbook-experience-actions">
            <button className="button outline" onClick={() => {
              const a1WordBook = wordBookCatalog.wordBooks.find((wordBook) => wordBook.id === "wordbook-a1-core");
              if (a1WordBook) openWordBookOverview(a1WordBook);
            }}>进入 A1 单词概览</button>
            <button className="button coral" onClick={startCardLearning}>开始语义分组学习 →</button>
          </div>
        </section>

        <section className="wordbook-toolbar" aria-label="筛选词书">
          <label className="search-box compact-search">
            <span>⌕</span>
            <input
              value={wordBookQuery}
              onChange={(event) => setWordBookQuery(event.target.value)}
              placeholder="搜索词书名称或场景…"
            />
            {wordBookQuery && <button onClick={() => setWordBookQuery("")}>清除</button>}
          </label>
          <div className="wordbook-filter-tabs">
            {([
              ["all", "全部"],
              ["A1", "A1"],
              ["A2", "A2"],
              ["B1", "B1"],
              ["planned", "未来词书"],
              ["DEV", "开发测试"],
            ] as Array<[WordBookLevelFilter, string]>).map(([id, label]) => (
              <button
                key={id}
                className={wordBookLevelFilter === id ? "active" : ""}
                onClick={() => setWordBookLevelFilter(id)}
              >
                {label}
              </button>
            ))}
          </div>
        </section>

        <div className="wordbook-grid">
          {visibleWordBooks.map((wordBook) => {
            const stats = deriveWordBookStats(
              wordBook,
              content.entries,
              reviewState,
              datePlusDays(0),
            );
            const progress = wordBookState.progress[wordBook.id];
            const isCurrent = wordBook.id === wordBookState.currentWordBookId;
            const isFocused = wordBook.id === focusedWordBook.id;
            return (
              <article
                className={`wordbook-card ${isCurrent ? "current" : ""} ${!wordBook.isEnabled ? "planned" : ""} ${isFocused ? "focused" : ""}`}
                key={wordBook.id}
              >
                <div className="wordbook-card-head">
                  <span className={`wordbook-level ${wordBook.isDevelopmentOnly ? "development" : ""}`}>
                    {wordBook.level}
                  </span>
                  <span className={`wordbook-status ${wordBook.isEnabled ? "available" : ""}`}>
                    {isCurrent ? "当前词书" : contentStatusLabels[wordBook.contentStatus] ?? wordBook.contentStatus}
                  </span>
                </div>
                <p className="wordbook-kicker">{wordBook.shortLabel}</p>
                <h2>{wordBook.name}</h2>
                <p className="wordbook-description">{wordBook.description}</p>
                <div className="wordbook-stats">
                  <span><strong>{stats.indexed}</strong>索引词条</span>
                  <span><strong>{stats.ready}</strong>可学习</span>
                  <span><strong>{stats.learned}</strong>已学习</span>
                  <span><strong>{stats.mastered}</strong>已掌握</span>
                </div>
                <div className="wordbook-progress-track" aria-label={`进度 ${stats.progressPercent}%`}>
                  <span style={{ width: `${stats.progressPercent}%` }} />
                </div>
                <div className="wordbook-card-meta">
                  <span>{progress ? wordBookStateLabels[progress.state] : "未开始"}</span>
                  <span>{stats.due} 待复习</span>
                  <span>{stats.progressPercent}%</span>
                </div>
                <div className="wordbook-actions">
                  <button className="button outline" onClick={() => {
                    openWordBookOverview(wordBook);
                  }}>
                    {wordBook.id === "wordbook-a1-core" ? "进入单词概览" : "查看详情"}
                  </button>
                  {wordBook.isEnabled ? (
                    <button
                      className={`button ${isCurrent ? "dark" : "coral"}`}
                      onClick={() => chooseWordBook(wordBook)}
                    >
                      {isCurrent ? "保持当前" : "选择词书"}
                    </button>
                  ) : (
                    <button className="button outline" disabled>尚未开放</button>
                  )}
                </div>
              </article>
            );
          })}
        </div>

        {!visibleWordBooks.length && (
          <div className="empty-state compact-empty">
            <strong>没有匹配的词书</strong>
            <p>清除搜索词或切换筛选条件后再试。</p>
          </div>
        )}

        {selectedWordBookId && (
        <div className="wordbook-modal-backdrop" onClick={() => setSelectedWordBookId(null)}>
        <section
          id="wordbook-overview"
          className="wordbook-detail wordbook-modal"
          role="dialog"
          aria-modal="true"
          aria-label={`${focusedWordBook.name} 详情`}
          onClick={(event) => event.stopPropagation()}
        >
          <button
            className="wordbook-modal-close"
            onClick={() => setSelectedWordBookId(null)}
            aria-label={`关闭 ${focusedWordBook.name}`}
          >×</button>
          <div className="wordbook-detail-head">
            <div>
              <span className="eyebrow">当前查看 · {focusedWordBook.level}</span>
              <h2>{focusedWordBook.name}</h2>
              <p>{focusedWordBook.sourceNotice}</p>
            </div>
            <div className="wordbook-detail-actions">
              {focusedWordBook.isEnabled && (
                <>
                  <button
                    className="button coral"
                    disabled={!focusedWordBook.isDevelopmentOnly && !focusedWordBook.readyEntryIds.length}
                    onClick={() => continueWordBook(focusedWordBook)}
                  >
                    {!focusedWordBook.isDevelopmentOnly && !focusedWordBook.readyEntryIds.length
                      ? "内容分批建设中"
                      : wordBookState.progress[focusedWordBook.id]?.currentPosition ? "继续上次位置" : "开始学习"}
                  </button>
                  <button className="button outline" onClick={() => pauseWordBook(focusedWordBook)}>
                    {wordBookState.progress[focusedWordBook.id]?.state === "paused" ? "恢复词书" : "暂停词书"}
                  </button>
                  <button className="text-action danger-text" onClick={() => restartWordBook(focusedWordBook)}>
                    重新开始
                  </button>
                </>
              )}
            </div>
          </div>

          <div className="wordbook-source-grid">
            <div><span>词书来源</span><strong>{focusedWordBook.sourceName}</strong></div>
            <div><span>授权状态</span><strong>{focusedWordBook.authorizationStatus}</strong></div>
            <div><span>版本 / 更新</span><strong>v{focusedWordBook.version} · {focusedWordBook.updatedAt}</strong></div>
            <div><span>真实内容状态</span><strong>{focusedWordBookStats.indexed} 个索引 / {focusedWordBookStats.ready} 个可进入学习</strong></div>
          </div>
          <p className="license-note">许可说明：{focusedWordBook.licenseNotice}</p>

          {focusedWordBook.id === "wordbook-a1-core" ? (
            <section className="a1-index-browser">
              <section className="a1-semantic-overview" aria-label="A1 语义分组单词概览">
                <div className="a1-overview-heading">
                  <div>
                    <span className="eyebrow">先概览，再开始</span>
                    <h3>按语义对比学习，不按字母排序</h3>
                    <p>{a1SemanticPlan.meta.notice}</p>
                  </div>
                  <div><strong>{a1Content.entries.length}</strong><span>完整可学词</span><small>{a1Content.entries.reduce((sum, entry) => sum + entry.senses.length, 0)} 个常用义项 · 每义项 4 例句</small></div>
                </div>

                <div className="simple-word-panel">
                  <div><span>过于简单？可在学习前直接“斩”</span><small>这些索引词仍保留来源记录，但不会强迫你逐个学习。</small></div>
                  <div className="simple-word-list">
                    {a1SemanticPlan.simpleFunctionWords.map((entryId) => {
                      const indexEntry = a1IndexById.get(entryId);
                      if (!indexEntry) return null;
                      const familiar = dailyPlanState.familiarEntryIds.includes(entryId);
                      const cutting = cuttingEntryIds.includes(entryId);
                      if (familiar && !cutting) return null;
                      return (
                        <button
                          key={entryId}
                          className={cutting ? "cutting" : ""}
                          disabled={cutting}
                          onClick={() => toggleOverviewFamiliar(entryId, indexEntry.lemma)}
                        >
                          <strong lang="es">{indexEntry.lemma}</strong><span>{cutting ? "移入中…" : "斩"}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="semantic-unit-list">
                  {a1SemanticPlan.units.map((unit, unitIndex) => (
                    <article key={unit.id} className="semantic-unit-card">
                      <header><span>{String(unitIndex + 1).padStart(2, "0")}</span><div><h4>{unit.name}</h4><p>{unit.description}</p></div></header>
                      <div>
                        {unit.entryIds.map((entryId) => {
                          const entry = contentEntryById.get(entryId);
                          if (!entry) return null;
                          const familiar = dailyPlanState.familiarEntryIds.includes(entryId);
                          const cutting = cuttingEntryIds.includes(entryId);
                          if (familiar && !cutting) return null;
                          const exampleCount = entry.senses.reduce((sum, sense) => sum + sense.examples.length, 0);
                          return (
                            <section key={entryId} className={cutting ? "semantic-word cutting" : "semantic-word"}>
                              <div><strong lang="es">{entry.lemma}</strong><span>{entry.summaryZh}</span><small>{entry.senses.length} 个常用义项 · {exampleCount} 条精选例句</small></div>
                              <div>
                                <button className="button outline" disabled={cutting} onClick={() => toggleOverviewFamiliar(entryId, entry.lemma)}>{cutting ? "移入中…" : "斩"}</button>
                                <button className="button dark" disabled={cutting} onClick={() => openEntry(entry)}>学习</button>
                              </div>
                            </section>
                          );
                        })}
                      </div>
                    </article>
                  ))}
                </div>
              </section>

              <div className="a1-index-head">
                <div>
                  <span className="eyebrow">已导入索引 · 尚待内容建设</span>
                  <h3>{a1Index.meta.title}</h3>
                  <p>{a1Index.meta.notice}</p>
                </div>
                <div className="a1-index-count">
                  <strong>{a1Index.meta.indexedLexemes}</strong>
                  <span>核心候选词</span>
                  <small>{a1Content.entries.length} 个可进入学习</small>
                </div>
              </div>
              <label className="search-box compact-search a1-index-search">
                <span>⌕</span>
                <input
                  value={query}
                  onChange={(event) => {
                    setQuery(event.target.value);
                    setA1IndexPage(1);
                  }}
                  placeholder="搜索 835 个 A1 索引词或词性…"
                />
                {query && <button onClick={() => { setQuery(""); setA1IndexPage(1); }}>清除</button>}
              </label>
              <div className="a1-index-list">
                {a1IndexMatches.visible.map((entry) => {
                  const readyEntry = contentEntryById.get(entry.id);
                  const familiar = dailyPlanState.familiarEntryIds.includes(entry.id);
                  const cutting = cuttingEntryIds.includes(entry.id);
                  if (familiar && !cutting) return null;
                  return (
                  <article key={entry.id} className={cutting ? "cutting" : ""}>
                    <span>{String(entry.priorityRank).padStart(3, "0")}</span>
                    <div>
                      <strong lang="es">{entry.lemma}</strong>
                      <small>{entry.partsOfSpeech.map((part) => indexPartOfSpeechLabels[part] ?? part).join(" · ")}</small>
                    </div>
                    <div>
                      <span>{entry.a1DocumentCount} 份 A1 来源文档</span>
                      <strong>{readyEntry ? `${readyEntry.senses.length} 个义项 · 内容可学习` : "待补齐义项与 4+ 例句"}</strong>
                    </div>
                    <div className="a1-index-actions">
                      {readyEntry && <button onClick={() => openEntry(readyEntry)}>学习</button>}
                      <button disabled={cutting} onClick={() => toggleOverviewFamiliar(entry.id, entry.lemma)}>{cutting ? "移入中…" : "斩"}</button>
                    </div>
                  </article>
                );})}
              </div>
              {!a1IndexMatches.total && (
                <div className="empty-state compact-empty"><strong>没有匹配的 A1 索引词</strong><p>尝试其他西语词形或词性。</p></div>
              )}
              {a1IndexMatches.visible.length < a1IndexMatches.total && (
                <button className="button outline a1-load-more" onClick={() => setA1IndexPage((page) => page + 1)}>
                  再显示 60 个 · 当前 {a1IndexMatches.visible.length}/{a1IndexMatches.total}
                </button>
              )}
              <p className="a1-index-method">筛选规则：{a1Index.meta.selectionRule} 来源：{a1Index.meta.sourceName} · {a1Index.meta.license}。</p>
            </section>
          ) : focusedWordBook.id === "wordbook-a2-core" ? (
            <section className="a1-index-browser" aria-label="A2 单词索引概览">
              <section className="a1-semantic-overview" aria-label="A2 第一批语义分组">
                <div className="a1-overview-heading">
                  <div>
                    <span className="eyebrow">A2 第一批可学内容</span>
                    <h3>动作关系成组，不按字母排序</h3>
                    <p>{a2SemanticPlan.meta.notice}</p>
                  </div>
                  <div><strong>{a2Content.entries.length}</strong><span>完整可学词</span><small>{a2Content.entries.reduce((sum, entry) => sum + entry.senses.length, 0)} 个重要义项 · {a2Content.entries.reduce((sum, entry) => sum + entry.senses.reduce((senseSum, sense) => senseSum + sense.examples.length, 0), 0)} 条长例句</small></div>
                </div>
                <div className="semantic-unit-list">
                  {a2SemanticPlan.units.map((unit, unitIndex) => (
                    <article key={unit.id} className="semantic-unit-card">
                      <header><span>{String(unitIndex + 1).padStart(2, "0")}</span><div><h4>{unit.name}</h4><p>{unit.description}</p></div></header>
                      <div>
                        {unit.entryIds.map((entryId) => {
                          const entry = contentEntryById.get(entryId);
                          if (!entry) return null;
                          const familiar = dailyPlanState.familiarEntryIds.includes(entryId);
                          const cutting = cuttingEntryIds.includes(entryId);
                          if (familiar && !cutting) return null;
                          const exampleCount = entry.senses.reduce((sum, sense) => sum + sense.examples.length, 0);
                          return (
                            <section key={entryId} className={cutting ? "semantic-word cutting" : "semantic-word"}>
                              <div><strong lang="es">{entry.lemma}</strong><span>{entry.summaryZh}</span><small>{entry.senses.length} 个重要义项 · {exampleCount} 条长例句与微课</small></div>
                              <div>
                                <button className="button outline" disabled={cutting} onClick={() => toggleOverviewFamiliar(entryId, entry.lemma)}>{cutting ? "移入中…" : "斩"}</button>
                                <button className="button dark" disabled={cutting} onClick={() => openEntry(entry)}>学习</button>
                              </div>
                            </section>
                          );
                        })}
                      </div>
                    </article>
                  ))}
                </div>
              </section>
              <div className="a1-index-head">
                <div>
                  <span className="eyebrow">A2 合法索引 · 内容分批精建</span>
                  <h3>{a2Index.meta.title}</h3>
                  <p>{a2Index.meta.notice}</p>
                </div>
                <div className="a1-index-count">
                  <strong>{a2Index.meta.indexedLexemes}</strong>
                  <span>A2 候选索引词</span>
                  <small>{a2Index.meta.sharedLexemes} 个与 A1 共享核心词条</small>
                </div>
              </div>
              <label className="search-box compact-search a1-index-search">
                <span>⌕</span>
                <input
                  value={query}
                  onChange={(event) => {
                    setQuery(event.target.value);
                    setA1IndexPage(1);
                  }}
                  placeholder={`搜索 ${a2Index.meta.indexedLexemes} 个 A2 索引词或词性…`}
                />
                {query && <button onClick={() => { setQuery(""); setA1IndexPage(1); }}>清除</button>}
              </label>
              <div className="a1-index-list">
                {a2IndexMatches.visible.map((entry) => {
                  const readyEntry = contentEntryById.get(entry.id);
                  const familiar = dailyPlanState.familiarEntryIds.includes(entry.id);
                  const cutting = cuttingEntryIds.includes(entry.id);
                  if (familiar && !cutting) return null;
                  return (
                    <article key={`${entry.level}-${entry.id}`} className={cutting ? "cutting" : ""}>
                      <span>{String(entry.priorityRank).padStart(4, "0")}</span>
                      <div>
                        <strong lang="es">{entry.lemma}</strong>
                        <small>{entry.partsOfSpeech.map((part) => indexPartOfSpeechLabels[part] ?? part).join(" · ")}</small>
                      </div>
                      <div>
                        <span>{entry.documentCount} 份 A2 来源文档</span>
                        <strong>{readyEntry ? `${readyEntry.senses.length} 个共享义项 · 可学习` : "待补齐全部重要义项与长例句"}</strong>
                      </div>
                      <div className="a1-index-actions">
                        {readyEntry && <button onClick={() => openEntry(readyEntry)}>学习</button>}
                        <button disabled={cutting} onClick={() => toggleOverviewFamiliar(entry.id, entry.lemma)}>{cutting ? "移入中…" : "斩"}</button>
                      </div>
                    </article>
                  );
                })}
              </div>
              {!a2IndexMatches.total && (
                <div className="empty-state compact-empty"><strong>没有匹配的 A2 索引词</strong><p>尝试其他西语词形或词性。</p></div>
              )}
              {a2IndexMatches.visible.length < a2IndexMatches.total && (
                <button className="button outline a1-load-more" onClick={() => setA1IndexPage((page) => page + 1)}>
                  再显示 60 个 · 当前 {a2IndexMatches.visible.length}/{a2IndexMatches.total}
                </button>
              )}
              <p className="a1-index-method">筛选规则：{a2Index.meta.selectionRule} 来源：{a2Index.meta.sourceName} · {a2Index.meta.license}。</p>
            </section>
          ) : focusedWordBook.entryIds.length > 0 ? (
            <>
              <div className="word-entry-tools">
                <label className="search-box compact-search">
                  <span>⌕</span>
                  <input
                    value={query}
                    onChange={(event) => setQuery(event.target.value)}
                    placeholder="在本词书中搜索单词、义项或词块…"
                  />
                  {query && <button onClick={() => setQuery("")}>清除</button>}
                </label>
                <label>
                  <span>学习状态</span>
                  <select
                    value={wordEntryStatusFilter}
                    onChange={(event) => setWordEntryStatusFilter(event.target.value as WordEntryStatusFilter)}
                  >
                    <option value="all">全部</option>
                    <option value="unlearned">未学</option>
                    <option value="learned">已学</option>
                    <option value="due">待复习</option>
                  </select>
                </label>
              </div>

              <div className="entry-grid compact-entry-grid">
                {filteredEntries.map((entry) => (
                  <article className="entry-card" key={entry.id}>
                    <div className="entry-head">
                      <div>
                        <span className="level-badge">{entry.level}</span>
                        <h2>{entry.lemma}</h2>
                        <p>{entry.partOfSpeech} · {entry.frequency}</p>
                      </div>
                      <button
                        className={`heart-button ${favorites.includes(entry.id) ? "active" : ""}`}
                        onClick={() => toggleFavorite(entry.id, entry.lemma)}
                        aria-label={`收藏 ${entry.lemma}`}
                      >
                        {favorites.includes(entry.id) ? "♥" : "♡"}
                      </button>
                    </div>
                    <p className="entry-summary">{entry.summaryZh}</p>
                    <div className="sense-preview-list">
                      {entry.senses.map((sense, index) => (
                        <button key={sense.id} onClick={() => openEntry(entry, sense.id)}>
                          <span>{String(index + 1).padStart(2, "0")}</span>
                          <div>
                            <strong>{sense.labelZh}</strong>
                            <small>{sense.chunks.slice(0, 2).join(" · ")}</small>
                          </div>
                          <i>→</i>
                        </button>
                      ))}
                    </div>
                    <div className="entry-footer">
                      <span>{entry.senses.reduce((sum, sense) => sum + sense.examples.length, 0)} 条场景例句</span>
                      <button onClick={() => openEntry(entry)}>进入卡片学习 →</button>
                    </div>
                  </article>
                ))}
              </div>
              {!filteredEntries.length && (
                <div className="empty-state compact-empty">
                  <strong>本词书中没有匹配词条</strong>
                  <p>尝试清除搜索词或选择“全部”状态。</p>
                </div>
              )}
            </>
          ) : (
            <div className="empty-state honest-empty">
              <strong>词书入口已经建立，词表尚未导入</strong>
              <p>下一阶段会先核验开放许可或用户合法提供的词表，再显示真实总量；现在不会用虚构数量填充。</p>
              <span>{wordBookCatalog.meta.notice}</span>
            </div>
          )}
        </section>
        </div>
        )}
      </div>
    );
  }

  function renderReview() {
    if (!reviewItem || !reviewableSenses.length) {
      return (
        <div className="view-stack review-view">
          <section className="page-intro compact center">
            <span className="eyebrow">REPASO · 主动复习</span>
            <h1>当前没有需要复习的词</h1>
            <p>被“斩”的熟词不会进入复习队列；你可以在收藏页的熟词本中恢复它们。</p>
          </section>
          <div className="empty-state honest-empty">
            <strong>复习队列为空</strong>
            <button className="button dark" onClick={() => navigate("favorites")}>查看熟词本</button>
          </div>
        </div>
      );
    }
    const record = reviewState[reviewItem.sense.id];
    const example = reviewItem.sense.examples[(record?.attempts ?? 0) % reviewItem.sense.examples.length];
    const savedExamples = reviewItem.entry.senses.flatMap((sense) =>
      sense.examples
        .filter((candidate) => favorites.includes(candidate.id))
        .map((candidate) => ({ sense, example: candidate })),
    );
    return (
      <div className="view-stack review-view">
        <section className="page-intro compact center">
          <span className="eyebrow">REPASO · 主动复习</span>
          <h1>用与学习页相同的完整卡片复习</h1>
          <p>义项、4 条例句、收藏锚点、详细分析和三档熟悉度都保留；评分仍按具体义项记录。</p>
        </section>
        <div className="review-progress">
          <span style={{ width: `${((reviewCursor + 1) / reviewableSenses.length) * 100}%` }} />
        </div>
        <article className="review-card review-launch-card">
          <div className="review-card-head">
            <span>{reviewCursor + 1} / {reviewableSenses.length}</span>
            <span>{reviewItem.sense.cardLabel} · {example.scene}</span>
          </div>
          <div className="review-word">
            <span>{reviewItem.entry.partOfSpeech}</span>
            <h2>{reviewItem.entry.lemma}</h2>
            <p>{reviewItem.sense.labelZh}</p>
          </div>
          <button className="listen-orb" onClick={() => speak(example.spanish)} aria-label="播放西语例句">
            ◉
          </button>
          <p className="review-sentence">{example.spanish}</p>
          <div className="review-answer compact-review-answer">
            <div className="answer-meaning"><span>当前义项</span><strong>{reviewItem.sense.labelZh}</strong><p>{example.chinese}</p></div>
            <div className="answer-chunks">{reviewItem.sense.chunks.map((chunk) => <span key={chunk}>{chunk}</span>)}</div>
          </div>
          <button className="button coral wide" onClick={() => openEntry(reviewItem.entry, reviewItem.sense.id, "review")}>
            进入完整卡片式复习 →
          </button>
        </article>
        <section className="review-favorite-section">
          <div className="section-heading"><div><span className="eyebrow">ANCLAS · 记忆锚点</span><h2>本词收藏例句</h2></div><span className="muted">{savedExamples.length} 条</span></div>
          {savedExamples.length ? (
            <div className="favorite-examples review-favorite-grid">
              {savedExamples.map(({ sense, example: savedExample }) => (
                <article key={savedExample.id}>
                  <div><span>{sense.labelZh}</span><small>{savedExample.scene}</small></div>
                  <p>{savedExample.spanish}</p><p>{savedExample.chinese}</p>
                  <button onClick={() => setSelectedExampleStudy({ entry: reviewItem.entry, sense, example: savedExample })}>打开详细学习 →</button>
                </article>
              ))}
            </div>
          ) : <div className="empty-state compact-empty"><strong>本词还没有收藏例句</strong><p>在卡片复习中可随时收藏，之后会在这里显示。</p></div>}
        </section>
        <p className="review-footnote">
          单词熟悉度采用可配置的 1 → 3 → 8 → 20 天参考周期；义项证据仍独立记录，不能凭一次“认识”永久掌握。
        </p>
      </div>
    );
  }

  function renderFavorites() {
    const favoriteEntries = content.entries.filter((entry) => favorites.includes(entry.id));
    const familiarItems = dailyPlanState.familiarEntryIds.map((entryId) => {
      const completeEntry = contentEntryById.get(entryId);
      const indexEntry = a1IndexById.get(entryId) ?? a2IndexById.get(entryId);
      return completeEntry
        ? { id: entryId, lemma: completeEntry.lemma, summary: completeEntry.summaryZh, ready: true }
        : indexEntry
          ? { id: entryId, lemma: indexEntry.lemma, summary: "A1 索引词 · 已在学习前斩", ready: false }
          : { id: entryId, lemma: entryId, summary: "旧版熟词记录", ready: false };
    });
    const favoriteExamples = content.entries.flatMap((entry) =>
      entry.senses.flatMap((sense) =>
        sense.examples
          .filter((example) => favorites.includes(example.id))
          .map((example) => ({ entry, sense, example })),
      ),
    );
    return (
      <div className="view-stack">
        <section className="page-intro compact">
          <span className="eyebrow">ANCLAS · 收藏</span>
          <h1>你的个人记忆锚点</h1>
          <p>收藏的例句会进入后续复习，而不只是静态书签。</p>
        </section>
        {!favoriteEntries.length && !favoriteExamples.length && !familiarItems.length ? (
          <div className="empty-state illustrated">
            <div className="empty-mark">♡</div>
            <strong>还没有收藏内容</strong>
            <p>从词库或首页收藏一个词条、义项或场景例句。</p>
            <button className="button dark" onClick={() => navigate("library")}>去词库看看</button>
          </div>
        ) : (
          <>
            {!!familiarItems.length && (
              <section className="familiar-book-section">
                <div className="section-heading">
                  <div><span className="eyebrow">斩 · 熟词本</span><h2>不再安排复习的熟词</h2></div>
                  <span className="muted">{familiarItems.length} 词</span>
                </div>
                <div className="familiar-word-list">
                  {familiarItems.map((entry) => (
                    <article key={entry.id}>
                      <div><strong lang="es">{entry.lemma}</strong><span>{entry.summary}</span></div>
                      <button className="button outline" onClick={() => restoreFromFamiliarBook(entry.id)}>恢复学习</button>
                    </article>
                  ))}
                </div>
              </section>
            )}
            {!!favoriteEntries.length && (
              <section>
                <div className="section-heading"><h2>收藏的单词</h2></div>
                <div className="favorite-list">
                  {favoriteEntries.map((entry) => (
                    <button key={entry.id} onClick={() => openEntry(entry)}>
                      <div><strong>{entry.lemma}</strong><span>{entry.summaryZh}</span></div><i>→</i>
                    </button>
                  ))}
                </div>
              </section>
            )}
            {!!favoriteExamples.length && (
              <section>
                <div className="section-heading"><h2>收藏的例句</h2></div>
                <div className="favorite-examples">
                  {favoriteExamples.map(({ entry, sense, example }) => (
                    <article key={example.id}>
                      <div><span>{entry.lemma}</span><small>{example.scene}</small></div>
                      <p>{example.spanish}</p>
                      <p>{example.chinese}</p>
                      <button onClick={() => setSelectedExampleStudy({ entry, sense, example })}>打开例句详细学习 →</button>
                    </article>
                  ))}
                </div>
              </section>
            )}
          </>
        )}
      </div>
    );
  }

  function renderPractice() {
    const oralSentence = exerciseSense?.sense.examples[0].english ?? "";
    const oralAnswer = exerciseSense?.sense.examples[0].spanish ?? "";
    return (
      <div className="view-stack">
        <section className="page-intro compact">
          <span className="eyebrow">PRÁCTICA · 练习</span>
          <h1>从理解走向主动表达</h1>
          <p>开放式答案按预设变体、标点和重音归一化处理，不假装理解所有表达。</p>
        </section>
        <div className="practice-tabs" role="tablist">
          <button className="active">书面练习</button>
          <button onClick={() => document.getElementById("oral-task")?.scrollIntoView({ behavior: "smooth" })}>口语复说</button>
        </div>
        <article className="exercise-card">
          <div className="exercise-meta">
            <span>{exercise.type === "context_gap" ? "语境填空" : "英译西"}</span>
            <span>{exerciseIndex + 1} / {content.exercises.length}</span>
          </div>
          <h2>{exercise.prompt}</h2>
          <p className="exercise-target">
            目标：<strong>{exerciseSense?.entry.lemma}</strong> · {exerciseSense?.sense.labelZh}
          </p>
          <textarea
            value={answer}
            onChange={(event) => setAnswer(event.target.value)}
            placeholder="在这里写下你的西语答案…"
            rows={3}
            disabled={!!practiceFeedback}
          />
          <div className="exercise-tools">
            <button className="text-action" onClick={() => setShowHint((current) => !current)}>
              {showHint ? "收起提示" : "需要提示？"}
            </button>
            <span>重音、大小写和标点会宽容处理</span>
          </div>
          {showHint && <div className="hint-box">提示：{exercise.hint}</div>}
          {practiceFeedback && (
            <div className={`feedback-box ${practiceFeedback.correct ? "correct" : "retry"}`}>
              <strong>{practiceFeedback.correct ? "✓ 可以接受" : "↻ 再比较一次"}</strong>
              <p>{practiceFeedback.message}</p>
              {!practiceFeedback.correct && <p>你的答案：{answer}</p>}
            </div>
          )}
          <div className="exercise-buttons">
            {!practiceFeedback ? (
              <button className="button dark" onClick={checkPractice}>检查答案</button>
            ) : (
              <button className="button dark" onClick={nextExercise}>下一题 →</button>
            )}
          </div>
        </article>

        <article className="oral-card" id="oral-task">
          <div className="oral-heading">
            <div>
              <span className="eyebrow">英西口语翻译 · 第 {recordingTake} 次表达</span>
              <h2>听或看英语，然后说西语</h2>
            </div>
            <span className="dev-badge">浏览器录音</span>
          </div>
          <div className="oral-prompt">
            <span>EN</span>
            <p>{oralSentence}</p>
          </div>
          <div className="record-controls">
            <button className={`record-button ${recording ? "recording" : ""}`} onClick={toggleRecording}>
              <span /> {recording ? "停止录音" : `录下第 ${recordingTake} 次表达`}
            </button>
            {recordingUrl && <audio controls src={recordingUrl} />}
          </div>
          {recordingUrl && (
            <div className="oral-reference">
              <button className="chip-action" onClick={() => speak(oralAnswer)}>◉ 听首选答案</button>
              <details>
                <summary>查看参考答案与说明</summary>
                <p className="reference-answer">{oralAnswer}</p>
                <p>{exerciseSense?.sense.examples[0].targetMeaning}</p>
                <p className="limitation">本版只提供录音、回放和参考表达，不虚构具体发音分数。</p>
              </details>
              {recordingTake === 1 && (
                <button
                  className="button coral"
                  onClick={() => {
                    setRecordingTake(2);
                    setRecordingUrl(null);
                    setToast("请结合反馈完成第二次复说");
                  }}
                >
                  开始第二次复说 →
                </button>
              )}
            </div>
          )}
        </article>
      </div>
    );
  }

  function renderProfile() {
    const accuracy = activity.answered
      ? Math.round((activity.correct / activity.answered) * 100)
      : 0;
    return (
      <div className="view-stack">
        <section className="page-intro compact">
          <span className="eyebrow">PERFIL · 学习档案</span>
          <h1>只展示有证据的进步</h1>
          <p>没有作答、录音或跨场景使用记录时，系统明确显示“缺少证据”。</p>
        </section>
        <div className="stats-grid">
          <article><span>学习时长</span><strong>{activity.minutes}</strong><small>分钟</small></article>
          <article><span>已学义项</span><strong>{learnedCount}</strong><small>/ {allSenses.length}</small></article>
          <article><span>答题正确率</span><strong>{activity.answered ? `${accuracy}%` : "—"}</strong><small>{activity.answered ? `${activity.answered} 次证据` : "缺少证据"}</small></article>
          <article><span>录音复说</span><strong>{activity.recordings}</strong><small>段录音</small></article>
        </div>
        <section className="profile-panel">
          <div className="section-heading">
            <div><span className="eyebrow">义项掌握证据</span><h2>当前学习状态</h2></div>
            <span className="muted">至少两个场景主动使用</span>
          </div>
          <div className="mastery-list">
            {allSenses.map(({ entry, sense }) => {
              const record = reviewState[sense.id];
              const qualified = record && record.independentUses >= 2 && record.contexts.length >= 2;
              return (
                <button key={sense.id} onClick={() => openEntry(entry, sense.id)}>
                  <div className="mastery-word"><strong>{entry.lemma}</strong><span>{sense.labelZh}</span></div>
                  <div className="mastery-evidence">
                    <span>{record?.attempts ?? 0} 次复习</span>
                    <span>{record?.contexts.length ?? 0} 个场景</span>
                  </div>
                  <div className={`mastery-status ${qualified ? "qualified" : ""}`}>
                    {qualified ? "已形成证据" : record ? `下次 ${formatDate(record.nextReview)}` : "缺少证据"}
                  </div>
                </button>
              );
            })}
          </div>
        </section>
      </div>
    );
  }

  function renderSettings() {
    const a1ExampleCount = a1Content.entries.reduce(
      (sum, entry) => sum + entry.senses.reduce((senseSum, sense) => senseSum + sense.examples.length, 0),
      0,
    );
    const a1SenseCount = a1Content.entries.reduce((sum, entry) => sum + entry.senses.length, 0);
    return (
      <div className="view-stack settings-view">
        <section className="page-intro compact">
          <span className="eyebrow">AJUSTES · 设置</span>
          <h1>本地数据与内容</h1>
          <p>学习数据默认保存在当前浏览器；重要修改前请先导出备份。</p>
        </section>
        <section className="settings-card daily-plan-settings">
          <div>
            <span className="settings-icon">日</span>
            <div>
              <h2>每日新词计划</h2>
              <p>选择每天进入有限新词队列的数量；全部完成后停止，不会从第一个词重新循环。</p>
            </div>
          </div>
          <div className="daily-goal-options" aria-label="每日新词数量">
            {(DAILY_WORD_GOALS as readonly number[]).map((goal) => (
              <button
                key={goal}
                className={dailyPlanState.dailyGoal === goal ? "active" : ""}
                onClick={() => setDailyPlanState((current) =>
                  setDailyGoal(current, goal) as DailyLearningPlanState)}
              >
                <strong>{goal}</strong><span>词／日</span>
              </button>
            ))}
          </div>
        </section>
        <InstallAppCard />
        <section className="settings-card">
          <div><span className="settings-icon">◉</span><div><h2>西班牙语音频</h2><p>使用浏览器提供的合法合成语音，优先选择 es-ES。</p></div></div>
          <label className="segmented">
            <button className={speechRate === "normal" ? "active" : ""} onClick={() => setSpeechRate("normal")}>正常</button>
            <button className={speechRate === "slow" ? "active" : ""} onClick={() => setSpeechRate("slow")}>慢速</button>
          </label>
        </section>
        <section className="settings-card vertical">
          <div><span className="settings-icon">⇩</span><div><h2>备份与恢复</h2><p>导出收藏、复习排程和学习记录；恢复前请确认文件来源。</p></div></div>
          <div className="settings-actions">
            <button className="button dark" onClick={exportProfile}>导出学习档案</button>
            <label className="button outline">从备份恢复<input type="file" accept="application/json" onChange={importProfile} /></label>
          </div>
        </section>
        <section className="content-pack-card">
          <div className="content-pack-head">
            <div><span className="eyebrow">结构化内容包</span><h2>{content.meta.title}</h2></div>
            <span className="dev-badge">v{content.meta.version}</span>
          </div>
          <div className="content-counts">
            <span><strong>{a1Index.meta.indexedLexemes}</strong> A1 索引</span>
            <span><strong>{a1Content.entries.length}</strong> A1 完整词</span>
            <span><strong>{a1SenseCount}</strong> A1 义项</span>
            <span><strong>{a1ExampleCount}</strong> A1 例句</span>
            <span><strong>{a1Content.exercises.length}</strong> A1 练习</span>
          </div>
          <p>{content.meta.notice}</p>
          <div className="source-row"><span>来源类型</span><strong>项目自建 AI 辅助学习文本 · 明确标注</strong></div>
          <div className="source-row"><span>审核状态</span><strong>结构与规则检查通过 · 待母语教师终审</strong></div>
        </section>
        <section className="danger-zone">
          <div><h2>清空本地档案</h2><p>只删除当前浏览器中的学习数据，不删除示范内容包。</p></div>
          <button onClick={resetProfile}>清空数据</button>
        </section>
      </div>
    );
  }

  function renderView() {
    switch (activeView) {
      case "library": return renderLibrary();
      case "review": return renderReview();
      case "favorites": return renderFavorites();
      case "practice": return renderPractice();
      case "profile": return renderProfile();
      case "settings": return renderSettings();
      default: return renderHome();
    }
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <button className="brand" onClick={() => navigate("home")}>
          <span className="brand-mark">C</span>
          <span><strong>contexto</strong><small>西语情境学习</small></span>
        </button>
        <nav aria-label="主要导航">
          {navItems.map((item) => (
            <button
              key={item.id}
              className={activeView === item.id ? "active" : ""}
              onClick={() => navigate(item.id)}
            >
              <span className="nav-icon">{item.icon}</span>
              <span>{item.label}</span>
              {item.id === "review" && totalDueCount > 0 && <b>{totalDueCount}</b>}
            </button>
          ))}
        </nav>
        <div className="sidebar-footer">
          <div className="local-pill"><span /> 本地优先 · 自动保存</div>
          <small>v0.5.0-dev.1 · A2 语义词组与词书队列修复</small>
        </div>
      </aside>

      <main className="main-area">
        <header className="mobile-header">
          <button className="brand compact-brand" onClick={() => navigate("home")}>
            <span className="brand-mark">C</span><strong>contexto</strong>
          </button>
          <span className="dev-badge">v0.5</span>
        </header>
        <div className="content-wrap">{renderView()}</div>
      </main>

      <nav className="mobile-nav" aria-label="手机导航">
        {navItems.slice(0, 5).map((item) => (
          <button
            key={item.id}
            className={activeView === item.id ? "active" : ""}
            onClick={() => navigate(item.id)}
          >
            <span>{item.icon}</span><small>{item.label === "今日复习" ? "复习" : item.label}</small>
          </button>
        ))}
        <button
          className={activeView === "profile" || activeView === "settings" ? "active" : ""}
          onClick={() => navigate(activeView === "profile" ? "settings" : "profile")}
        >
          <span>•••</span><small>更多</small>
        </button>
      </nav>

      {selectedEntry && (
        <WordLearningFlow
          key={`${selectedFlowMode}-${selectedEntry.id}-${selectedSenseId ?? "first"}`}
          entry={selectedEntry}
          mode={selectedFlowMode}
          currentWordBook={selectedEntryWordBook?.name ?? "开发测试内容"}
          positionLabel={selectedFlowMode === "review"
            ? `复习第 ${reviewCursor + 1} / ${reviewableSenses.length} 项`
            : selectedFlowMode === "lookup"
              ? "从例句中打开 · 不占今日新词"
              : `今日第 ${selectedEntryPosition} / ${selectedEntryTotal} 词`}
          favorites={favorites}
          favoriteExamples={selectedEntryFavoriteExamples}
          initialSenseId={selectedSenseId}
          memory={wordMemoryState[selectedEntry.id]}
          senseMemories={Object.fromEntries(
            selectedEntry.senses.map((sense) => [sense.id, wordMemoryState[`sense:${sense.id}`]]),
          )}
          senseStatuses={reviewState}
          onClose={() => {
            setSelectedEntryId(null);
            setSelectedFlowMode("learn");
          }}
          onToggleFavorite={toggleFavorite}
          onSpeak={speak}
          onEvidence={(event) => recordLearningEvidence(selectedEntry.id, event, selectedFlowMode === "learn")}
          onRate={(rating, details) => rateWordMemory(selectedEntry.id, rating, details)}
          onRateSense={rateSenseMemory}
          onMarkFamiliar={() => cutFamiliarEntry(selectedEntry.id)}
          onNextEntry={() => selectedFlowMode === "review"
            ? openNextReviewEntry()
            : selectedFlowMode === "lookup"
              ? setSelectedEntryId(null)
              : openNextEntry(selectedEntry.id)}
          onViewFavorites={() => {
            setSelectedEntryId(null);
            navigate("favorites");
          }}
          onWordClick={handleContextWord}
        />
      )}

      {selectedExampleStudy && (
        <ExampleStudyDialog
          entry={selectedExampleStudy.entry}
          sense={selectedExampleStudy.sense}
          example={selectedExampleStudy.example}
          saved={favorites.includes(selectedExampleStudy.example.id)}
          onClose={() => setSelectedExampleStudy(null)}
          onSpeak={speak}
          onToggleFavorite={() => toggleFavorite(selectedExampleStudy.example.id, selectedExampleStudy.example.spanish)}
          onWordClick={handleContextWord}
        />
      )}

      {selectedIndexPreview && (
        <div className="analysis-backdrop index-preview-backdrop" onMouseDown={() => setSelectedIndexPreview(null)}>
          <aside className="index-preview-card" onMouseDown={(event) => event.stopPropagation()} aria-label={`${selectedIndexPreview.lemma} 索引词预览`}>
            <button className="analysis-close" onClick={() => setSelectedIndexPreview(null)}>×</button>
            <span className="eyebrow">ÍNDICE · 句中生词</span>
            <h2 lang="es">{selectedIndexPreview.lemma}</h2>
            <p>{selectedIndexPreview.partsOfSpeech.map((part) => indexPartOfSpeechLabels[part] ?? part).join(" · ")}</p>
            <div className="index-preview-facts">
              <span>{"a1DocumentCount" in selectedIndexPreview ? selectedIndexPreview.a1DocumentCount : selectedIndexPreview.documentCount} 份 {selectedIndexPreview.level} 来源文档出现</span>
              <span>优先级 {selectedIndexPreview.priorityRank}</span>
            </div>
            <div className="honest-content-note"><strong>目前只有合法词形索引</strong><p>完整常用义项、4+ 例句和语法分析尚未审核完成，因此这里不会临时编造学习内容。</p></div>
            <button className="button outline" onClick={() => toggleOverviewFamiliar(selectedIndexPreview.id, selectedIndexPreview.lemma)}>
              {dailyPlanState.familiarEntryIds.includes(selectedIndexPreview.id) ? "从熟词本恢复" : "斩 · 加入熟词本"}
            </button>
          </aside>
        </div>
      )}

      {dailySessionComplete && (
        <div className="daily-complete-backdrop" role="dialog" aria-modal="true" aria-label="今日新词计划完成">
          <section className="daily-complete-card">
            <span className="completion-mark">✓</span>
            <p className="eyebrow">HOY · 今日计划</p>
            <h2>今日新词队列已结束</h2>
            {todayPlan.available ? (
              <p>
                已处理 <strong>{todayPlan.completed}</strong> 个可用新词；队列已经结束，系统不会再跳回第一个词循环。
              </p>
            ) : (
              <p>目前内容完整的测试词已经学完，系统不会把它们重新加入新词队列。需要重测时，请在词书页重置“开发测试内容”。</p>
            )}
            {todayPlan.available < todayPlan.goal && (
              <div className="daily-capacity-note">
                你的计划是 {todayPlan.goal} 词，但目前只有 {todayPlan.available} 个内容完整的测试词可用。
                A1 索引已有 {a1Index.meta.indexedLexemes} 词，待逐批补齐义项、4+ 例句并审核后才会加入学习。
              </div>
            )}
            <div className="daily-complete-actions">
              <button className="button dark" onClick={() => {
                setDailySessionComplete(false);
                navigate("home");
              }}>返回首页</button>
              <button className="button light" onClick={() => {
                setDailySessionComplete(false);
                navigate("review");
              }}>进入今日复习</button>
              <button className="button text" onClick={() => {
                setDailySessionComplete(false);
                navigate(todayPlan.available ? "favorites" : "library");
              }}>{todayPlan.available ? "查看熟词本" : "前往词书页"}</button>
            </div>
          </section>
        </div>
      )}

      {toast && <div className="toast" role="status">{toast}</div>}
    </div>
  );
}
