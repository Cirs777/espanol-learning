CREATE TABLE `audio_assets` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_type` text NOT NULL,
	`owner_id` text NOT NULL,
	`asset_type` text NOT NULL,
	`storage_path` text,
	`voice_name` text,
	`locale` text DEFAULT 'es-ES' NOT NULL,
	`accent_label` text DEFAULT '欧洲西班牙语' NOT NULL,
	`speed` real DEFAULT 1 NOT NULL,
	`source_id` text,
	`license_notice` text,
	`review_status_code` text DEFAULT 'pending_review' NOT NULL,
	`created_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL,
	`updated_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL,
	FOREIGN KEY (`source_id`) REFERENCES `content_sources`(`id`) ON UPDATE no action ON DELETE set null,
	FOREIGN KEY (`review_status_code`) REFERENCES `content_review_statuses`(`code`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `audio_owner_idx` ON `audio_assets` (`owner_type`,`owner_id`);--> statement-breakpoint
CREATE TABLE `content_review_statuses` (
	`code` text PRIMARY KEY NOT NULL,
	`label_zh` text NOT NULL,
	`is_learnable` integer DEFAULT false NOT NULL,
	`sort_order` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `content_review_status_sort_uq` ON `content_review_statuses` (`sort_order`);--> statement-breakpoint
CREATE TABLE `content_sources` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`source_type` text NOT NULL,
	`original_level` text,
	`license_name` text,
	`license_url` text,
	`authorization_status` text NOT NULL,
	`imported_at` text,
	`notes` text,
	`created_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL,
	`updated_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL
);
--> statement-breakpoint
CREATE TABLE `example_sentences` (
	`id` text PRIMARY KEY NOT NULL,
	`sense_id` text NOT NULL,
	`sort_order` integer NOT NULL,
	`scene` text NOT NULL,
	`spanish` text NOT NULL,
	`translation_zh` text NOT NULL,
	`translation_en` text,
	`target_meaning` text NOT NULL,
	`framework` text,
	`replacement_prompt` text,
	`level` text,
	`source_id` text,
	`source_type_label` text NOT NULL,
	`review_status_code` text DEFAULT 'pending_review' NOT NULL,
	`created_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL,
	`updated_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL,
	FOREIGN KEY (`sense_id`) REFERENCES `senses`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`source_id`) REFERENCES `content_sources`(`id`) ON UPDATE no action ON DELETE set null,
	FOREIGN KEY (`review_status_code`) REFERENCES `content_review_statuses`(`code`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `examples_sense_order_uq` ON `example_sentences` (`sense_id`,`sort_order`);--> statement-breakpoint
CREATE INDEX `examples_sense_idx` ON `example_sentences` (`sense_id`);--> statement-breakpoint
CREATE TABLE `exercise_acceptable_answers` (
	`exercise_id` text NOT NULL,
	`answer` text NOT NULL,
	`normalized_answer` text NOT NULL,
	`sort_order` integer NOT NULL,
	PRIMARY KEY(`exercise_id`, `normalized_answer`),
	FOREIGN KEY (`exercise_id`) REFERENCES `exercises`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `exercise_attempts` (
	`id` text PRIMARY KEY NOT NULL,
	`profile_id` text NOT NULL,
	`exercise_id` text NOT NULL,
	`answer` text NOT NULL,
	`normalized_answer` text NOT NULL,
	`is_accepted` integer NOT NULL,
	`error_type` text,
	`response_time_ms` integer,
	`attempted_at` text NOT NULL,
	`feedback_json` text DEFAULT '{}' NOT NULL,
	FOREIGN KEY (`profile_id`) REFERENCES `local_profiles`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`exercise_id`) REFERENCES `exercises`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `exercise_attempts_profile_idx` ON `exercise_attempts` (`profile_id`);--> statement-breakpoint
CREATE TABLE `exercises` (
	`id` text PRIMARY KEY NOT NULL,
	`lexeme_id` text,
	`sense_id` text,
	`phrase_id` text,
	`example_sentence_id` text,
	`exercise_type` text NOT NULL,
	`prompt` text NOT NULL,
	`hint` text,
	`primary_answer` text NOT NULL,
	`feedback` text NOT NULL,
	`difficulty` integer DEFAULT 1 NOT NULL,
	`error_type_on_failure` text,
	`review_status_code` text DEFAULT 'pending_review' NOT NULL,
	`created_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL,
	`updated_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL,
	FOREIGN KEY (`lexeme_id`) REFERENCES `lexemes`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`sense_id`) REFERENCES `senses`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`phrase_id`) REFERENCES `phrases`(`id`) ON UPDATE no action ON DELETE set null,
	FOREIGN KEY (`example_sentence_id`) REFERENCES `example_sentences`(`id`) ON UPDATE no action ON DELETE set null,
	FOREIGN KEY (`review_status_code`) REFERENCES `content_review_statuses`(`code`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `exercises_sense_idx` ON `exercises` (`sense_id`);--> statement-breakpoint
CREATE INDEX `exercises_type_idx` ON `exercises` (`exercise_type`);--> statement-breakpoint
CREATE TABLE `favorites` (
	`id` text PRIMARY KEY NOT NULL,
	`profile_id` text NOT NULL,
	`target_type` text NOT NULL,
	`target_id` text NOT NULL,
	`source` text DEFAULT 'user' NOT NULL,
	`created_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL,
	FOREIGN KEY (`profile_id`) REFERENCES `local_profiles`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `favorites_target_uq` ON `favorites` (`profile_id`,`target_type`,`target_id`);--> statement-breakpoint
CREATE INDEX `favorites_profile_idx` ON `favorites` (`profile_id`);--> statement-breakpoint
CREATE TABLE `grammar_annotations` (
	`id` text PRIMARY KEY NOT NULL,
	`example_sentence_id` text NOT NULL,
	`annotation_type` text NOT NULL,
	`label_zh` text NOT NULL,
	`content_zh` text NOT NULL,
	`content_es` text,
	`content_en` text,
	`sort_order` integer NOT NULL,
	`review_status_code` text DEFAULT 'pending_review' NOT NULL,
	`created_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL,
	`updated_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL,
	FOREIGN KEY (`example_sentence_id`) REFERENCES `example_sentences`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`review_status_code`) REFERENCES `content_review_statuses`(`code`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `grammar_example_idx` ON `grammar_annotations` (`example_sentence_id`);--> statement-breakpoint
CREATE TABLE `import_issues` (
	`id` text PRIMARY KEY NOT NULL,
	`import_job_id` text NOT NULL,
	`row_number` integer,
	`severity` text NOT NULL,
	`issue_code` text NOT NULL,
	`message` text NOT NULL,
	`row_payload_json` text DEFAULT '{}' NOT NULL,
	FOREIGN KEY (`import_job_id`) REFERENCES `import_jobs`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `import_issues_job_idx` ON `import_issues` (`import_job_id`);--> statement-breakpoint
CREATE TABLE `import_jobs` (
	`id` text PRIMARY KEY NOT NULL,
	`profile_id` text,
	`word_book_id` text,
	`file_name` text NOT NULL,
	`file_type` text NOT NULL,
	`source_checksum` text NOT NULL,
	`field_mapping_json` text DEFAULT '{}' NOT NULL,
	`status` text NOT NULL,
	`preview_counts_json` text DEFAULT '{}' NOT NULL,
	`result_counts_json` text DEFAULT '{}' NOT NULL,
	`backup_path` text,
	`started_at` text NOT NULL,
	`completed_at` text,
	FOREIGN KEY (`profile_id`) REFERENCES `local_profiles`(`id`) ON UPDATE no action ON DELETE set null,
	FOREIGN KEY (`word_book_id`) REFERENCES `word_books`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE INDEX `import_jobs_checksum_idx` ON `import_jobs` (`source_checksum`);--> statement-breakpoint
CREATE TABLE `learning_sessions` (
	`id` text PRIMARY KEY NOT NULL,
	`profile_id` text NOT NULL,
	`word_book_id` text,
	`device_label` text,
	`started_at` text NOT NULL,
	`ended_at` text,
	`duration_seconds` integer DEFAULT 0 NOT NULL,
	`viewed_sense_ids_json` text DEFAULT '[]' NOT NULL,
	`played_audio_ids_json` text DEFAULT '[]' NOT NULL,
	`opened_analysis_ids_json` text DEFAULT '[]' NOT NULL,
	`metadata_json` text DEFAULT '{}' NOT NULL,
	FOREIGN KEY (`profile_id`) REFERENCES `local_profiles`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`word_book_id`) REFERENCES `word_books`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE INDEX `learning_sessions_profile_idx` ON `learning_sessions` (`profile_id`);--> statement-breakpoint
CREATE TABLE `lexeme_relations` (
	`id` text PRIMARY KEY NOT NULL,
	`source_lexeme_id` text NOT NULL,
	`target_lexeme_id` text,
	`relation_type` text NOT NULL,
	`related_form` text NOT NULL,
	`explanation_zh` text,
	`replaceability_note` text,
	`sort_order` integer NOT NULL,
	`created_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL,
	FOREIGN KEY (`source_lexeme_id`) REFERENCES `lexemes`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`target_lexeme_id`) REFERENCES `lexemes`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE INDEX `lexeme_relations_source_idx` ON `lexeme_relations` (`source_lexeme_id`);--> statement-breakpoint
CREATE UNIQUE INDEX `lexeme_relations_form_uq` ON `lexeme_relations` (`source_lexeme_id`,`relation_type`,`related_form`);--> statement-breakpoint
CREATE TABLE `lexemes` (
	`id` text PRIMARY KEY NOT NULL,
	`lemma` text NOT NULL,
	`normalized_lemma` text NOT NULL,
	`language` text DEFAULT 'es' NOT NULL,
	`part_of_speech_code` text NOT NULL,
	`summary_zh` text DEFAULT '' NOT NULL,
	`frequency_band` text,
	`source_id` text,
	`content_stage` text DEFAULT 'index_only' NOT NULL,
	`review_status_code` text DEFAULT 'pending_review' NOT NULL,
	`created_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL,
	`updated_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL,
	FOREIGN KEY (`part_of_speech_code`) REFERENCES `parts_of_speech`(`code`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`source_id`) REFERENCES `content_sources`(`id`) ON UPDATE no action ON DELETE set null,
	FOREIGN KEY (`review_status_code`) REFERENCES `content_review_statuses`(`code`) ON UPDATE no action ON DELETE no action,
	CONSTRAINT "lexemes_content_stage_check" CHECK("lexemes"."content_stage" in ('index_only','meanings_ready','examples_ready','grammar_ready','audio_ready','exercises_ready','complete'))
);
--> statement-breakpoint
CREATE UNIQUE INDEX `lexemes_identity_uq` ON `lexemes` (`normalized_lemma`,`language`,`part_of_speech_code`);--> statement-breakpoint
CREATE INDEX `lexemes_search_idx` ON `lexemes` (`normalized_lemma`);--> statement-breakpoint
CREATE INDEX `lexemes_content_stage_idx` ON `lexemes` (`content_stage`);--> statement-breakpoint
CREATE TABLE `local_profiles` (
	`id` text PRIMARY KEY NOT NULL,
	`display_name` text DEFAULT '个人学习档案' NOT NULL,
	`locale` text DEFAULT 'zh-CN' NOT NULL,
	`timezone` text DEFAULT 'UTC' NOT NULL,
	`speech_rate` text DEFAULT 'normal' NOT NULL,
	`settings_json` text DEFAULT '{}' NOT NULL,
	`created_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL,
	`updated_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL
);
--> statement-breakpoint
CREATE TABLE `migration_issues` (
	`id` text PRIMARY KEY NOT NULL,
	`migration_record_id` text NOT NULL,
	`severity` text NOT NULL,
	`record_type` text NOT NULL,
	`legacy_id` text,
	`message` text NOT NULL,
	`payload_json` text DEFAULT '{}' NOT NULL,
	FOREIGN KEY (`migration_record_id`) REFERENCES `migration_records`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `migration_issues_record_idx` ON `migration_issues` (`migration_record_id`);--> statement-breakpoint
CREATE TABLE `migration_records` (
	`id` text PRIMARY KEY NOT NULL,
	`migration_type` text NOT NULL,
	`source_version` text NOT NULL,
	`target_version` text NOT NULL,
	`source_checksum` text NOT NULL,
	`status` text NOT NULL,
	`backup_path` text,
	`counts_json` text DEFAULT '{}' NOT NULL,
	`original_payload_json` text NOT NULL,
	`started_at` text NOT NULL,
	`completed_at` text
);
--> statement-breakpoint
CREATE UNIQUE INDEX `migration_completed_source_uq` ON `migration_records` (`migration_type`,`source_checksum`) WHERE "migration_records"."status" = 'completed';--> statement-breakpoint
CREATE TABLE `parts_of_speech` (
	`code` text PRIMARY KEY NOT NULL,
	`label_es` text NOT NULL,
	`label_zh` text NOT NULL,
	`sort_order` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `phrases` (
	`id` text PRIMARY KEY NOT NULL,
	`lexeme_id` text NOT NULL,
	`sense_id` text,
	`phrase_type` text NOT NULL,
	`text_es` text NOT NULL,
	`meaning_zh` text,
	`usage_note` text,
	`sort_order` integer NOT NULL,
	`review_status_code` text DEFAULT 'pending_review' NOT NULL,
	`created_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL,
	`updated_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL,
	FOREIGN KEY (`lexeme_id`) REFERENCES `lexemes`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`sense_id`) REFERENCES `senses`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`review_status_code`) REFERENCES `content_review_statuses`(`code`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `phrases_sense_idx` ON `phrases` (`sense_id`);--> statement-breakpoint
CREATE UNIQUE INDEX `phrases_sense_text_uq` ON `phrases` (`sense_id`,`text_es`);--> statement-breakpoint
CREATE TABLE `profile_stats` (
	`profile_id` text PRIMARY KEY NOT NULL,
	`sessions_count` integer DEFAULT 0 NOT NULL,
	`answered_count` integer DEFAULT 0 NOT NULL,
	`correct_count` integer DEFAULT 0 NOT NULL,
	`recordings_count` integer DEFAULT 0 NOT NULL,
	`minutes_total` integer DEFAULT 0 NOT NULL,
	`last_active_at` text,
	`updated_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL,
	FOREIGN KEY (`profile_id`) REFERENCES `local_profiles`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `review_events` (
	`id` text PRIMARY KEY NOT NULL,
	`profile_id` text NOT NULL,
	`lexeme_id` text NOT NULL,
	`sense_id` text,
	`word_book_id` text,
	`event_type` text NOT NULL,
	`rating` text,
	`previous_status` text,
	`resulting_status` text,
	`previous_ease` real,
	`resulting_ease` real,
	`previous_interval_days` real,
	`resulting_interval_days` real,
	`multiple_choice_errors` integer DEFAULT 0 NOT NULL,
	`response_time_ms` integer,
	`context_id` text,
	`occurred_at` text NOT NULL,
	`payload_json` text DEFAULT '{}' NOT NULL,
	FOREIGN KEY (`profile_id`) REFERENCES `local_profiles`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`lexeme_id`) REFERENCES `lexemes`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`sense_id`) REFERENCES `senses`(`id`) ON UPDATE no action ON DELETE set null,
	FOREIGN KEY (`word_book_id`) REFERENCES `word_books`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE INDEX `review_events_profile_time_idx` ON `review_events` (`profile_id`,`occurred_at`);--> statement-breakpoint
CREATE INDEX `review_events_sense_time_idx` ON `review_events` (`sense_id`,`occurred_at`);--> statement-breakpoint
CREATE TABLE `sense_progress` (
	`profile_id` text NOT NULL,
	`sense_id` text NOT NULL,
	`current_status` text DEFAULT 'unseen' NOT NULL,
	`ease_factor` real DEFAULT 2.5 NOT NULL,
	`interval_days` real DEFAULT 0 NOT NULL,
	`last_reviewed_at` text,
	`next_review_at` text,
	`short_queue_stage` integer DEFAULT 0 NOT NULL,
	`short_queue_due_at` text,
	`consecutive_known` integer DEFAULT 0 NOT NULL,
	`consecutive_failures` integer DEFAULT 0 NOT NULL,
	`attempts` integer DEFAULT 0 NOT NULL,
	`independent_uses` integer DEFAULT 0 NOT NULL,
	`context_ids_json` text DEFAULT '[]' NOT NULL,
	`updated_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL,
	PRIMARY KEY(`profile_id`, `sense_id`),
	FOREIGN KEY (`profile_id`) REFERENCES `local_profiles`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`sense_id`) REFERENCES `senses`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `sense_progress_due_idx` ON `sense_progress` (`profile_id`,`next_review_at`);--> statement-breakpoint
CREATE INDEX `sense_progress_short_due_idx` ON `sense_progress` (`profile_id`,`short_queue_due_at`);--> statement-breakpoint
CREATE TABLE `senses` (
	`id` text PRIMARY KEY NOT NULL,
	`lexeme_id` text NOT NULL,
	`part_of_speech_code` text,
	`sense_order` integer NOT NULL,
	`importance` integer DEFAULT 50 NOT NULL,
	`label_zh` text NOT NULL,
	`definition_es` text,
	`definition_en` text,
	`scene` text,
	`register_label` text,
	`region_label` text,
	`preposition_notes` text,
	`source_id` text,
	`content_stage` text DEFAULT 'meanings_ready' NOT NULL,
	`review_status_code` text DEFAULT 'pending_review' NOT NULL,
	`created_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL,
	`updated_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL,
	FOREIGN KEY (`lexeme_id`) REFERENCES `lexemes`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`part_of_speech_code`) REFERENCES `parts_of_speech`(`code`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`source_id`) REFERENCES `content_sources`(`id`) ON UPDATE no action ON DELETE set null,
	FOREIGN KEY (`review_status_code`) REFERENCES `content_review_statuses`(`code`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `senses_lexeme_order_uq` ON `senses` (`lexeme_id`,`sense_order`);--> statement-breakpoint
CREATE INDEX `senses_lexeme_idx` ON `senses` (`lexeme_id`);--> statement-breakpoint
CREATE TABLE `user_word_book_progress` (
	`profile_id` text NOT NULL,
	`word_book_id` text NOT NULL,
	`state` text DEFAULT 'not_started' NOT NULL,
	`current_lexeme_id` text,
	`current_position` integer DEFAULT 0 NOT NULL,
	`is_current` integer DEFAULT false NOT NULL,
	`started_at` text,
	`last_studied_at` text,
	`updated_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL,
	PRIMARY KEY(`profile_id`, `word_book_id`),
	FOREIGN KEY (`profile_id`) REFERENCES `local_profiles`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`word_book_id`) REFERENCES `word_books`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`current_lexeme_id`) REFERENCES `lexemes`(`id`) ON UPDATE no action ON DELETE set null,
	CONSTRAINT "word_book_progress_state_check" CHECK("user_word_book_progress"."state" in ('not_started','active','paused','completed','restarted'))
);
--> statement-breakpoint
CREATE INDEX `word_book_progress_current_idx` ON `user_word_book_progress` (`profile_id`,`is_current`);--> statement-breakpoint
CREATE TABLE `user_word_progress` (
	`profile_id` text NOT NULL,
	`lexeme_id` text NOT NULL,
	`current_status` text DEFAULT 'unseen' NOT NULL,
	`familiarity_score` real DEFAULT 0 NOT NULL,
	`total_multiple_choice_errors` integer DEFAULT 0 NOT NULL,
	`total_study_seconds` integer DEFAULT 0 NOT NULL,
	`first_learned_at` text,
	`last_studied_at` text,
	`updated_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL,
	PRIMARY KEY(`profile_id`, `lexeme_id`),
	FOREIGN KEY (`profile_id`) REFERENCES `local_profiles`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`lexeme_id`) REFERENCES `lexemes`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `word_progress_status_idx` ON `user_word_progress` (`profile_id`,`current_status`);--> statement-breakpoint
CREATE TABLE `word_book_entries` (
	`word_book_id` text NOT NULL,
	`lexeme_id` text NOT NULL,
	`position` integer NOT NULL,
	`original_level` text,
	`frequency_rank` integer,
	`priority` integer DEFAULT 0 NOT NULL,
	`source_id` text,
	`content_ready` integer DEFAULT false NOT NULL,
	`created_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL,
	PRIMARY KEY(`word_book_id`, `lexeme_id`),
	FOREIGN KEY (`word_book_id`) REFERENCES `word_books`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`lexeme_id`) REFERENCES `lexemes`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`source_id`) REFERENCES `content_sources`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE UNIQUE INDEX `word_book_entries_position_uq` ON `word_book_entries` (`word_book_id`,`position`);--> statement-breakpoint
CREATE INDEX `word_book_entries_lexeme_idx` ON `word_book_entries` (`lexeme_id`);--> statement-breakpoint
CREATE INDEX `word_book_entries_ready_idx` ON `word_book_entries` (`word_book_id`,`content_ready`);--> statement-breakpoint
CREATE TABLE `word_books` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`level` text,
	`description` text DEFAULT '' NOT NULL,
	`source_id` text,
	`source_notice` text DEFAULT '' NOT NULL,
	`license_notice` text DEFAULT '' NOT NULL,
	`version` text NOT NULL,
	`is_enabled` integer DEFAULT true NOT NULL,
	`is_development_only` integer DEFAULT false NOT NULL,
	`created_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL,
	`updated_at` text DEFAULT (CURRENT_TIMESTAMP) NOT NULL,
	FOREIGN KEY (`source_id`) REFERENCES `content_sources`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE INDEX `word_books_level_idx` ON `word_books` (`level`);--> statement-breakpoint
CREATE INDEX `word_books_enabled_idx` ON `word_books` (`is_enabled`);