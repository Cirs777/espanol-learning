"use client";

import { useEffect, useState } from "react";

type InstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

export default function InstallAppCard() {
  const [promptEvent, setPromptEvent] = useState<InstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(() => {
    if (typeof window === "undefined") return false;

    return window.matchMedia("(display-mode: standalone)").matches
      || Boolean((window.navigator as Navigator & { standalone?: boolean }).standalone);
  });
  const [showHelp, setShowHelp] = useState(false);

  useEffect(() => {
    const capturePrompt = (event: Event) => {
      event.preventDefault();
      setPromptEvent(event as InstallPromptEvent);
    };
    const markInstalled = () => {
      setInstalled(true);
      setPromptEvent(null);
    };
    window.addEventListener("beforeinstallprompt", capturePrompt);
    window.addEventListener("appinstalled", markInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", capturePrompt);
      window.removeEventListener("appinstalled", markInstalled);
    };
  }, []);

  async function install() {
    if (!promptEvent) {
      setShowHelp(true);
      return;
    }
    await promptEvent.prompt();
    const choice = await promptEvent.userChoice;
    if (choice.outcome === "accepted") setInstalled(true);
    setPromptEvent(null);
  }

  return (
    <section className="settings-card install-app-card">
      <div>
        <span className="settings-icon">↧</span>
        <div>
          <h2>安装到手机桌面</h2>
          <p>公开网页可安装成独立 App 图标；更新仍来自同一个公开版本，无需下载未知来源的文件。</p>
        </div>
      </div>
      <button className="button coral" onClick={install} disabled={installed}>
        {installed ? "已安装" : promptEvent ? "安装 Contexto" : "查看安装方法"}
      </button>
      {showHelp && !installed && (
        <div className="install-help">
          <strong>手机安装方法</strong>
          <p><b>Android Chrome：</b>打开浏览器菜单，选择“安装应用”或“添加到主屏幕”。</p>
          <p><b>iPhone Safari：</b>点击“分享”，再选择“添加到主屏幕”。</p>
          <button className="text-action" onClick={() => setShowHelp(false)}>收起说明</button>
        </div>
      )}
    </section>
  );
}
