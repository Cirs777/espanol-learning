"use client";

import { useState } from "react";

import InteractiveSpanishText from "@/components/InteractiveSpanishText";
import type { LearningEntry, LearningExample, LearningSense } from "@/components/WordLearningFlow";

type Props = {
  entry: LearningEntry;
  sense: LearningSense;
  example: LearningExample;
  saved: boolean;
  onClose: () => void;
  onSpeak: (text: string, rate: "normal" | "slow") => void;
  onToggleFavorite: () => void;
  onWordClick: (word: string) => void;
};

export default function ExampleStudyDialog({
  entry,
  sense,
  example,
  saved,
  onClose,
  onSpeak,
  onToggleFavorite,
  onWordClick,
}: Props) {
  const [showAnswer, setShowAnswer] = useState(false);
  const [rate, setRate] = useState<"normal" | "slow">("normal");
  const targetForms = [entry.lemma, ...(entry.lookupForms ?? [])];
  return (
    <div className="analysis-backdrop example-study-backdrop" onMouseDown={onClose}>
      <aside className="analysis-drawer example-study-drawer" onMouseDown={(event) => event.stopPropagation()} aria-label="收藏例句详细学习">
        <button className="analysis-close" onClick={onClose}>×</button>
        <span className="eyebrow">ANCLA · 收藏例句详细学习</span>
        <div className="example-study-heading">
          <div><strong>{entry.lemma}</strong><span>{sense.labelZh} · {example.scene}</span></div>
          <label><span>语速</span><select value={rate} onChange={(event) => setRate(event.target.value as "normal" | "slow")}><option value="normal">正常</option><option value="slow">慢速</option></select></label>
        </div>
        <h2 className="interactive-example-title">
          <InteractiveSpanishText text={example.spanish} targetForms={targetForms} onWordClick={onWordClick} />
        </h2>
        <p className="token-help">点击句中非目标词，可打开该词的学习框；粗体为当前目标词。</p>
        <div className="example-study-actions">
          <button className="button dark" onClick={() => onSpeak(example.spanish, rate)}>◉ 播放例句</button>
          <button className={`button outline ${saved ? "active" : ""}`} onClick={onToggleFavorite}>{saved ? "♥ 已收藏" : "♡ 收藏例句"}</button>
        </div>
        <p className="analysis-translation">{example.chinese}</p>
        <p className="analysis-english">EN · {example.english}</p>
        <section className="analysis-meaning"><span>目标词在本句中的义项</span><strong>{example.targetMeaning}</strong></section>
        <details open><summary>句子成分与从句</summary><ul>{example.analysis.sentenceParts.map((item) => <li key={item}>{item}</li>)}</ul></details>
        <details open><summary>动词原形、时态、语气与人称</summary><p>{example.analysis.verbInfo}</p></details>
        <details><summary>代词、冠词、性数一致、介词与语序</summary><ul>{example.analysis.functionNotes.map((item) => <li key={item}>{item}</li>)}</ul></details>
        <details><summary>固定搭配、词块与可替换框架</summary><div className="analysis-chunks">{example.analysis.chunks.map((item) => <span key={item}>{item}</span>)}</div><p><strong>框架：</strong>{example.framework}</p><p><strong>替换：</strong>{example.replacement}</p></details>
        <details><summary>英语与西语的关键差别</summary><p>{example.analysis.englishContrast}</p><p className="transfer-warning"><strong>常见迁移错误：</strong>{example.analysis.transferError}</p></details>
        <details><summary>句中其他值得学习的词语</summary><ul>{example.analysis.extraVocabulary.map((item) => <li key={item}>{item}</li>)}</ul></details>
        <section className="micro-exercise">
          <span>立即使用这个结构</span><h3>{example.analysis.microExercise.prompt}</h3>
          {!showAnswer ? <button className="button dark" onClick={() => setShowAnswer(true)}>显示参考答案</button> : <p lang="es">{example.analysis.microExercise.answer}</p>}
        </section>
      </aside>
    </div>
  );
}

