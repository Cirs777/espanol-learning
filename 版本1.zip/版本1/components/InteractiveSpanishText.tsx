"use client";

type Props = {
  text: string;
  targetForms?: string[];
  onWordClick?: (word: string) => void;
  className?: string;
};

function normalize(value: string) {
  return value
    .normalize("NFC")
    .toLocaleLowerCase("es")
    .replace(/^[^\p{L}áéíóúüñ]+|[^\p{L}áéíóúüñ]+$/giu, "");
}

export default function InteractiveSpanishText({
  text,
  targetForms = [],
  onWordClick,
  className = "",
}: Props) {
  const targetSet = new Set(targetForms.map(normalize));
  const tokens = text.split(/(\s+)/);
  return (
    <span className={`interactive-spanish ${className}`} lang="es">
      {tokens.map((token, index) => {
        if (/^\s+$/.test(token)) return token;
        const word = normalize(token);
        if (!word) return token;
        if (targetSet.has(word)) {
          return <strong className="target-word-token" key={`${token}-${index}`}>{token}</strong>;
        }
        return onWordClick ? (
          <button
            type="button"
            className="context-word-token"
            key={`${token}-${index}`}
            onClick={(event) => {
              event.stopPropagation();
              onWordClick(word);
            }}
            title={`学习 ${word}`}
          >
            {token}
          </button>
        ) : token;
      })}
    </span>
  );
}

