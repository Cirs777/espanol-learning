"use client";

import { PointerEvent, useEffect, useMemo, useRef, useState } from "react";

import InteractiveSpanishText from "@/components/InteractiveSpanishText";

export type MemoryRating = "unknown" | "unfamiliar" | "known";

export type LearningAnalysis = {
  sentenceParts: string[];
  verbInfo: string;
  functionNotes: string[];
  chunks: string[];
  englishContrast: string;
  transferError: string;
  extraVocabulary: string[];
  microExercise: { prompt: string; answer: string };
};

export type LearningExample = {
  id: string;
  scene: string;
  spanish: string;
  english: string;
  chinese: string;
  targetMeaning: string;
  framework: string;
  grammar: string[];
  analysis: LearningAnalysis;
  replacement: string;
  sourceType: string;
  reviewStatus: string;
};

export type LearningSense = {
  id: string;
  cardLabel: string;
  labelZh: string;
  definitionEs: string;
  definitionEn: string;
  register: string;
  region: string;
  usageScenes: string[];
  prepositionNote: string;
  chunks: string[];
  grammarTags: string[];
  microLesson?: {
    title: string;
    body: string;
    keyPoints: string[];
  };
  examples: LearningExample[];
};

export type LearningEntry = {
  id: string;
  lemma: string;
  partOfSpeech: string;
  level: string;
  frequency: string;
  summaryZh: string;
  coreMeaningZh: string;
  recognitionOptions: Array<{ id: string; label: string; correct: boolean }>;
  forms: Array<{ label: string; value: string; note: string }>;
  importantPhrases: string[];
  patterns: string[];
  synonyms: string[];
  antonyms: string[];
  family: string[];
  contrasts: string[];
  semanticUnit?: string;
  lookupForms?: string[];
  senses: LearningSense[];
};

type EvidenceEvent = {
  type:
    | "recognition_wrong"
    | "recognition_correct"
    | "sense_view"
    | "audio_play"
    | "analysis_view"
    | "sense_rating"
    | "word_check"
    | "card_position"
    | "completed";
  id?: string;
  value?: number;
};

type MemorySummary = {
  status?: string;
  easeFactor?: number;
  intervalDays?: number;
  nextReviewDate?: string | null;
  shortTermDueAt?: string[];
};

type Props = {
  entry: LearningEntry;
  mode?: "learn" | "review" | "lookup";
  currentWordBook: string;
  positionLabel: string;
  favorites: string[];
  favoriteExamples?: LearningExample[];
  initialSenseId?: string | null;
  memory?: MemorySummary;
  senseMemories: Record<string, MemorySummary | undefined>;
  senseStatuses: Record<string, { score?: number; nextReview?: string }>;
  onClose: () => void;
  onToggleFavorite: (id: string, label: string) => void;
  onSpeak: (text: string, rate: "normal" | "slow") => void;
  onEvidence: (event: EvidenceEvent) => void;
  onRate: (
    rating: MemoryRating,
    details: { recognitionErrors: number; reactionMs: number | null },
  ) => MemorySummary;
  onRateSense: (
    senseId: string,
    rating: MemoryRating,
    exampleId: string,
  ) => MemorySummary;
  onMarkFamiliar: () => void;
  onNextEntry: () => void;
  onViewFavorites: () => void;
  onWordClick?: (word: string) => void;
};

const ratingLabels: Record<MemoryRating, { title: string; note: string }> = {
  unknown: { title: "不认识", note: "1、5 分钟后再现，长期重置到明天" },
  unfamiliar: { title: "不熟", note: "约 12 分钟后再测，间隔仅小幅增加" },
  known: { title: "认识", note: "按 1、3、8、20 天逐步拉长" },
};

function memoryLabel(status?: string) {
  if (status === "unknown") return "不认识";
  if (status === "unfamiliar") return "不熟";
  if (status === "known") return "认识";
  return "尚未判断";
}

function displayDate(value?: string | null) {
  if (!value) return "尚未安排";
  return value;
}

export default function WordLearningFlow({
  entry,
  mode = "learn",
  currentWordBook,
  positionLabel,
  favorites,
  favoriteExamples = [],
  initialSenseId,
  memory,
  senseMemories,
  senseStatuses,
  onClose,
  onToggleFavorite,
  onSpeak,
  onEvidence,
  onRate,
  onRateSense,
  onMarkFamiliar,
  onNextEntry,
  onViewFavorites,
  onWordClick,
}: Props) {
  const preferredSenseIndex = Math.max(
    0,
    entry.senses.findIndex((sense) => sense.id === initialSenseId),
  );
  const [cardIndex, setCardIndex] = useState(mode === "review" ? preferredSenseIndex : -1);
  const [exampleIndexes, setExampleIndexes] = useState<Record<string, number>>({});
  const [wrongOptionIds, setWrongOptionIds] = useState<string[]>([]);
  const [recognitionCorrect, setRecognitionCorrect] = useState(false);
  const [reactionMs, setReactionMs] = useState<number | null>(null);
  const [speechRate, setSpeechRate] = useState<"normal" | "slow">("normal");
  const [analysisExample, setAnalysisExample] = useState<LearningExample | null>(null);
  const [showMicroAnswer, setShowMicroAnswer] = useState(false);
  const [reachedEnd, setReachedEnd] = useState(false);
  const [ratingResult, setRatingResult] = useState<MemorySummary | null>(null);
  const [senseRatingResults, setSenseRatingResults] = useState<Record<string, MemorySummary>>({});
  const [wordCheckOpen, setWordCheckOpen] = useState(false);
  const [wordCheckWrongIds, setWordCheckWrongIds] = useState<string[]>([]);
  const [wordCheckComplete, setWordCheckComplete] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const startedAt = useRef(0);
  const pointerStart = useRef<{ x: number; y: number } | null>(null);

  useEffect(() => {
    startedAt.current = window.performance.now();
  }, []);

  const sense = cardIndex >= 0 ? entry.senses[cardIndex] : null;
  const exampleIndex = sense ? exampleIndexes[sense.id] ?? 0 : 0;
  const example = sense?.examples[exampleIndex];
  const totalCards = entry.senses.length + 1;
  const wrongCount = wrongOptionIds.length;
  const wordCheckSense = entry.senses[(entry.lemma.length + wrongCount) % entry.senses.length];
  const wordCheckExample = wordCheckSense.examples[Math.min(1, wordCheckSense.examples.length - 1)];

  const sourceNotice = useMemo(() => {
    const sourceTypes = new Set(
      entry.senses.flatMap((item) => item.examples.map((candidate) => candidate.sourceType)),
    );
    return [...sourceTypes].join(" · ");
  }, [entry.senses]);
  const targetForms = [entry.lemma, ...(entry.lookupForms ?? [])];
  const modeLabel = mode === "review" ? "卡片式复习" : mode === "lookup" ? "句中词学习" : "新词学习";

  function moveToSense(nextIndex: number) {
    const bounded = Math.max(0, Math.min(entry.senses.length - 1, nextIndex));
    setCardIndex(bounded);
    setAnalysisExample(null);
    setShowMicroAnswer(false);
    onEvidence({ type: "sense_view", id: entry.senses[bounded].id });
    onEvidence({ type: "card_position", value: bounded + 1 });
    if (bounded === entry.senses.length - 1) setReachedEnd(true);
  }

  function moveExample(direction: -1 | 1) {
    if (!sense) return;
    const count = sense.examples.length;
    const next = (exampleIndex + direction + count) % count;
    setExampleIndexes((current) => ({ ...current, [sense.id]: next }));
    setAnalysisExample(null);
    setShowMicroAnswer(false);
  }

  function chooseMeaning(
    option: LearningEntry["recognitionOptions"][number],
    eventTimestamp: number,
  ) {
    if (recognitionCorrect || wrongOptionIds.includes(option.id)) return;
    if (!option.correct) {
      setWrongOptionIds((current) => [...current, option.id]);
      setStatusMessage("这次选择不正确，请继续选择，直到找到核心释义。");
      onEvidence({ type: "recognition_wrong", id: option.id });
      return;
    }
    const responseTime = Math.max(0, eventTimestamp - startedAt.current);
    setReactionMs(responseTime);
    setRecognitionCorrect(true);
    setStatusMessage(wrongCount ? "已找到正确释义；错误次数会进入本次记忆记录。" : "回答正确，已展开全部核心内容。");
    onEvidence({ type: "recognition_correct", value: responseTime });
  }

  function play(text: string) {
    onSpeak(text, speechRate);
    onEvidence({ type: "audio_play", id: example?.id ?? entry.id });
  }

  function openAnalysis(candidate: LearningExample) {
    setAnalysisExample(candidate);
    setShowMicroAnswer(false);
    onEvidence({ type: "analysis_view", id: candidate.id });
  }

  function rate(rating: MemoryRating) {
    const next = onRate(rating, { recognitionErrors: wrongCount, reactionMs });
    setRatingResult(next);
    onEvidence({ type: "completed" });
    setStatusMessage(`已记录“${ratingLabels[rating].title}”，长期复习：${displayDate(next.nextReviewDate)}`);
  }

  function rateSense(rating: MemoryRating) {
    if (!sense || !example) return;
    const next = onRateSense(sense.id, rating, example.id);
    setSenseRatingResults((current) => ({ ...current, [sense.id]: next }));
    onEvidence({ type: "sense_rating", id: sense.id, value: rating === "known" ? 2 : rating === "unfamiliar" ? 1 : 0 });
  }

  function chooseWordCheck(senseId: string) {
    if (wordCheckComplete || wordCheckWrongIds.includes(senseId)) return;
    if (senseId !== wordCheckSense.id) {
      setWordCheckWrongIds((current) => [...current, senseId]);
      onEvidence({ type: "word_check", id: senseId, value: 0 });
      return;
    }
    setWordCheckComplete(true);
    onEvidence({ type: "word_check", id: senseId, value: 1 });
  }

  function handlePointerDown(event: PointerEvent<HTMLElement>) {
    const target = event.target as HTMLElement;
    if (target.closest("button, audio, input, select, details")) return;
    pointerStart.current = { x: event.clientX, y: event.clientY };
  }

  function handlePointerUp(event: PointerEvent<HTMLElement>) {
    if (!pointerStart.current || !sense) return;
    const deltaX = event.clientX - pointerStart.current.x;
    const deltaY = event.clientY - pointerStart.current.y;
    pointerStart.current = null;
    if (Math.abs(deltaX) < 45 || Math.abs(deltaX) <= Math.abs(deltaY)) return;
    const direction: -1 | 1 = deltaX < 0 ? 1 : -1;
    if (Math.abs(deltaX) >= 130) {
      moveToSense(cardIndex + direction);
    } else {
      moveExample(direction);
    }
  }

  return (
    <div className="learning-flow-backdrop" role="dialog" aria-modal="true" aria-label={`${entry.lemma} ${modeLabel}`}>
      <section className="learning-flow-shell">
        <header className="learning-flow-header">
          <button className="flow-close" onClick={onClose} aria-label="退出单词学习">×</button>
          <div>
            <span>{modeLabel} · {currentWordBook}</span>
            <strong>{positionLabel}</strong>
          </div>
          <div className="flow-header-status">
            <span>熟悉度</span>
            <strong>{memoryLabel(ratingResult?.status ?? memory?.status)}</strong>
          </div>
        </header>

        <div className="flow-progress" aria-label={`第 ${cardIndex + 2} 张，共 ${totalCards} 张`}>
          {Array.from({ length: totalCards }, (_, index) => (
            <span key={index} className={index === cardIndex + 1 ? "active" : index < cardIndex + 1 ? "passed" : ""} />
          ))}
        </div>

        {cardIndex === -1 ? (
          <article className="learning-card recognition-card">
            <div className="recognition-head">
              <div>
                <span className="card-sequence">第一张卡 · 词形识别</span>
                <h1>{entry.lemma}</h1>
                <p>{entry.partOfSpeech} · {entry.level} · {entry.frequency}</p>
              </div>
              <div className="recognition-actions">
                <button className="flow-audio-button" onClick={() => play(entry.lemma)} aria-label={`播放 ${entry.lemma}`}>
                  ◉ <span>标准发音</span>
                </button>
                <button
                  className={`flow-favorite ${favorites.includes(entry.id) ? "active" : ""}`}
                  onClick={() => onToggleFavorite(entry.id, entry.lemma)}
                >
                  {favorites.includes(entry.id) ? "♥ 已收藏" : "♡ 收藏"}
                </button>
                <button className="flow-cut" onClick={onMarkFamiliar} aria-label={`斩掉熟词 ${entry.lemma}`}>
                  <strong>斩</strong><span>加入熟词本</span>
                </button>
              </div>
            </div>

            <p className="cut-explanation">如果这是已经熟练掌握的词，选择“斩”后将加入熟词本，不再进入新词或复习队列；可以在收藏页恢复。</p>

            <section className="meaning-quiz">
              <div className="quiz-heading">
                <div><span>先作答</span><h2>请选择最接近的核心中文释义</h2></div>
                <small>{wrongCount} 次错误 · {reactionMs ? `${(reactionMs / 1000).toFixed(1)} 秒` : "正在计时"}</small>
              </div>
              <div className="meaning-options">
                {entry.recognitionOptions.map((option, index) => {
                  const wrong = wrongOptionIds.includes(option.id);
                  const correct = recognitionCorrect && option.correct;
                  return (
                    <button
                      key={option.id}
                      className={`${wrong ? "wrong" : ""} ${correct ? "correct" : ""}`}
                      disabled={wrong || recognitionCorrect}
                      onClick={(event) => chooseMeaning(option, event.timeStamp)}
                    >
                      <span>{String.fromCharCode(65 + index)}</span>
                      <strong>{option.label}</strong>
                      <i>{wrong ? "再想想" : correct ? "正确" : "选择"}</i>
                    </button>
                  );
                })}
              </div>
              {statusMessage && <p className={`quiz-message ${recognitionCorrect ? "success" : ""}`}>{statusMessage}</p>}
            </section>

            {recognitionCorrect && (
              <div className="recognition-reveal">
                <section className="all-meanings">
                  <div className="flow-section-title"><span>核心内容已展开</span><h2>{entry.summaryZh}</h2></div>
                  <div className="meaning-summary-grid">
                    {entry.senses.map((item, index) => (
                      <button key={item.id} onClick={() => moveToSense(index)}>
                        <span>{item.cardLabel}</span><strong>{item.labelZh}</strong><small>{item.definitionEs}</small>
                      </button>
                    ))}
                  </div>
                </section>
                <section className="forms-grid">
                  {entry.forms.map((form) => (
                    <div key={`${form.label}-${form.value}`}><span>{form.label}</span><strong>{form.value}</strong><p>{form.note}</p></div>
                  ))}
                </section>
                <section className="recognition-reference-grid">
                  <div><span>高频短语</span>{entry.importantPhrases.map((item) => <strong key={item}>{item}</strong>)}</div>
                  <div><span>常用句式</span>{entry.patterns.map((item) => <strong key={item}>{item}</strong>)}</div>
                  <div><span>近义入口</span>{entry.synonyms.map((item) => <strong key={item}>{item}</strong>)}</div>
                  <div><span>反义入口</span>{entry.antonyms.map((item) => <strong key={item}>{item}</strong>)}</div>
                </section>
                <div className="recognition-next-row">
                  <span>后续共 {entry.senses.length} 张义项卡，每张至少 4 条精选例句</span>
                  <button className="button coral" onClick={() => moveToSense(preferredSenseIndex)}>进入第一张义项卡 →</button>
                  {reachedEnd && <button className="button dark" onClick={onNextEntry}>下一词 →</button>}
                </div>
              </div>
            )}
          </article>
        ) : sense && example ? (
          <article
            className="learning-card sense-learning-card"
            onPointerDown={handlePointerDown}
            onPointerUp={handlePointerUp}
          >
            <div className="sense-card-heading">
              <div>
                <span className="card-sequence">第 {cardIndex + 2} 张卡 · {sense.cardLabel}</span>
                <h1>{sense.labelZh}</h1>
                <p lang="es">{sense.definitionEs}</p>
                <small>EN · {sense.definitionEn}</small>
              </div>
              <div className="sense-card-badges">
                <span>{sense.register}</span><span>{sense.region}</span>
                <strong>{memoryLabel(senseRatingResults[sense.id]?.status ?? senseMemories[sense.id]?.status) !== "尚未判断"
                  ? memoryLabel(senseRatingResults[sense.id]?.status ?? senseMemories[sense.id]?.status)
                  : senseStatuses[sense.id]?.score === 2 ? "认识" : senseStatuses[sense.id] ? "已有记录" : "未学习"}</strong>
              </div>
            </div>

            <div className="sense-reference-strip">
              <div><span>使用场景</span><strong>{sense.usageScenes.join(" · ")}</strong></div>
              <div><span>介词与句法</span><strong>{sense.prepositionNote}</strong></div>
            </div>
            <div className="flow-chunks">
              {sense.chunks.map((chunk) => <span key={chunk}>{chunk}</span>)}
            </div>

            {sense.microLesson && (
              <details className="sense-micro-lesson">
                <summary><span>短语与语法微课</span><strong>{sense.microLesson.title}</strong></summary>
                <p>{sense.microLesson.body}</p>
                <ul>{sense.microLesson.keyPoints.map((point) => <li key={point}>{point}</li>)}</ul>
              </details>
            )}

            {mode === "review" && favoriteExamples.length > 0 && (
              <section className="review-anchor-strip" aria-label="本词收藏例句">
                <div><span>你的记忆锚点</span><strong>{favoriteExamples.length} 条收藏例句</strong></div>
                <div>
                  {favoriteExamples.map((savedExample) => (
                    <button
                      key={savedExample.id}
                      onClick={() => {
                        const savedSenseIndex = entry.senses.findIndex((candidate) =>
                          candidate.examples.some((candidateExample) => candidateExample.id === savedExample.id));
                        if (savedSenseIndex < 0) return;
                        const savedExampleIndex = entry.senses[savedSenseIndex].examples.findIndex((candidate) => candidate.id === savedExample.id);
                        setExampleIndexes((current) => ({ ...current, [entry.senses[savedSenseIndex].id]: savedExampleIndex }));
                        moveToSense(savedSenseIndex);
                      }}
                    >
                      {savedExample.spanish}
                    </button>
                  ))}
                </div>
              </section>
            )}

            <section className="example-carousel" aria-label={`${sense.labelZh} 例句 ${exampleIndex + 1}`}>
              <div className="example-carousel-head">
                <div><span>例句 {exampleIndex + 1} / {sense.examples.length}</span><strong>{example.scene}</strong></div>
                <label className="flow-speed-control">
                  <span>语速</span>
                  <select value={speechRate} onChange={(event) => setSpeechRate(event.target.value as "normal" | "slow")}>
                    <option value="normal">正常</option><option value="slow">慢速</option>
                  </select>
                </label>
              </div>
              <div className="example-main-copy">
                <button className="flow-audio-button large" onClick={() => play(example.spanish)} aria-label="播放当前例句">◉</button>
                <div>
                  <p><InteractiveSpanishText text={example.spanish} targetForms={targetForms} onWordClick={onWordClick} /></p>
                  <span>{example.chinese}</span><small>{example.english}</small>
                </div>
              </div>
              <div className="example-target-callout"><span>本句义项</span><strong>{example.targetMeaning}</strong></div>
              <div className="example-actions-row">
                <button className="button outline" onClick={() => openAnalysis(example)}>详细分析与微练习</button>
                <button
                  className={`flow-favorite ${favorites.includes(example.id) ? "active" : ""}`}
                  onClick={() => onToggleFavorite(example.id, example.spanish)}
                >
                  {favorites.includes(example.id) ? "♥ 已收藏例句" : "♡ 收藏例句"}
                </button>
              </div>
              <div className="small-navigation">
                <button onClick={() => moveExample(-1)} aria-label="上一条例句">‹ <span>上一条例句</span></button>
                <div>{sense.examples.map((candidate, index) => <span key={candidate.id} className={index === exampleIndex ? "active" : ""} />)}</div>
                <button onClick={() => moveExample(1)} aria-label="下一条例句"><span>下一条例句</span> ›</button>
              </div>
              <p className="gesture-hint">短距离左右滑动切换例句；长距离滑动切换义项。纵向滚动不受影响。</p>
            </section>

            <section className="sense-memory-panel" aria-label={`${sense.labelZh} 熟悉度`}>
              <div>
                <span>当前义项独立记录</span>
                <strong>这个义项记得怎么样？</strong>
                <small>只影响“{sense.labelZh}”，不会替其他义项自动评分。</small>
              </div>
              <div className="sense-memory-actions">
                {(Object.keys(ratingLabels) as MemoryRating[]).map((rating) => (
                  <button
                    key={rating}
                    className={(senseRatingResults[sense.id]?.status ?? senseMemories[sense.id]?.status) === rating ? "active" : ""}
                    onClick={() => rateSense(rating)}
                  >
                    {ratingLabels[rating].title}
                  </button>
                ))}
              </div>
              {(senseRatingResults[sense.id] || senseMemories[sense.id]) && (
                <p>下次复习：{displayDate((senseRatingResults[sense.id] ?? senseMemories[sense.id])?.nextReviewDate)}</p>
              )}
            </section>

            <nav className="large-navigation" aria-label="义项卡导航">
              <button disabled={cardIndex === 0} onClick={() => moveToSense(cardIndex - 1)}>« <span>上一个义项</span></button>
              <div><strong>{cardIndex + 1} / {entry.senses.length}</strong><span>义项卡</span></div>
              <button disabled={cardIndex === entry.senses.length - 1} onClick={() => moveToSense(cardIndex + 1)}><span>下一个义项</span> »</button>
            </nav>

            {cardIndex === entry.senses.length - 1 && (
              <section className="word-finish-panel">
                <div className="flow-section-title"><span>已到最后一张义项卡</span><h2>这次记得怎么样？</h2></div>
                <div className="memory-rating-grid">
                  {(Object.keys(ratingLabels) as MemoryRating[]).map((rating) => (
                    <button key={rating} onClick={() => rate(rating)} className={ratingResult?.status === rating ? "active" : ""}>
                      <strong>{ratingLabels[rating].title}</strong><span>{ratingLabels[rating].note}</span>
                    </button>
                  ))}
                </div>
                {(ratingResult || memory) && (
                  <div className="schedule-result">
                    <span>容易度 {(ratingResult?.easeFactor ?? memory?.easeFactor ?? 2.5).toFixed(2)}</span>
                    <span>长期间隔 {ratingResult?.intervalDays ?? memory?.intervalDays ?? 0} 天</span>
                    <strong>下次长期复习：{displayDate(ratingResult?.nextReviewDate ?? memory?.nextReviewDate)}</strong>
                  </div>
                )}
                <div className="finish-actions">
                  <button className="button outline" onClick={() => setCardIndex(-1)}>返回第一张卡片</button>
                  <button className="button outline" onClick={() => moveToSense(0)}>复习全部义项</button>
                  <button className="button outline" onClick={onViewFavorites}>查看收藏例句</button>
                  <button className="button coral" onClick={() => setWordCheckOpen((current) => !current)}>完成本词小测</button>
                  <button className="button dark" onClick={onNextEntry}>下一词 →</button>
                </div>
                {wordCheckOpen && (
                  <section className="word-check-panel" aria-label="本词小测">
                    <span>本词小测 · 根据新例句辨认义项</span>
                    <h3 lang="es">{wordCheckExample.spanish}</h3>
                    <p>这句话中的 <strong>{entry.lemma}</strong> 使用了哪个义项？</p>
                    <div>
                      {entry.senses.map((candidate) => {
                        const wrong = wordCheckWrongIds.includes(candidate.id);
                        const correct = wordCheckComplete && candidate.id === wordCheckSense.id;
                        return (
                          <button
                            key={candidate.id}
                            className={wrong ? "wrong" : correct ? "correct" : ""}
                            disabled={wrong || wordCheckComplete}
                            onClick={() => chooseWordCheck(candidate.id)}
                          >
                            <span>{candidate.cardLabel}</span>
                            <strong>{candidate.labelZh}</strong>
                          </button>
                        );
                      })}
                    </div>
                    <small>{wordCheckComplete
                      ? `答对了：${wordCheckExample.targetMeaning}`
                      : wordCheckWrongIds.length ? "这个义项不符合语境，请继续选择。" : "先独立判断，再查看结果。"}</small>
                  </section>
                )}
              </section>
            )}
          </article>
        ) : null}

        <footer className="learning-flow-footer">
          <span>{sourceNotice}</span>
          <span>小箭头：例句　大箭头：义项</span>
        </footer>
      </section>

      {analysisExample && (
        <div className="analysis-backdrop" onMouseDown={() => setAnalysisExample(null)}>
          <aside className="analysis-drawer" onMouseDown={(event) => event.stopPropagation()} aria-label="例句详细分析">
            <button className="analysis-close" onClick={() => setAnalysisExample(null)}>×</button>
            <span className="eyebrow">ANÁLISIS · 逐句学习</span>
            <h2><InteractiveSpanishText text={analysisExample.spanish} targetForms={targetForms} onWordClick={onWordClick} /></h2>
            {onWordClick && <p className="token-help">点击句中非目标词，可打开对应词条；粗体为当前目标词。</p>}
            <p className="analysis-translation">{analysisExample.chinese}</p>
            <p className="analysis-english">EN · {analysisExample.english}</p>

            <section className="analysis-meaning"><span>目标词在本句中的义项</span><strong>{analysisExample.targetMeaning}</strong></section>

            <details open><summary>句子成分与从句</summary><ul>{analysisExample.analysis.sentenceParts.map((item) => <li key={item}>{item}</li>)}</ul></details>
            <details open><summary>动词原形、时态、语气与人称</summary><p>{analysisExample.analysis.verbInfo}</p></details>
            <details><summary>代词、冠词、性数一致、介词与语序</summary><ul>{analysisExample.analysis.functionNotes.map((item) => <li key={item}>{item}</li>)}</ul></details>
            <details><summary>固定搭配、词块与句式框架</summary><div className="analysis-chunks">{analysisExample.analysis.chunks.map((item) => <span key={item}>{item}</span>)}</div><p><strong>框架：</strong>{analysisExample.framework}</p><p><strong>可替换：</strong>{analysisExample.replacement}</p></details>
            <details><summary>英语与西语的关键差别</summary><p>{analysisExample.analysis.englishContrast}</p><p className="transfer-warning"><strong>常见迁移错误：</strong>{analysisExample.analysis.transferError}</p></details>
            <details><summary>句中其他值得学习的词语</summary><ul>{analysisExample.analysis.extraVocabulary.map((item) => <li key={item}>{item}</li>)}</ul></details>
            <section className="micro-exercise">
              <span>立即使用这个结构</span><h3>{analysisExample.analysis.microExercise.prompt}</h3>
              {!showMicroAnswer ? <button className="button dark" onClick={() => setShowMicroAnswer(true)}>显示参考答案</button> : <p lang="es">{analysisExample.analysis.microExercise.answer}</p>}
            </section>
          </aside>
        </div>
      )}
    </div>
  );
}
