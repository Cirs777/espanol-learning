# Word-book indexes

本目录只保存经过来源和许可记录的词形索引。索引条目不等于可学习内容。

`a1-elelex-core.json` 来源于 ELELex（CEFRLex project, CENTAL / UCLouvain），依照 CC BY-NC-SA 4.0 用于个人非商业学习。筛选、归并规则和原始下载地址保存在文件的 `meta` 中。

`a2-elelex-core.json` 使用相同合法来源，筛选至少出现在 5 份 A2 来源文档中的词形，得到 1775 个候选索引；其中 779 个与 A1 共用同一个核心词条 ID，避免为同一单词维护两份内容。

截至 `v0.3.0-dev.1`，首批 10 个索引词已在 `../a1-core-content-source.json` 中补齐常用义项组、每义项 4 条精选例句和逐句分析，并由 `../a1-semantic-plan.json` 按语义对比排序。其余 825 个仍需补齐内容和审核后才能加入学习队列。

索引条目可以用于概览、搜索和提前“斩”，但不能仅凭词形和频率进入正式学习。内容质量由 `npm run content:audit` 检查：重要义项、词块、每义项至少 4 条例句、例句长度、句式框架和额外词汇缺一不可。
